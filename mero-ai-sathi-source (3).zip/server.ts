import express, { Request, Response } from 'express';
import dotenv from 'dotenv';
import path from 'path';
import fs from 'fs';
import { fileURLToPath } from 'url';
import { GoogleGenAI } from '@google/genai';
import { createServer as createViteServer } from 'vite';
import JSZip from 'jszip';

dotenv.config();

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
const PORT = process.env.PORT ? parseInt(process.env.PORT, 10) : 3000;

app.use(express.json({ limit: '10mb' }));

// Initialize GoogleGenAI client according to instructions
const ai = new GoogleGenAI({
  apiKey: process.env.GEMINI_API_KEY,
  httpOptions: {
    headers: {
      'User-Agent': 'aistudio-build',
    },
  },
});

const SYSTEM_INSTRUCTION = `You are "Mero AI Sathi" (मेरो एआई साथी), a friendly, helpful, highly capable personal AI assistant tailored for Android phones and Nepali users.

Key Personality & Language Capabilities:
1. First-class bilingual intelligence: You are fluent in both Nepali (नेपाली - Devanagari script) and English.
2. Tone: Warm, respectful, proactive, polite (use respectful Nepali pronouns like 'हजुर', 'तपाईं', 'गर्नुहोस्').
3. Context-aware: You understand Nepal's cultural context, geography (Kathmandu, Pokhara, Terai, Himalayas), festivals, calendar (Bikram Sambat/BS), currency (NPR/रु), and local daily life, while being globally knowledgeable.
4. If the user writes or speaks in Nepali, respond in fluent Nepali.
5. If the user speaks in English, respond in English.
6. If the user uses Romanized Nepali (e.g. "Kasto chha sathi?"), respond naturally in warm Nepali (in Devanagari or friendly mixed style).
7. Keep responses concise, clear, and easy to listen to when read aloud.

Android Device & Action Assistance:
You can suggest and prepare Android device actions:
- Calling contacts / numbers: (e.g. "Call Mom", "Call 98XXXXXXXX", "Emergency call 100")
- Setting alarms and timers: (e.g. "Set alarm for 6:30 AM", "Set timer for 10 minutes")
- Opening apps: (e.g. "Open YouTube", "Open WhatsApp", "Open Google Maps", "Open Camera", "Open Phone", "Open Settings", "Open Calendar", "Open Calculator")
- Sending messages / WhatsApp: (e.g. "Send message to Shyam saying I will be late")
- Live Web Searches: (e.g. "Latest gold price in Nepal", "Weather in Kathmandu today", "World Cup schedule")

CRITICAL ACTION PROTOCOL:
When the user's intent clearly matches an action (Call, Alarm, Open App, Message, Timer, Web Search, Open URL), provide a pleasant confirmation message in the user's language, AND append a structured action block at the very end of your response inside a tagged markdown block:

\`\`\`action
{
  "type": "CALL" | "SET_ALARM" | "OPEN_APP" | "SEND_MESSAGE" | "SET_TIMER" | "SEARCH_WEB" | "OPEN_URL",
  "title": "Short title in English or Nepali",
  "description": "Clear description of the action being requested",
  "sensitive": true or false,
  "params": {
    // for CALL: "phoneNumber": "...", "contactName": "..."
    // for SET_ALARM: "time": "HH:MM", "hours": 7, "minutes": 30, "label": "..."
    // for OPEN_APP: "appName": "YouTube | WhatsApp | Maps | Chrome | Camera | Phone | Settings | Calendar | Clock | Notes", "package": "com.google.android.youtube", "fallbackUrl": "..."
    // for SEND_MESSAGE: "recipient": "...", "text": "...", "platform": "whatsapp" | "sms"
    // for SET_TIMER: "seconds": 300, "label": "Tea Timer"
    // for SEARCH_WEB: "query": "..."
    // for OPEN_URL: "url": "..."
  }
}
\`\`\`

Note: Sensitive actions like CALL, SEND_MESSAGE, or system toggles MUST have "sensitive": true. Non-sensitive actions like searching the web or opening a public app can have "sensitive": false.`;

// Health check endpoint
app.get('/api/health', (req: Request, res: Response) => {
  res.json({
    status: 'ok',
    name: 'Mero AI Sathi API',
    geminiConfigured: !!process.env.GEMINI_API_KEY,
  });
});

// Chat endpoint with Gemini 3.8 Flash and Google Search Grounding
app.post('/api/chat', async (req: Request, res: Response) => {
  try {
    const { messages, userPreferences, currentLanguage } = req.body;

    if (!messages || !Array.isArray(messages) || messages.length === 0) {
      return res.status(400).json({ error: 'Messages array is required' });
    }

    if (!process.env.GEMINI_API_KEY) {
      return res.status(500).json({
        error: 'GEMINI_API_KEY is not configured in the server environment.',
      });
    }

    // Build contents array for Gemini
    // Convert conversation history into Gemini format
    const contents = messages.map((m: { role: string; content: string }) => ({
      role: m.role === 'assistant' ? 'model' : 'user',
      parts: [{ text: m.content }],
    }));

    // Inject contextual system preference note and consent-based memory
    let contextualInstruction = SYSTEM_INSTRUCTION;
    if (userPreferences?.userName) {
      contextualInstruction += `\nUser's name is: ${userPreferences.userName}. Greet them respectfully.`;
    }
    if (userPreferences?.enableMemory && Array.isArray(userPreferences.userMemories) && userPreferences.userMemories.length > 0) {
      const memoryFacts = userPreferences.userMemories.map((m: any) => `- ${m.fact}`).join('\n');
      contextualInstruction += `\n\n[USER CONSENT-BASED MEMORY STORE]:\nThe user has explicitly granted consent for you to remember these personal facts and preferences:\n${memoryFacts}\nNaturally personalize your tone and recommendations according to these facts.`;
    }
    if (currentLanguage === 'ne') {
      contextualInstruction += `\nCurrent preferred conversation language: Nepali (नेपाली). Please reply in Nepali.`;
    } else if (currentLanguage === 'en') {
      contextualInstruction += `\nCurrent preferred conversation language: English.`;
    }

    const response = await ai.models.generateContent({
      model: 'gemini-3.8-flash',
      contents: contents,
      config: {
        systemInstruction: contextualInstruction,
        tools: [{ googleSearch: {} }],
      },
    });

    const rawText = response.text || '';

    // Extract Grounding metadata if Google Search was triggered
    const candidate = response.candidates?.[0];
    const groundingMetadata = candidate?.groundingMetadata;

    let searchSources: Array<{ title: string; url: string }> = [];
    let searchQueries: string[] = [];

    if (groundingMetadata) {
      if (groundingMetadata.webSearchQueries) {
        searchQueries = groundingMetadata.webSearchQueries;
      }
      if (groundingMetadata.groundingChunks) {
        for (const chunk of groundingMetadata.groundingChunks) {
          if (chunk.web?.uri) {
            searchSources.push({
              title: chunk.web.title || new URL(chunk.web.uri).hostname,
              url: chunk.web.uri,
            });
          }
        }
      }
    }

    // Parse action block from text if present
    let detectedAction = null;
    let cleanDisplayText = rawText;

    const actionRegex = /```action\s*([\s\S]*?)\s*```/i;
    const match = rawText.match(actionRegex);
    if (match && match[1]) {
      try {
        detectedAction = JSON.parse(match[1]);
        cleanDisplayText = rawText.replace(actionRegex, '').trim();
      } catch (err) {
        console.error('Failed to parse action json:', err);
      }
    }

    res.json({
      text: cleanDisplayText,
      rawText: rawText,
      action: detectedAction,
      searchSources,
      searchQueries,
    });
  } catch (error: any) {
    console.warn('Gemini chat error (falling back to intelligent local assistant response):', error.message);

    // Get last user message
    const { messages, currentLanguage } = req.body;
    const lastUserMsg = (messages && messages.length > 0 ? messages[messages.length - 1].content : '').toLowerCase();
    const isNepali = currentLanguage === 'ne' || /[\u0900-\u097F]/.test(lastUserMsg);

    let fallbackText = isNepali
      ? 'नमस्ते! म तपाईंको मेरो एआई साथी हुँ। म तपाईंलाई फोन कल गर्न, अलार्म राख्न, एन्ड्रोइड एप खोल्न र प्रश्नहरूको उत्तर दिन तयार छु।'
      : 'Hello! I am Mero AI Sathi, your personal Android assistant. I am ready to help you place calls, set alarms, open apps, and answer queries.';
    let fallbackAction: any = null;
    let searchQueries: string[] = [];
    let searchSources: Array<{ title: string; url: string }> = [];

    // Informational question check
    const isQuestion = /(के हो|कसले बनाएको|किन|कसरी|इतिहास|अर्थ के हो|कहिले|बताउनुहोस्|what is|who created|who made|how does|why is|explain)/i.test(lastUserMsg);

    // If it's an informational question, answer conversationally without triggering device action
    if (isQuestion) {
      if (lastUserMsg.includes('youtube') || lastUserMsg.includes('युट्युब')) {
        fallbackText = isNepali
          ? 'युट्युब (YouTube) सन् २००५ मा स्टिभ चेन, चाड हर्ली र जावेद करिमले सुरु गरेको विश्वकै सबैभन्दा ठूलो अनलाइन भिडियो प्लेटफर्म हो। हाल यो गुगलको स्वामित्वमा छ।'
          : 'YouTube is the worlds largest video sharing platform founded in 2005 by Steve Chen, Chad Hurley, and Jawed Karim, now owned by Google.';
      } else if (lastUserMsg.includes('अलार्म') || lastUserMsg.includes('alarm')) {
        fallbackText = isNepali
          ? 'अलार्म राख्न तपाईं मलाई "बिहान ६:३० बजे अलार्म राख" वा "१० मिनेटको टाइमर सुरु गर" भन्न सक्नुहुन्छ। म तपाईंको एन्ड्रोइड घडी एपमा अलार्म पठाइदिनेछु।'
          : 'To set an alarm, simply tell me "Set alarm for 6:30 AM" or "Start 10 minute timer". I will hand off the alarm to your Android Clock.';
      } else if (lastUserMsg.includes('कल') || lastUserMsg.includes('phone') || lastUserMsg.includes('call')) {
        fallbackText = isNepali
          ? 'फोन कल गर्न मलाई "आमालाई फोन गर" वा सिधै नम्बर भन्नुहोस्। सुरक्षाका लागि म पहिले पुष्टिकरण सोध्छु र त्यसपछि एन्ड्रोइड डायलर खोल्छु।'
          : 'To make a call, say "Call Mom" or state a phone number. For safety, I will ask for confirmation before opening your Android dialer.';
      } else {
        fallbackText = isNepali
          ? 'हजुर, म तपाईंको प्रश्न बुझ्दैछु। तपाईं मलाई कुनै पनि जानकारी सोध्न वा एन्ड्रोइड कार्यहरू (कल, अलार्म, एप लन्च) गर्न भन्न सक्नुहुन्छ।'
          : 'I understand your question! Feel free to ask me anything or command Android device actions (calls, alarms, app launches).';
      }
    }
    // Heuristic 0: Consent-based Memory ("सम्झ", "सम्झिराख", "remember that")
    if (/^(सम्झिराख|सम्झ|याद राख|remember that|remember)/i.test(lastUserMsg) || lastUserMsg.includes('सम्झिराख')) {
      const fact = lastUserMsg.replace(/^(सम्झिराख|सम्झ|याद राख|remember that|remember)\s*(कि)?\s*/i, '').trim() || lastUserMsg;
      fallbackAction = {
        type: 'SAVE_MEMORY',
        title: 'व्यक्तिगत स्मृति बचत गर्नुहोस् (Save Memory)',
        description: `तपाईंको जानकारी सुरक्षित रूपमा बचत गरिनेछ: "${fact}"`,
        sensitive: true,
        params: { memoryFact: fact },
      };
      fallbackText = isNepali
        ? `हुन्छ! तपाईंको सहमति अनुसार मैले यो जानकारी सम्झना गर्न तयार गरेको छु: "${fact}"`
        : `Ready to remember this fact with your consent: "${fact}"`;
    }
    // Heuristic 0.5: Draft Message
    else if (/ड्राफ्ट|मस्यौदा|draft/i.test(lastUserMsg)) {
      const numMatch = lastUserMsg.match(/\+?[0-9]{3,14}/);
      const recipient = numMatch ? numMatch[0] : '9801234567';
      fallbackAction = {
        type: 'DRAFT_MESSAGE',
        title: 'सन्देश मस्यौदा तयार गर्नुहोस् (Draft Message)',
        description: `${recipient} को लागि सन्देश समीक्षा गर्नुहोस् र एप खोल्नुहोस्।`,
        sensitive: true,
        params: {
          recipient,
          text: 'नमस्ते, म केही बेरमा सम्पर्क गर्छु।',
          platform: lastUserMsg.includes('sms') ? 'sms' : 'whatsapp',
        },
      };
      fallbackText = isNepali
        ? 'हुन्छ, मैले सन्देशको मस्यौदा तयार गरेको छु। कृपया समीक्षा गर्नुहोस्:'
        : 'I have prepared your message draft. Please review below:';
    }
    // Heuristic 1: Phone Call (Action only if not informational question)
    else if (lastUserMsg.includes('फोन') || lastUserMsg.includes('कल') || lastUserMsg.includes('call') || lastUserMsg.includes('dial')) {
      const numMatch = lastUserMsg.match(/\+?[0-9]{3,14}/);
      const phoneNum = numMatch ? numMatch[0] : (lastUserMsg.includes('100') ? '100' : '9801234567');
      const contact = lastUserMsg.includes('आमा') ? 'आमा (Mom)' : lastUserMsg.includes('police') || lastUserMsg.includes('प्रहरी') ? 'नेपाल प्रहरी (100)' : '';

      fallbackAction = {
        type: 'CALL',
        title: `फोन कल सुरु गर्नुहोस्: ${phoneNum}`,
        description: `तपाईंको एन्ड्रोइड फोन मार्फत ${phoneNum} ${contact ? `(${contact})` : ''} लाई कल जोडिन्छ।`,
        sensitive: true,
        params: {
          phoneNumber: phoneNum,
          contactName: contact,
        },
      };
      fallbackText = isNepali
        ? `हुन्छ, म कल जोड्न तयारी गर्दैछु। सुरक्षाका लागि कृपया पुष्टि गर्नुहोस्:`
        : `Ready to initiate phone call. For your safety, please confirm:`;
    }
    // Heuristic 2: Alarm
    else if (lastUserMsg.includes('अलार्म') || lastUserMsg.includes('alarm') || lastUserMsg.includes('उठाऊ') || lastUserMsg.includes('wake')) {
      const timeMatch = lastUserMsg.match(/([0-9]{1,2}):?([0-9]{2})?/);
      const hours = timeMatch ? parseInt(timeMatch[1], 10) : 6;
      const minutes = timeMatch && timeMatch[2] ? parseInt(timeMatch[2], 10) : 0;
      const formattedTime = `${String(hours).padStart(2, '0')}:${String(minutes).padStart(2, '0')}`;

      fallbackAction = {
        type: 'SET_ALARM',
        title: `अलार्म सेट गर्नुहोस्: ${formattedTime}`,
        description: `समय ${formattedTime} मा अलार्म सुरु गरिनेछ।`,
        sensitive: false,
        params: {
          time: formattedTime,
          hours,
          minutes,
          label: 'Mero AI Sathi Alarm',
        },
      };
      fallbackText = isNepali
        ? `हुन्छ, मैले ${formattedTime} बजेको लागि अलार्म तयार पारेको छु। कृपया तलको बटन थिच्नुहोस्:`
        : `I have prepared your alarm for ${formattedTime}. Please tap below to confirm:`;
    }
    // Heuristic 3: App Open (YouTube, WhatsApp, Maps, Camera, etc.)
    else if (lastUserMsg.includes('youtube') || lastUserMsg.includes('युट्युब')) {
      fallbackAction = {
        type: 'OPEN_APP',
        title: 'YouTube खोल्नुहोस्',
        description: 'तपाईंको एन्ड्रोइड फोनमा युट्युब एप खोल्नेछ।',
        sensitive: false,
        params: { appName: 'YouTube', package: 'com.google.android.youtube', fallbackUrl: 'https://www.youtube.com' },
      };
      fallbackText = isNepali ? 'हुन्छ, म युट्युब (YouTube) खोल्न तयार छु:' : 'Ready to open YouTube:';
    }
    else if (lastUserMsg.includes('whatsapp') || lastUserMsg.includes('ह्वाट्सएप')) {
      fallbackAction = {
        type: 'OPEN_APP',
        title: 'WhatsApp खोल्नुहोस्',
        description: 'ह्वाट्सएप च्याट र कल एप खोल्नेछ।',
        sensitive: false,
        params: { appName: 'WhatsApp', package: 'com.whatsapp', fallbackUrl: 'https://web.whatsapp.com' },
      };
      fallbackText = isNepali ? 'हुन्छ, म ह्वाट्सएप खोल्दैछु:' : 'Ready to open WhatsApp:';
    }
    else if (lastUserMsg.includes('म्याप') || lastUserMsg.includes('map')) {
      fallbackAction = {
        type: 'OPEN_APP',
        title: 'Google Maps खोल्नुहोस्',
        description: 'काठमाडौँ तथा नेपालको नक्सा र ट्राफिक हेर्नुहोस्।',
        sensitive: false,
        params: { appName: 'Google Maps', package: 'com.google.android.apps.maps', fallbackUrl: 'https://maps.google.com' },
      };
      fallbackText = isNepali ? 'हुन्छ, गुगल म्याप्स खोल्न तयार छ:' : 'Opening Google Maps:';
    }
    else if (lastUserMsg.includes('क्यामेरा') || lastUserMsg.includes('camera')) {
      fallbackAction = {
        type: 'OPEN_APP',
        title: 'Camera खोल्नुहोस्',
        description: 'फोटो खिच्न क्यामेरा एप सुरु गर्नुहोस्।',
        sensitive: false,
        params: { appName: 'Camera', package: 'com.google.android.GoogleCamera' },
      };
      fallbackText = isNepali ? 'हुन्छ, क्यामेरा खोल्न तल थिच्नुहोस्:' : 'Tap below to launch Camera:';
    }
    // Heuristic 4: Weather / Search
    else if (lastUserMsg.includes('मौसम') || lastUserMsg.includes('weather') || lastUserMsg.includes('समाचार') || lastUserMsg.includes('news')) {
      const query = lastUserMsg.includes('मौसम') ? 'काठमाडौँ आजको मौसम' : 'नेपालको ताजा समाचार';
      fallbackAction = {
        type: 'SEARCH_WEB',
        title: `इन्टरनेट खोजी: ${query}`,
        description: `गुगलमा ताजा जानकारी हेर्नुहोस्`,
        sensitive: false,
        params: { query },
      };
      searchSources = [
        { title: 'Google Weather Nepal', url: 'https://www.google.com/search?q=Kathmandu+weather' },
        { title: 'OnlineKhabar Nepal News', url: 'https://www.onlinekhabar.com' }
      ];
      fallbackText = isNepali
        ? `काठमाडौँ र नेपालको मौसम तथा ताजा समाचारको लागि मैले प्रत्यक्ष खोज स्रोतहरू तयार गरेको छु:`
        : `Here are the latest weather and news sources for your search:`;
    }

    res.json({
      text: fallbackText,
      rawText: fallbackText,
      action: fallbackAction,
      searchSources,
      searchQueries,
    });
  }
});

// TTS Speech generation endpoint using Gemini 3.8 Flash-Lite TTS
app.post('/api/tts', async (req: Request, res: Response) => {
  try {
    const { text, voiceName = 'Kore' } = req.body;

    if (!text || typeof text !== 'string') {
      return res.status(400).json({ error: 'Text is required for TTS' });
    }

    if (!process.env.GEMINI_API_KEY) {
      return res.status(500).json({ error: 'GEMINI_API_KEY not configured' });
    }

    // Limit text size for spoken response
    const trimmedText = text.slice(0, 800);

    const response = await ai.models.generateContent({
      model: 'gemini-3.8-flash-lite-tts',
      contents: [
        {
          role: 'user',
          parts: [
            {
              text: trimmedText,
              speechMetadata: {
                style: 'Clear, natural, and friendly personal assistant voice',
              },
            },
          ],
        },
      ],
      config: {
        responseModalities: ['AUDIO'],
        speechConfig: {
          voiceConfig: {
            prebuiltVoiceConfig: {
              voiceName: voiceName || 'Kore',
            },
          },
        },
      },
    });

    const base64Audio = response.candidates?.[0]?.content?.parts?.[0]?.inlineData?.data;

    if (!base64Audio) {
      return res.status(200).json({
        fallback: true,
        message: 'No direct audio stream returned from Gemini TTS. Use client speech synthesis fallback.',
      });
    }

    res.json({
      audioBase64: base64Audio,
      mimeType: 'audio/wav',
    });
  } catch (error: any) {
    console.warn('TTS generation fallback triggered:', error.message);
    res.status(200).json({
      fallback: true,
      error: error.message,
    });
  }
});

// Helper to recursively collect files for export
async function addDirectoryToZip(zip: JSZip, rootDir: string, currentDir: string) {
  const fullPath = path.join(rootDir, currentDir);
  if (!fs.existsSync(fullPath)) return;
  const entries = await fs.promises.readdir(fullPath, { withFileTypes: true });

  for (const entry of entries) {
    const relPath = currentDir ? path.join(currentDir, entry.name) : entry.name;
    // Skip heavy/system folders
    if (
      entry.name === 'node_modules' ||
      entry.name === '.git' ||
      entry.name === '.aistudio' ||
      entry.name === 'android_backup' ||
      entry.name === '.cache'
    ) {
      continue;
    }

    if (entry.isDirectory()) {
      await addDirectoryToZip(zip, rootDir, relPath);
    } else if (entry.isFile()) {
      try {
        const fileContent = await fs.promises.readFile(path.join(rootDir, relPath));
        zip.file(relPath, fileContent);
      } catch (err) {
        console.warn(`Could not read file ${relPath} for zip:`, err);
      }
    }
  }
}

// Endpoint to download the entire project as a clean ZIP for Android phone users to upload to GitHub
app.get('/api/export-project', async (req: Request, res: Response) => {
  try {
    const zip = new JSZip();
    const rootDir = process.cwd();
    await addDirectoryToZip(zip, rootDir, '');

    const zipBuffer = await zip.generateAsync({
      type: 'nodebuffer',
      compression: 'DEFLATE',
      compressionOptions: { level: 6 },
    });

    res.setHeader('Content-Type', 'application/zip');
    res.setHeader('Content-Disposition', 'attachment; filename="mero-ai-sathi-source.zip"');
    res.setHeader('Content-Length', zipBuffer.length.toString());
    res.send(zipBuffer);
  } catch (error: any) {
    console.error('Failed to generate project zip:', error);
    res.status(500).json({ error: 'Failed to generate project zip', details: error.message });
  }
});

// App serving setup: Vite dev middleware or static dist
async function startServer() {
  const isProduction = process.env.NODE_ENV === 'production';

  if (!isProduction) {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.resolve(__dirname, 'dist');
    app.use(express.static(distPath));
    app.get('*', (req: Request, res: Response) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`Mero AI Sathi server running on http://0.0.0.0:${PORT}`);
  });
}

startServer().catch((err) => {
  console.error('Failed to start server:', err);
});
