import fs from 'fs';
import path from 'path';
import zlib from 'zlib';

function createPng(width, height, r, g, b) {
  // Simple uncompressed or deflate PNG generator
  const signature = Buffer.from([137, 80, 78, 71, 13, 10, 26, 10]);

  // IHDR chunk
  const ihdrData = Buffer.alloc(13);
  ihdrData.writeUInt32BE(width, 0);
  ihdrData.writeUInt32BE(height, 4);
  ihdrData[8] = 8; // bit depth
  ihdrData[9] = 2; // color type: truecolor (RGB)
  ihdrData[10] = 0; // compression
  ihdrData[11] = 0; // filter
  ihdrData[12] = 0; // interlace
  const ihdr = makeChunk('IHDR', ihdrData);

  // Scanlines with filter byte 0
  const rowSize = 1 + width * 3;
  const rawData = Buffer.alloc(rowSize * height);

  for (let y = 0; y < height; y++) {
    const rowOffset = y * rowSize;
    rawData[rowOffset] = 0; // No filter

    // Subtle dark blue assistant gradient and center cyan glow
    const dy = (y - height / 2) / (height / 2);
    for (let x = 0; x < width; x++) {
      const dx = (x - width / 2) / (width / 2);
      const dist = Math.sqrt(dx * dx + dy * dy);
      const colOffset = rowOffset + 1 + x * 3;

      if (dist < 0.6) {
        // Glowing cyan/blue core
        rawData[colOffset] = Math.min(255, Math.floor(0 + (1 - dist) * 70));
        rawData[colOffset + 1] = Math.min(255, Math.floor(180 + (1 - dist) * 75));
        rawData[colOffset + 2] = Math.min(255, Math.floor(230 + (1 - dist) * 25));
      } else {
        // Dark blue background
        rawData[colOffset] = Math.floor(r * (1 - dy * 0.2));
        rawData[colOffset + 1] = Math.floor(g * (1 - dy * 0.2));
        rawData[colOffset + 2] = Math.floor(b * (1 - dy * 0.2));
      }
    }
  }

  const compressedData = zlib.deflateSync(rawData);
  const idat = makeChunk('IDAT', compressedData);
  const iend = makeChunk('IEND', Buffer.alloc(0));

  return Buffer.concat([signature, ihdr, idat, iend]);
}

function makeChunk(type, data) {
  const len = data.length;
  const buf = Buffer.alloc(12 + len);
  buf.writeUInt32BE(len, 0);
  buf.write(type, 4, 4, 'ascii');
  data.copy(buf, 8);
  const crc = calcCrc(buf.subarray(4, 8 + len));
  buf.writeUInt32BE(crc, 8 + len);
  return buf;
}

const crcTable = [];
for (let n = 0; n < 256; n++) {
  let c = n;
  for (let k = 0; k < 8; k++) {
    if (c & 1) c = 0xedb88320 ^ (c >>> 1);
    else c = c >>> 1;
  }
  crcTable[n] = c;
}

function calcCrc(buf) {
  let c = 0xffffffff;
  for (let i = 0; i < buf.length; i++) {
    c = crcTable[(c ^ buf[i]) & 0xff] ^ (c >>> 8);
  }
  return (c ^ 0xffffffff) >>> 0;
}

const publicDir = path.resolve('public');
if (!fs.existsSync(publicDir)) {
  fs.mkdirSync(publicDir, { recursive: true });
}

fs.writeFileSync(path.join(publicDir, 'pwa-192x192.png'), createPng(192, 192, 10, 26, 64));
fs.writeFileSync(path.join(publicDir, 'pwa-512x512.png'), createPng(512, 512, 10, 26, 64));
fs.writeFileSync(path.join(publicDir, 'pwa-maskable-512x512.png'), createPng(512, 512, 8, 20, 50));
fs.writeFileSync(path.join(publicDir, 'apple-touch-icon.png'), createPng(180, 180, 10, 26, 64));

console.log('PWA PNG icons generated successfully!');
