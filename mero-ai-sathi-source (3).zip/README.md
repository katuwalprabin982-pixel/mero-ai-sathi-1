# Mero AI Sathi (मेरो एआई साथी) • Android Personal AI Assistant

An intelligent, bilingual (Nepali & English) personal AI assistant designed specifically for Android devices with voice interaction, Gemini 3.8 Flash intelligence, Google Search grounding, and genuine Android intent execution (calls, alarms, timers, app launchers).

---

## 📱 How to Build the Real Android APK (Using Android Phone Only - No PC Required!)

If you do not have a computer and want to build the installable `app-debug.apk` directly using GitHub's free cloud servers:

### Step 1: Download the Source Code ZIP
- In the running Mero AI Sathi web app, tap **"Build APK"** (or open the Permissions / APK guide modal).
- Tap the **"Download Complete Source Code (.ZIP)"** button.
- Your Android phone will download `mero-ai-sathi-source.zip`.

### Step 2: Create a Repository on GitHub
1. Open Google Chrome on your Android phone and go to [github.com](https://github.com).
2. Sign in (or create a free account).
3. Tap the **`+`** icon at the top right -> choose **"New repository"**.
4. Name your repository: `mero-ai-sathi`.
5. Keep it Public (or Private) and tap **"Create repository"**.

### Step 3: Upload the Source Code
1. On your new repository screen, tap the link: **"uploading an existing file"**.
2. Select and upload the contents of your downloaded project ZIP.
   *(Note: The automated `.github/workflows/build-apk.yml` file is already included!)*
3. Tap **"Commit changes"**.

### Step 4: Automated Cloud Build (GitHub Actions)
1. Tap the **"Actions"** tab on your GitHub repository.
2. You will see **"Build Android APK (Mero AI Sathi)"** running automatically.
3. GitHub's cloud runners set up Node.js 20, Java JDK 17, and Android SDK, run `npm run build`, sync Capacitor, and compile `./gradlew assembleDebug`.
4. It takes approximately **2 minutes**. When finished, a green checkmark (✓) appears.

### Step 5: Download & Install on Your Phone
1. Tap on the completed workflow run.
2. Scroll down to the **"Artifacts"** section.
3. Tap on **`mero-ai-sathi-debug-apk`**.
4. A zip file containing `app-debug.apk` will download to your phone.
5. Extract/tap `app-debug.apk` -> when prompted, allow "Install unknown apps" -> tap **Install**!

---

## 💻 Alternative: Building on a Computer (Android Studio / Local Gradle)

If you have a computer with Android Studio:

```bash
# 1. Clone repository
git clone <your-repo-url>
cd mero-ai-sathi

# 2. Install dependencies & build web bundle
npm install
npm run build

# 3. Synchronize native Android platform
npx cap sync android

# 4. Build APK with Gradle CLI:
cd android
chmod +x gradlew
./gradlew assembleDebug

# Output APK location:
# android/app/build/outputs/apk/debug/app-debug.apk

# 5. Sideload to connected Android phone:
adb install -r android/app/build/outputs/apk/debug/app-debug.apk
```

Or open the `android/` directory in **Android Studio** and click **Run ▶** or **Build > Build Bundle(s) / APK(s) > Build APK(s)**.

---

## 🚀 Key Features
- **Bilingual STT/TTS**: Fluent Nepali (Devanagari) & English speech recognition and synthesis.
- **Gemini 3.8 Flash AI**: Context-aware natural chat with Google Search grounding and source links.
- **Genuine Device Intents**:
  - `tel:` / `ACTION_DIAL` for phone calls with safety confirmation modal.
  - `SET_ALARM` / `SCHEDULE_EXACT_ALARM` for alarms and timers.
  - Deep links for YouTube (`vnd.youtube`), WhatsApp (`smsto:`), Google Maps, Camera, Calculator.
- **Privacy First**: Optional local data consent toggle, instant memory wipe, and no hidden tracking.
