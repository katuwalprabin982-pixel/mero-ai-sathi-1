import { AndroidAppShortcut, ActionExecutionDetail, ActionStatus } from '../types/assistant';

// Curated list of popular Android apps with package names and intent URLs
export const POPULAR_ANDROID_APPS: AndroidAppShortcut[] = [
  {
    id: 'youtube',
    name: 'YouTube',
    nepaliName: 'युट्युब',
    icon: 'Youtube',
    category: 'social',
    packageName: 'com.google.android.youtube',
    intentUri: 'intent://#Intent;package=com.google.android.youtube;scheme=vnd.youtube;end',
    deepLinkScheme: 'vnd.youtube://',
    webFallback: 'https://www.youtube.com',
    description: 'Watch Nepali & global videos, music, news',
    browserSupportLevel: 'deep_link',
  },
  {
    id: 'whatsapp',
    name: 'WhatsApp',
    nepaliName: 'ह्वाट्सएप',
    icon: 'MessageSquare',
    category: 'social',
    packageName: 'com.whatsapp',
    intentUri: 'intent://#Intent;package=com.whatsapp;scheme=whatsapp;end',
    deepLinkScheme: 'whatsapp://send',
    webFallback: 'https://web.whatsapp.com',
    description: 'Free chats, audio and video calls',
    browserSupportLevel: 'deep_link',
  },
  {
    id: 'maps',
    name: 'Google Maps',
    nepaliName: 'गुगल म्याप्स',
    icon: 'MapPin',
    category: 'utility',
    packageName: 'com.google.android.apps.maps',
    intentUri: 'intent://#Intent;package=com.google.android.apps.maps;scheme=geo;end',
    deepLinkScheme: 'geo:0,0',
    webFallback: 'https://maps.google.com',
    description: 'Directions, Kathmandu traffic, local places',
    browserSupportLevel: 'native_intent',
  },
  {
    id: 'dialer',
    name: 'Phone / Dialer',
    nepaliName: 'फोन / डायलर',
    icon: 'Phone',
    category: 'system',
    packageName: 'com.google.android.dialer',
    intentUri: 'tel:',
    deepLinkScheme: 'tel:',
    webFallback: 'tel:',
    description: 'Make voice phone calls to any contact',
    browserSupportLevel: 'native_intent',
  },
  {
    id: 'camera',
    name: 'Camera',
    nepaliName: 'क्यामेरा',
    icon: 'Camera',
    category: 'tools',
    packageName: 'com.google.android.GoogleCamera',
    intentUri: 'intent:#Intent;action=android.media.action.IMAGE_CAPTURE;end',
    webFallback: 'intent:#Intent;action=android.media.action.IMAGE_CAPTURE;end',
    description: 'Capture photos and memories',
    browserSupportLevel: 'native_intent',
  },
  {
    id: 'clock',
    name: 'Clock & Alarms',
    nepaliName: 'घडी र अलार्म',
    icon: 'AlarmClock',
    category: 'system',
    packageName: 'com.google.android.deskclock',
    intentUri: 'intent:#Intent;action=android.intent.action.SHOW_ALARMS;end',
    webFallback: '#alarm',
    description: 'Set wake-up alarms, timers & stopwatches',
    browserSupportLevel: 'native_intent',
  },
  {
    id: 'calendar',
    name: 'Calendar',
    nepaliName: 'क्यालेन्डर / पात्रो',
    icon: 'Calendar',
    category: 'utility',
    packageName: 'com.google.android.calendar',
    intentUri: 'intent:#Intent;action=android.intent.action.VIEW;type=time/epoch;end',
    webFallback: 'https://calendar.google.com',
    description: 'Manage appointments, events & holidays',
    browserSupportLevel: 'native_intent',
  },
  {
    id: 'calculator',
    name: 'Calculator',
    nepaliName: 'क्यालकुलेटर',
    icon: 'Calculator',
    category: 'tools',
    packageName: 'com.google.android.calculator',
    intentUri: 'intent:#Intent;action=android.intent.action.MAIN;category=android.intent.category.APP_CALCULATOR;end',
    webFallback: 'https://www.google.com/search?q=calculator',
    description: 'Quick math, calculations & conversions',
    browserSupportLevel: 'native_intent',
  },
  {
    id: 'chrome',
    name: 'Chrome Browser',
    nepaliName: 'क्रोम ब्राउजर',
    icon: 'Globe',
    category: 'utility',
    packageName: 'com.android.chrome',
    intentUri: 'googlechrome://',
    webFallback: 'https://www.google.com',
    description: 'Fast internet browsing & web search',
    browserSupportLevel: 'deep_link',
  },
  {
    id: 'settings',
    name: 'Android Settings',
    nepaliName: 'सेटिङहरू',
    icon: 'Settings',
    category: 'system',
    packageName: 'com.android.settings',
    intentUri: 'intent:#Intent;action=android.settings.SETTINGS;end',
    webFallback: '#settings',
    description: 'Wi-Fi, Bluetooth, Display, Sound',
    browserSupportLevel: 'native_intent',
  },
];

// Play synthetic feedback chime
export function playChime(type: 'success' | 'alert' | 'start' | 'alarm' = 'success') {
  try {
    const AudioContextClass = window.AudioContext || (window as any).webkitAudioContext;
    if (!AudioContextClass) return;
    const ctx = new AudioContextClass();
    const now = ctx.currentTime;

    const osc = ctx.createOscillator();
    const gain = ctx.createGain();
    osc.connect(gain);
    gain.connect(ctx.destination);

    if (type === 'start') {
      osc.type = 'sine';
      osc.frequency.setValueAtTime(440, now);
      osc.frequency.exponentialRampToValueAtTime(880, now + 0.15);
      gain.gain.setValueAtTime(0.15, now);
      gain.gain.exponentialRampToValueAtTime(0.01, now + 0.25);
      osc.start(now);
      osc.stop(now + 0.25);
    } else if (type === 'success') {
      osc.type = 'sine';
      osc.frequency.setValueAtTime(523.25, now);
      osc.frequency.setValueAtTime(659.25, now + 0.08);
      osc.frequency.setValueAtTime(783.99, now + 0.16);
      gain.gain.setValueAtTime(0.2, now);
      gain.gain.exponentialRampToValueAtTime(0.01, now + 0.35);
      osc.start(now);
      osc.stop(now + 0.35);
    } else if (type === 'alert') {
      osc.type = 'triangle';
      osc.frequency.setValueAtTime(320, now);
      osc.frequency.setValueAtTime(240, now + 0.12);
      gain.gain.setValueAtTime(0.2, now);
      gain.gain.exponentialRampToValueAtTime(0.01, now + 0.3);
      osc.start(now);
      osc.stop(now + 0.3);
    } else if (type === 'alarm') {
      osc.type = 'sawtooth';
      osc.frequency.setValueAtTime(800, now);
      osc.frequency.setValueAtTime(950, now + 0.2);
      osc.frequency.setValueAtTime(800, now + 0.4);
      osc.frequency.setValueAtTime(950, now + 0.6);
      gain.gain.setValueAtTime(0.3, now);
      gain.gain.exponentialRampToValueAtTime(0.01, now + 0.8);
      osc.start(now);
      osc.stop(now + 0.8);
    }
  } catch (err) {
    console.warn('Audio chime unsupported or blocked:', err);
  }
}

// Trigger haptic vibration on Android devices
export function triggerHaptic(duration = 45) {
  try {
    if (typeof window !== 'undefined' && 'vibrate' in navigator) {
      navigator.vibrate(duration);
    }
  } catch {
    // Ignore if vibration is restricted
  }
}

// Send local Android notification if authorized
export async function sendAndroidNotification(title: string, body: string): Promise<boolean> {
  if (typeof window === 'undefined' || !('Notification' in window)) {
    return false;
  }

  if (Notification.permission === 'granted') {
    new Notification(title, {
      body,
      icon: '/icon.svg',
      badge: '/icon.svg',
    });
    return true;
  } else if (Notification.permission !== 'denied') {
    const res = await Notification.requestPermission();
    if (res === 'granted') {
      new Notification(title, {
        body,
        icon: '/icon.svg',
      });
      return true;
    }
  }
  return false;
}

/**
 * Executes Phone Call via Android Dialer handoff
 * Strictly truthful: The browser can only prefill the dialer via tel: URI.
 * It CANNOT press the dial button or verify that the carrier connected the call.
 */
export function executePhoneCall(phoneNumber: string, contactName?: string): ActionExecutionDetail {
  const cleanNumber = phoneNumber.replace(/[^0-9+*#]/g, '');
  const url = `tel:${cleanNumber}`;

  triggerHaptic(60);

  try {
    window.location.href = url;
    return {
      success: true,
      status: 'dispatched_dialer',
      userMessage: `Handed off ${cleanNumber} to Android Phone Dialer`,
      nepaliMessage: `एन्ड्रोइड फोन डायलर खोलिएको छ। कृपया कल गर्न हरियो बटन थिच्नुहोस्।`,
      methodUsed: 'dialer',
      whatActuallyHappened: `The browser invoked the system tel:${cleanNumber} URI. Android opened the phone dialer with the number prefilled. For security reasons, web browsers cannot press the dial button or monitor carrier calls.`,
      whatRequiresNativeAPK: `Placing calls automatically in the background without user tapping the dial button requires a native Android APK with android.permission.CALL_PHONE.`,
      requiredPermission: 'android.permission.CALL_PHONE',
    };
  } catch (err: any) {
    return {
      success: false,
      status: 'unsupported_in_browser',
      userMessage: `Failed to open phone dialer: ${err.message}`,
      nepaliMessage: `फोन डायलर खोल्न सकिएन।`,
      methodUsed: 'dialer',
      whatActuallyHappened: `System blocked the tel: URI protocol handler.`,
      requiredPermission: 'android.permission.CALL_PHONE',
    };
  }
}

/**
 * Opens an Android app via Android Intent URI or registered scheme with web fallback
 * Accurately tracks whether intent handoff was triggered.
 */
export function executeOpenApp(
  appName: string,
  packageName?: string,
  fallbackUrl?: string
): ActionExecutionDetail {
  triggerHaptic(40);

  const target = POPULAR_ANDROID_APPS.find(
    (a) =>
      a.name.toLowerCase().includes(appName.toLowerCase()) ||
      appName.toLowerCase().includes(a.name.toLowerCase()) ||
      a.id.toLowerCase() === appName.toLowerCase()
  );

  const fallback = target?.webFallback || fallbackUrl || `https://www.google.com/search?q=${encodeURIComponent(appName)}`;
  const intentUri = target?.intentUri || (packageName ? `intent://#Intent;package=${packageName};end` : null);

  let launchedMethod: 'intent' | 'scheme' | 'web_fallback' = 'intent';

  if (target?.id === 'youtube') {
    // For YouTube on Android, use vnd.youtube:// or direct intent
    try {
      window.location.href = 'vnd.youtube://';
      launchedMethod = 'scheme';
    } catch {
      window.location.href = intentUri || fallback;
    }
  } else if (target?.id === 'whatsapp') {
    window.open('https://wa.me/', '_blank');
    launchedMethod = 'scheme';
  } else if (intentUri && !intentUri.startsWith('#')) {
    try {
      window.location.href = intentUri;
    } catch {
      window.open(fallback, '_blank');
      launchedMethod = 'web_fallback';
    }
  } else {
    window.open(fallback, '_blank');
    launchedMethod = 'web_fallback';
  }

  return {
    success: true,
    status: 'app_launched',
    userMessage: `Dispatched launch request for ${target?.name || appName}`,
    nepaliMessage: `${target?.nepaliName || appName} खोल्न अनुरोध पठाइयो।`,
    methodUsed: launchedMethod,
    whatActuallyHappened: `Dispatched Android Intent and URL scheme. If the native app is installed on your Android device, it opens immediately. Otherwise, the official web version opens as fallback.`,
    whatRequiresNativeAPK: `Querying whether the app is installed before launching requires android.permission.QUERY_ALL_PACKAGES in a native Android APK wrapper.`,
    requiredPermission: 'android.permission.QUERY_ALL_PACKAGES / <queries>',
  };
}

/**
 * Sets an Alarm using Android DeskClock SET_ALARM Intent
 * Strictly truthful: Informs user that the intent was sent to Android Clock.
 */
export function executeSetAlarm(
  hours: number,
  minutes: number,
  label: string = 'Mero AI Sathi Alarm'
): ActionExecutionDetail {
  triggerHaptic(60);
  const timeFormatted = `${String(hours).padStart(2, '0')}:${String(minutes).padStart(2, '0')}`;

  const androidIntent = `intent:#Intent;action=android.intent.action.SET_ALARM;i.android.intent.extra.HOUR=${hours};i.android.intent.extra.MINUTES=${minutes};S.android.intent.extra.MESSAGE=${encodeURIComponent(label)};B.android.intent.extra.SKIP_UI=false;end`;

  try {
    window.location.href = androidIntent;
    return {
      success: true,
      status: 'dispatched_intent',
      userMessage: `Dispatched alarm for ${timeFormatted} to Android Clock`,
      nepaliMessage: `${timeFormatted} को अलार्म एन्ड्रोइड घडी एपमा पठाइएको छ।`,
      methodUsed: 'intent',
      whatActuallyHappened: `Sent android.intent.action.SET_ALARM intent to pre-fill the native Android Clock app. Web browsers cannot directly insert rows into the system AlarmManager database.`,
      whatRequiresNativeAPK: `Creating silent hardware alarms that wake the CPU from deep sleep without opening the Clock app requires com.android.alarm.permission.SET_ALARM and Android AlarmManager in a native APK.`,
      requiredPermission: 'com.android.alarm.permission.SET_ALARM',
    };
  } catch (err: any) {
    return {
      success: false,
      status: 'unsupported_in_browser',
      userMessage: `Could not dispatch SET_ALARM intent: ${err.message}`,
      nepaliMessage: `एन्ड्रोइड घडी एपमा अलार्म पठाउन सकिएन।`,
      methodUsed: 'intent',
      whatActuallyHappened: `Intent invocation failed. Use the built-in assistant timer instead.`,
    };
  }
}

/**
 * Sends messages via WhatsApp or SMS
 */
export function executeSendMessage(
  recipient: string,
  text: string,
  platform: 'whatsapp' | 'sms' = 'sms'
): ActionExecutionDetail {
  const cleanNumber = recipient.replace(/[^0-9+]/g, '');
  triggerHaptic(50);

  if (platform === 'whatsapp') {
    const url = `https://wa.me/${cleanNumber}?text=${encodeURIComponent(text)}`;
    window.open(url, '_blank');
    return {
      success: true,
      status: 'dispatched_intent',
      userMessage: `Opened WhatsApp with pre-filled message for ${cleanNumber}`,
      nepaliMessage: `ह्वाट्सएपमा सन्देश पूर्व-तयार गरिएको छ। कृपया पठाउन सेन्ड बटन थिच्नुहोस्।`,
      methodUsed: 'scheme',
      whatActuallyHappened: `Opened WhatsApp chat with the text pre-filled. Browser sandbox prevents auto-transmitting messages.`,
      whatRequiresNativeAPK: `Automated background messaging without user review requires native WhatsApp Business API or Android AccessibilityService.`,
    };
  } else {
    const url = `sms:${cleanNumber}?body=${encodeURIComponent(text)}`;
    window.location.href = url;
    return {
      success: true,
      status: 'dispatched_intent',
      userMessage: `Opened SMS composer with pre-filled message for ${cleanNumber}`,
      nepaliMessage: `एसएमएस एपमा सन्देश तयार गरिएको छ। पठाउन सेन्ड थिच्नुहोस्।`,
      methodUsed: 'scheme',
      whatActuallyHappened: `Opened Android SMS composer with recipient and message. Browser cannot silently send background SMS.`,
      whatRequiresNativeAPK: `Sending background SMS silently without opening the SMS app requires android.permission.SEND_SMS in a native APK.`,
      requiredPermission: 'android.permission.SEND_SMS',
    };
  }
}
