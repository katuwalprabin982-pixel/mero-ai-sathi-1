import { ActionPayload, CommandClassification } from '../types/assistant';

/**
 * Intelligent Command Router for Mero AI Sathi
 * Accurately distinguishes actionable Android commands from ordinary conversation.
 * Handles both Nepali (Devanagari / Romanized) and English syntax.
 */

// Informational question indicators that indicate pure CHAT rather than ACTION
const INFORMATIONAL_QUESTION_REGEX = /(के हो|कसले बनाएको|किन|कसरी|इतिहास|अर्थ के हो|कहिले|बताउनुहोस्|बुझाइदिनुहोस्|जानकारी|what is|who created|who made|how does|why is|explain|meaning of|history of|tell me about)/i;

// Action keywords in Nepali & English
const APP_LAUNCH_VERBS = /(खोल|खोलिदेऊ|खोल्नुहोस्|सुरु गर|चलाऊ|open|launch|start|run)/i;
const CALL_VERBS = /(कल गर|फोन गर|फोन लगाऊ|कल लगाऊ|डायल गर|कल जोडिदेऊ|call|dial|phone)/i;
const ALARM_VERBS = /(अलार्म राख|अलार्म सेट गर|अलार्म लगाऊ|उठाऊ|ब्यूँझाऊ|set alarm|alarm for|wake me up)/i;
const TIMER_VERBS = /(टाइमर राख|टाइमर सुरु गर|टाइमर सेट गर|मिनेटको टाइमर|timer for|set timer|start timer|countdown)/i;
const MESSAGE_VERBS = /(सन्देश पठाऊ|मेसेज गर|ह्वाट्सएप गर|एसएमएस गर|send message|text|whatsapp)/i;
const SEARCH_VERBS = /(खोज्नुहोस्|खोज|गुगल गर|समाचार के छ|मौसम कस्तो छ|search for|google|look up|what's the weather|latest news)/i;

export function routeCommand(userInput: string): CommandClassification {
  const trimmed = userInput.trim();
  const lower = trimmed.toLowerCase();

  // 1. Check if user is asking an informational / explanatory question about an app or feature
  const isQuestion = INFORMATIONAL_QUESTION_REGEX.test(trimmed) && !trimmed.endsWith('!') && !lower.includes('please open');

  // If it's a "what is YouTube" or "how does alarm work", it is pure CHAT
  if (isQuestion && !lower.startsWith('open ') && !lower.startsWith('call ') && !lower.startsWith('set ')) {
    return {
      isAction: false,
      intentType: 'CHAT',
      confidence: 0.9,
      reason: 'User is asking an informational question rather than requesting a device action.',
      browserSupport: 'full',
      browserCapabilityNote: 'Answered directly by the AI conversational model.',
    };
  }

  // 2. Detect Phone Call intent
  if (CALL_VERBS.test(trimmed) || lower.startsWith('call ') || lower.startsWith('dial ')) {
    // Extract phone number or contact
    const numMatch = trimmed.match(/(\+?[0-9]{3,14})/);
    const hasEmergency = /100|101|102|103|112/.test(trimmed);
    const phoneNumber = numMatch ? numMatch[1] : (hasEmergency ? trimmed.match(/100|101|102|103|112/)?.[0] : '');

    let contactName = '';
    if (trimmed.includes('आमा') || lower.includes('mom') || lower.includes('mother')) contactName = 'आमा (Mom)';
    else if (trimmed.includes('बुबा') || lower.includes('dad') || lower.includes('father')) contactName = 'बुबा (Dad)';
    else if (trimmed.includes('प्रहरी') || lower.includes('police')) contactName = 'नेपाल प्रहरी (Police - 100)';
    else if (trimmed.includes('एम्बुलेन्स') || lower.includes('ambulance')) contactName = 'एम्बुलेन्स (102)';
    else if (trimmed.includes('साथी') || lower.includes('friend')) contactName = 'साथी (Friend)';

    return {
      isAction: true,
      intentType: 'CALL',
      confidence: phoneNumber ? 0.95 : 0.85,
      reason: 'User explicitly requested to initiate a phone call.',
      detectedParams: {
        phoneNumber: phoneNumber || '9801234567',
        contactName,
      },
      browserSupport: 'handoff_dialer',
      browserCapabilityNote:
        'Supported via Android "tel:" URL scheme handoff to the Phone Dialer. Browser security policies prevent auto-dialing in the background; user must tap "Call" in the dialer. Silent background calls require native Android APK with CALL_PHONE permission.',
    };
  }

  // 3. Detect Alarm intent
  if (ALARM_VERBS.test(trimmed) || (trimmed.includes('अलार्म') && !isQuestion) || lower.startsWith('set alarm')) {
    const timeMatch = trimmed.match(/([0-9]{1,2})(:([0-9]{2}))?\s*(am|pm|बजे)?/i);
    let hours = 6;
    let minutes = 30;

    if (timeMatch) {
      hours = parseInt(timeMatch[1], 10);
      minutes = timeMatch[3] ? parseInt(timeMatch[3], 10) : 0;
      if (lower.includes('pm') && hours < 12) hours += 12;
      if (lower.includes('am') && hours === 12) hours = 0;
    }

    const formattedTime = `${String(hours).padStart(2, '0')}:${String(minutes).padStart(2, '0')}`;

    return {
      isAction: true,
      intentType: 'SET_ALARM',
      confidence: 0.95,
      reason: 'User requested to set a wake-up or schedule alarm.',
      detectedParams: {
        time: formattedTime,
        hours,
        minutes,
        label: 'Mero AI Sathi Alarm',
      },
      browserSupport: 'intent_handoff',
      browserCapabilityNote:
        'Dispatches an Android SET_ALARM intent to prefill the Android Clock app. Browsers cannot modify the system alarm database directly or wake device from deep sleep without native Android AlarmManager and SET_ALARM permission.',
    };
  }

  // 4. Detect Timer intent
  if (TIMER_VERBS.test(trimmed) || (trimmed.includes('टाइमर') && !isQuestion) || lower.includes('timer for')) {
    const minMatch = trimmed.match(/([0-9]+)\s*(मिनेट|मिनट|min|minute|सेकेन्ड|sec|second)/i);
    let seconds = 300; // default 5 min
    let label = 'Assistant Timer';

    if (minMatch) {
      const val = parseInt(minMatch[1], 10);
      const unit = minMatch[2].toLowerCase();
      if (unit.includes('सेकेन्ड') || unit.includes('sec')) {
        seconds = val;
        label = `${val} Second Timer`;
      } else {
        seconds = val * 60;
        label = `${val} Minute Timer`;
      }
    }

    return {
      isAction: true,
      intentType: 'SET_TIMER',
      confidence: 0.95,
      reason: 'User requested a countdown timer.',
      detectedParams: {
        seconds,
        label,
      },
      browserSupport: 'in_app_only',
      browserCapabilityNote:
        'Runs directly in the browser via Web Audio synthesizer and Web Notification API. Fully functional while page/PWA is active.',
    };
  }

  // 5. Detect App Launch intent (YouTube, WhatsApp, Maps, Camera, Calculator, Settings, etc.)
  if (APP_LAUNCH_VERBS.test(trimmed) || lower.startsWith('open ') || lower.startsWith('launch ')) {
    const appMap: Record<string, { appName: string; package: string; fallbackUrl: string }> = {
      youtube: { appName: 'YouTube', package: 'com.google.android.youtube', fallbackUrl: 'https://www.youtube.com' },
      युट्युब: { appName: 'YouTube', package: 'com.google.android.youtube', fallbackUrl: 'https://www.youtube.com' },
      whatsapp: { appName: 'WhatsApp', package: 'com.whatsapp', fallbackUrl: 'https://web.whatsapp.com' },
      ह्वाट्सएप: { appName: 'WhatsApp', package: 'com.whatsapp', fallbackUrl: 'https://web.whatsapp.com' },
      maps: { appName: 'Google Maps', package: 'com.google.android.apps.maps', fallbackUrl: 'https://maps.google.com' },
      म्याप्स: { appName: 'Google Maps', package: 'com.google.android.apps.maps', fallbackUrl: 'https://maps.google.com' },
      म्याप: { appName: 'Google Maps', package: 'com.google.android.apps.maps', fallbackUrl: 'https://maps.google.com' },
      camera: { appName: 'Camera', package: 'com.google.android.GoogleCamera', fallbackUrl: 'intent:#Intent;action=android.media.action.IMAGE_CAPTURE;end' },
      क्यामेरा: { appName: 'Camera', package: 'com.google.android.GoogleCamera', fallbackUrl: 'intent:#Intent;action=android.media.action.IMAGE_CAPTURE;end' },
      calculator: { appName: 'Calculator', package: 'com.google.android.calculator', fallbackUrl: 'https://www.google.com/search?q=calculator' },
      क्यालकुलेटर: { appName: 'Calculator', package: 'com.google.android.calculator', fallbackUrl: 'https://www.google.com/search?q=calculator' },
      calendar: { appName: 'Calendar', package: 'com.google.android.calendar', fallbackUrl: 'https://calendar.google.com' },
      पात्रो: { appName: 'Calendar', package: 'com.google.android.calendar', fallbackUrl: 'https://calendar.google.com' },
      क्यालेन्डर: { appName: 'Calendar', package: 'com.google.android.calendar', fallbackUrl: 'https://calendar.google.com' },
      chrome: { appName: 'Chrome Browser', package: 'com.android.chrome', fallbackUrl: 'https://www.google.com' },
      क्रोम: { appName: 'Chrome Browser', package: 'com.android.chrome', fallbackUrl: 'https://www.google.com' },
      clock: { appName: 'Clock', package: 'com.google.android.deskclock', fallbackUrl: 'intent:#Intent;action=android.intent.action.SHOW_ALARMS;end' },
      घडी: { appName: 'Clock', package: 'com.google.android.deskclock', fallbackUrl: 'intent:#Intent;action=android.intent.action.SHOW_ALARMS;end' },
      settings: { appName: 'Android Settings', package: 'com.android.settings', fallbackUrl: 'intent:#Intent;action=android.settings.SETTINGS;end' },
      सेटिङ: { appName: 'Android Settings', package: 'com.android.settings', fallbackUrl: 'intent:#Intent;action=android.settings.SETTINGS;end' },
    };

    for (const [key, details] of Object.entries(appMap)) {
      if (lower.includes(key)) {
        return {
          isAction: true,
          intentType: 'OPEN_APP',
          confidence: 0.95,
          reason: `User requested to launch ${details.appName}.`,
          detectedParams: details,
          browserSupport: 'intent_handoff',
          browserCapabilityNote:
            'Dispatches Android package intent URI (intent://). If the native app is not installed, automatically opens the official web fallback.',
        };
      }
    }
  }

  // 6. Detect Send Message intent
  if (MESSAGE_VERBS.test(trimmed)) {
    const numMatch = trimmed.match(/(\+?[0-9]{3,14})/);
    const isWhatsapp = trimmed.includes('ह्वाट्सएप') || lower.includes('whatsapp');
    const recipient = numMatch ? numMatch[1] : '9801234567';

    // Extract text after 'भनेर' or 'saying'
    let text = 'नमस्ते, म मेरो एआई साथी मार्फत सन्देश पठाउँदैछु।';
    const msgExtract = trimmed.match(/(भनेर|saying|texting)\s+(.*)/i);
    if (msgExtract && msgExtract[2]) {
      text = msgExtract[2].trim();
    }

    const isDraft = /ड्राफ्ट|मस्यौदा|draft|prepare/i.test(trimmed);

    return {
      isAction: true,
      intentType: isDraft ? 'DRAFT_MESSAGE' : 'SEND_MESSAGE',
      confidence: 0.9,
      reason: isDraft ? 'User requested to draft a message for review.' : 'User requested to send a message via SMS or WhatsApp.',
      detectedParams: {
        recipient,
        text,
        platform: isWhatsapp ? 'whatsapp' : 'sms',
      },
      browserSupport: 'intent_handoff',
      browserCapabilityNote:
        'Opens WhatsApp (wa.me) or Android Messages (sms:) with pre-filled content. The browser cannot transmit messages silently in the background without user tapping "Send". Silent background SMS requires native Android SEND_SMS permission.',
    };
  }

  // 7. Detect Consent-based Memory storage intent ("सम्झिराख कि...", "Remember that...")
  if (/^(सम्झ|सम्झिराख|नोट गर|याद राख|remember that|remember|save fact|note that)/i.test(trimmed)) {
    const memoryFact = trimmed.replace(/^(सम्झ|सम्झिराख|नोट गर|याद राख|कि|remember that|remember|save fact|note that)\s*/i, '').trim();

    return {
      isAction: true,
      intentType: 'SAVE_MEMORY',
      confidence: 0.95,
      reason: 'User requested the assistant to remember a personal preference or fact with consent.',
      detectedParams: {
        memoryFact,
      },
      browserSupport: 'full',
      browserCapabilityNote: 'Saved locally in consent-based assistant memory and applied to future conversations.',
    };
  }

  // 7. Detect explicit search commands
  if (SEARCH_VERBS.test(trimmed) && (trimmed.includes('मौसम') || trimmed.includes('समाचार') || lower.startsWith('search '))) {
    const query = trimmed
      .replace(/खोज्नुहोस्|खोज|गुगल गर|search for|google/gi, '')
      .trim();

    return {
      isAction: true,
      intentType: 'SEARCH_WEB',
      confidence: 0.85,
      reason: 'User requested live internet search.',
      detectedParams: {
        query: query || trimmed,
      },
      browserSupport: 'full',
      browserCapabilityNote: 'Grounded in real-time via Google Search API and returns verified sources.',
    };
  }

  // Default: Pure conversational chat
  return {
    isAction: false,
    intentType: 'CHAT',
    confidence: 0.95,
    reason: 'Conversational interaction without device action requirement.',
    browserSupport: 'full',
    browserCapabilityNote: 'Processed via server-side Gemini 3.8 Flash LLM.',
  };
}
