import { Capacitor } from '@capacitor/core';
import { ActionExecutionDetail, ActionPayload } from '../types/assistant';
import { 
  executePhoneCall, 
  executeOpenApp, 
  executeSetAlarm, 
  executeSendMessage 
} from './androidActions';

/**
 * Native Android Bridge for Mero AI Sathi
 * Detects whether the app is executing inside a Native Android APK (Capacitor / Android Studio)
 * or as a Web PWA inside Android Chrome / Mobile Browser.
 */

export interface PlatformDiagnostics {
  isNative: boolean;
  platform: 'android' | 'ios' | 'web';
  runtimeEnvironment: string;
  hasBackgroundCallPermission: boolean;
  hasHardwareAlarmPermission: boolean;
  hasDirectQueryAllPackages: boolean;
}

export function getPlatformDiagnostics(): PlatformDiagnostics {
  const isNative = Capacitor.isNativePlatform();
  const platform = Capacitor.getPlatform() as 'android' | 'ios' | 'web';

  const userAgent = typeof navigator !== 'undefined' ? navigator.userAgent.toLowerCase() : '';
  const isAndroidBrowser = /android/.test(userAgent);

  let runtimeEnvironment = 'Web Browser';
  if (isNative && platform === 'android') {
    runtimeEnvironment = 'Native Android APK (Capacitor Container)';
  } else if (isAndroidBrowser) {
    runtimeEnvironment = 'Android Chrome / PWA Mobile Sandbox';
  }

  return {
    isNative,
    platform,
    runtimeEnvironment,
    hasBackgroundCallPermission: isNative, // Only true in native APK with CALL_PHONE
    hasHardwareAlarmPermission: isNative,  // Only true in native APK with AlarmManager
    hasDirectQueryAllPackages: isNative,   // Only true in native APK with QUERY_ALL_PACKAGES
  };
}

/**
 * Execute Android Action with Platform-Aware Feedback
 * Strictly truthful: Never claims silent background success if running in browser sandbox.
 */
export async function executePlatformAction(
  action: ActionPayload,
  onStartInAppTimer?: (seconds: number, label: string) => void
): Promise<ActionExecutionDetail> {
  const diag = getPlatformDiagnostics();

  switch (action.type) {
    case 'CALL': {
      const phoneNumber = action.params.phoneNumber || '';
      const contactName = action.params.contactName;

      // In browser or PWA, invoke tel: URI (opens system dialer)
      const detail = executePhoneCall(phoneNumber, contactName);
      if (diag.isNative) {
        detail.whatActuallyHappened += ' [Running in Native Container]';
      }
      return detail;
    }

    case 'OPEN_APP': {
      const appName = action.params.appName || 'App';
      const packageName = action.params.package;
      const fallbackUrl = action.params.fallbackUrl;

      return executeOpenApp(appName, packageName, fallbackUrl);
    }

    case 'SET_ALARM': {
      const hours = action.params.hours ?? 6;
      const minutes = action.params.minutes ?? 30;
      const label = action.params.label || 'Mero AI Sathi Alarm';

      const detail = executeSetAlarm(hours, minutes, label);

      // In browser, also initiate in-app timer as backup
      if (onStartInAppTimer) {
        const now = new Date();
        const target = new Date();
        target.setHours(hours, minutes, 0, 0);
        if (target.getTime() <= now.getTime()) {
          target.setDate(target.getDate() + 1);
        }
        const diffSecs = Math.floor((target.getTime() - now.getTime()) / 1000);
        if (diffSecs > 0 && diffSecs <= 86400) {
          onStartInAppTimer(Math.min(diffSecs, 3600), label);
        }
      }

      return detail;
    }

    case 'SET_TIMER': {
      const seconds = action.params.seconds || 300;
      const label = action.params.label || 'Timer';

      if (onStartInAppTimer) {
        onStartInAppTimer(seconds, label);
      }

      return {
        success: true,
        status: 'timer_active',
        userMessage: `Started ${label} (${seconds}s)`,
        nepaliMessage: `${label} सुरु भयो। घण्टी र सूचना दिइनेछ।`,
        methodUsed: 'web_audio',
        whatActuallyHappened: 'Running active in-app timer via Web Audio API chime & Notification API.',
      };
    }

    case 'SEND_MESSAGE': {
      const recipient = action.params.recipient || '';
      const text = action.params.text || '';
      const platform = action.params.platform || 'whatsapp';

      return executeSendMessage(recipient, text, platform);
    }

    case 'SEARCH_WEB': {
      const query = action.params.query || '';
      window.open(`https://www.google.com/search?q=${encodeURIComponent(query)}`, '_blank');
      return {
        success: true,
        status: 'executed',
        userMessage: `Searched Google for: ${query}`,
        nepaliMessage: `गुगल खोजी नयाँ विन्डोमा खोलिएको छ।`,
        methodUsed: 'browser_api',
        whatActuallyHappened: 'Opened verified Google web search query in browser.',
      };
    }

    default:
      return {
        success: false,
        status: 'unsupported_in_browser',
        userMessage: 'Unrecognized action type',
        nepaliMessage: 'अज्ञात कार्य प्रकार',
        methodUsed: 'browser_api',
        whatActuallyHappened: 'No matching action handler found.',
      };
  }
}
