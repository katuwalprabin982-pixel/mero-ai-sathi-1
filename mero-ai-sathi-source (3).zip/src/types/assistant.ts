export type LanguageMode = 'auto' | 'ne' | 'en';

export type ActionStatus = 
  | 'pending'
  | 'confirmed'
  | 'cancelled'
  | 'dispatched_dialer'
  | 'dispatched_intent'
  | 'timer_active'
  | 'app_launched'
  | 'executed'
  | 'unsupported_in_browser';

export interface ActionExecutionDetail {
  success: boolean;
  status: ActionStatus;
  userMessage: string;
  nepaliMessage: string;
  methodUsed: 'intent' | 'scheme' | 'web_fallback' | 'web_audio' | 'dialer' | 'browser_api';
  whatActuallyHappened: string;
  whatRequiresNativeAPK?: string;
  requiredPermission?: string;
}

export interface UserMemoryItem {
  id: string;
  fact: string;
  category: 'preference' | 'personal' | 'routine';
  createdAt: number;
}

export interface ActionPayload {
  type: 'CALL' | 'SET_ALARM' | 'OPEN_APP' | 'SEND_MESSAGE' | 'DRAFT_MESSAGE' | 'SET_TIMER' | 'SEARCH_WEB' | 'OPEN_URL' | 'SAVE_MEMORY';
  title: string;
  description: string;
  sensitive: boolean;
  status?: ActionStatus;
  executionDetail?: ActionExecutionDetail;
  params: {
    phoneNumber?: string;
    contactName?: string;
    time?: string;
    hours?: number;
    minutes?: number;
    label?: string;
    appName?: string;
    package?: string;
    fallbackUrl?: string;
    recipient?: string;
    text?: string;
    platform?: 'whatsapp' | 'sms';
    seconds?: number;
    query?: string;
    url?: string;
    memoryFact?: string;
    [key: string]: any;
  };
}

export interface SearchSource {
  title: string;
  url: string;
}

export interface CommandClassification {
  isAction: boolean;
  intentType: ActionPayload['type'] | 'CHAT';
  confidence: number;
  reason: string;
  detectedParams?: Record<string, any>;
  browserSupport: 'full' | 'handoff_dialer' | 'intent_handoff' | 'in_app_only' | 'native_only';
  browserCapabilityNote: string;
}

export interface Message {
  id: string;
  role: 'user' | 'assistant';
  content: string;
  timestamp: number;
  action?: ActionPayload;
  classification?: CommandClassification;
  searchSources?: SearchSource[];
  searchQueries?: string[];
  audioBase64?: string;
  isSpoken?: boolean;
}

export interface UserPreferences {
  hasGivenConsent: boolean;
  userName: string;
  language: LanguageMode;
  speechInputLanguage: 'ne-NP' | 'en-US' | 'en-IN';
  autoSpeakReplies: boolean;
  ttsEngine: 'gemini' | 'browser';
  geminiVoice: 'Kore' | 'Zephyr' | 'Puck' | 'Fenrir';
  speechRate: number;
  speechPitch: number;
  hapticFeedback: boolean;
  saveHistory: boolean;
  enableMemory: boolean;
  userMemories: UserMemoryItem[];
  highContrast: boolean;
}

export interface AndroidAppShortcut {
  id: string;
  name: string;
  nepaliName: string;
  icon: string;
  category: 'social' | 'tools' | 'utility' | 'system';
  packageName: string;
  intentUri: string;
  webFallback: string;
  description: string;
  deepLinkScheme?: string;
  browserSupportLevel: 'native_intent' | 'deep_link' | 'web_redirect';
}

export interface ActiveAssistantTimer {
  id: string;
  label: string;
  totalSeconds: number;
  remainingSeconds: number;
  isRunning: boolean;
  createdAt: number;
}
