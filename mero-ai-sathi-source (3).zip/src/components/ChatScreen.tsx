import React, { useState, useRef, useEffect } from 'react';
import { 
  Send, 
  Mic, 
  Volume2, 
  ExternalLink, 
  Phone, 
  AlarmClock, 
  MessageSquare, 
  Search, 
  CheckCircle2, 
  XCircle, 
  Clock, 
  Sparkles,
  Bot,
  User,
  Copy,
  Check,
  Globe,
  Info,
  Layers,
  ShieldCheck,
  Play
} from 'lucide-react';
import { motion } from 'motion/react';
import { Message, ActionPayload, UserPreferences, ActionStatus } from '../types/assistant';

interface ChatScreenProps {
  messages: Message[];
  isLoading: boolean;
  onSendMessage: (text: string) => void;
  onActionClick: (action: ActionPayload, messageId: string) => void;
  onSpeakMessage: (text: string) => void;
  isSpeaking: boolean;
  onToggleListening: () => void;
  isListening: boolean;
  preferences: UserPreferences;
}

export const ChatScreen: React.FC<ChatScreenProps> = ({
  messages,
  isLoading,
  onSendMessage,
  onActionClick,
  onSpeakMessage,
  isSpeaking,
  onToggleListening,
  isListening,
  preferences,
}) => {
  const [inputText, setInputText] = useState('');
  const [copiedId, setCopiedId] = useState<string | null>(null);
  const messagesEndRef = useRef<HTMLDivElement | null>(null);
  const inputRef = useRef<HTMLInputElement | null>(null);

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages, isLoading]);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!inputText.trim() || isLoading) return;
    onSendMessage(inputText);
    setInputText('');
  };

  const handleCopy = (id: string, text: string) => {
    navigator.clipboard.writeText(text);
    setCopiedId(id);
    setTimeout(() => setCopiedId(null), 2000);
  };

  const getActionIcon = (type: string) => {
    switch (type) {
      case 'CALL':
        return <Phone className="w-4 h-4 text-emerald-400" />;
      case 'SET_ALARM':
      case 'SET_TIMER':
        return <AlarmClock className="w-4 h-4 text-amber-400" />;
      case 'SEND_MESSAGE':
        return <MessageSquare className="w-4 h-4 text-cyan-400" />;
      case 'SEARCH_WEB':
        return <Search className="w-4 h-4 text-sky-400" />;
      case 'OPEN_APP':
        return <Layers className="w-4 h-4 text-indigo-400" />;
      default:
        return <ExternalLink className="w-4 h-4 text-sky-400" />;
    }
  };

  const renderStatusPill = (status?: ActionStatus) => {
    switch (status) {
      case 'dispatched_dialer':
        return (
          <span className="flex items-center gap-1 text-[10px] font-semibold text-emerald-300 bg-emerald-950/80 px-2 py-0.5 rounded-full border border-emerald-500/40">
            <CheckCircle2 className="w-3 h-3 text-emerald-400" /> डायलरमा पठाइयो (Dialer Opened)
          </span>
        );
      case 'dispatched_intent':
        return (
          <span className="flex items-center gap-1 text-[10px] font-semibold text-sky-300 bg-sky-950/80 px-2 py-0.5 rounded-full border border-sky-500/40">
            <CheckCircle2 className="w-3 h-3 text-sky-400" /> इन्टेन्ट पठाइयो (Intent Dispatched)
          </span>
        );
      case 'timer_active':
        return (
          <span className="flex items-center gap-1 text-[10px] font-semibold text-amber-300 bg-amber-950/80 px-2 py-0.5 rounded-full border border-amber-500/40 animate-pulse">
            <AlarmClock className="w-3 h-3 text-amber-400" /> टाइमर सक्रिय (Timer Active)
          </span>
        );
      case 'app_launched':
        return (
          <span className="flex items-center gap-1 text-[10px] font-semibold text-cyan-300 bg-cyan-950/80 px-2 py-0.5 rounded-full border border-cyan-500/40">
            <CheckCircle2 className="w-3 h-3 text-cyan-400" /> एप सुरु भयो (App Launched)
          </span>
        );
      case 'executed':
        return (
          <span className="flex items-center gap-1 text-[10px] font-semibold text-emerald-400 bg-emerald-950/80 px-2 py-0.5 rounded-full border border-emerald-500/30">
            <CheckCircle2 className="w-3 h-3" /> सम्पन्न (Executed)
          </span>
        );
      case 'cancelled':
        return (
          <span className="flex items-center gap-1 text-[10px] font-semibold text-slate-400 bg-slate-900 px-2 py-0.5 rounded-full border border-slate-700">
            <XCircle className="w-3 h-3" /> रद्द (Cancelled)
          </span>
        );
      default:
        return (
          <span className="flex items-center gap-1 text-[10px] font-semibold text-amber-300 bg-amber-950/80 px-2 py-0.5 rounded-full border border-amber-500/30">
            <Clock className="w-3 h-3" /> अनुमोदन पर्खँदै (Waiting for Approval)
          </span>
        );
    }
  };

  return (
    <div className="flex-1 flex flex-col w-full max-w-3xl mx-auto px-3 sm:px-4 py-2">
      {/* Message List */}
      <div className="flex-1 space-y-4 overflow-y-auto pb-4">
        {messages.length === 0 ? (
          <div className="py-8 px-4 text-center flex flex-col items-center justify-center">
            <div className="w-14 h-14 rounded-2xl bg-sky-500/10 border border-sky-500/20 flex items-center justify-center mb-3 glow-blue">
              <Bot className="w-7 h-7 text-sky-400" />
            </div>
            <h2 className="text-base sm:text-lg font-bold text-white mb-1">
              नमस्ते! म तपाईंको मेरो एआई साथी हुँ।
            </h2>
            <p className="text-xs sm:text-sm text-sky-300/80 max-w-md mx-auto leading-relaxed">
              तपाईं मलाई नेपाली वा अंग्रेजीमा जुनसुकै कुरा सोध्न सक्नुहुन्छ, फोन कल गर्न, अलार्म राख्न वा इन्टरनेटमा जानकारी खोज्न सक्नुहुन्छ।
            </p>
          </div>
        ) : (
          messages.map((message) => {
            const isUser = message.role === 'user';
            return (
              <motion.div
                key={message.id}
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                className={`flex gap-2.5 sm:gap-3 ${isUser ? 'justify-end' : 'justify-start'}`}
              >
                {!isUser && (
                  <div className="w-8 h-8 rounded-xl bg-gradient-to-br from-sky-500 to-blue-700 flex items-center justify-center text-white shrink-0 shadow-md shadow-sky-500/20 border border-sky-400/30">
                    <Sparkles className="w-4 h-4 text-sky-100" />
                  </div>
                )}

                <div
                  className={`flex flex-col max-w-[85%] sm:max-w-[80%] ${
                    isUser ? 'items-end' : 'items-start'
                  }`}
                >
                  {/* Bubble */}
                  <div
                    className={`rounded-2xl px-4 py-3 shadow-md ${
                      isUser
                        ? 'bg-gradient-to-r from-sky-600 to-blue-600 text-white rounded-br-xs'
                        : 'glass-panel text-slate-100 border border-sky-500/20 rounded-bl-xs'
                    }`}
                  >
                    {/* Command Router Diagnostic Badge */}
                    {message.classification && message.classification.isAction && (
                      <div className="flex items-center gap-1.5 mb-2 pb-1.5 border-b border-sky-500/20 text-[10px] text-sky-300 font-mono">
                        <ShieldCheck className="w-3 h-3 text-sky-400" />
                        <span>Command Routed: {message.classification.intentType}</span>
                        <span className="text-slate-400">({Math.round(message.classification.confidence * 100)}% confidence)</span>
                      </div>
                    )}

                    <div className="text-sm leading-relaxed whitespace-pre-wrap font-normal selection:bg-cyan-500/30">
                      {message.content}
                    </div>

                    {/* Action Card if assistant triggered an action */}
                    {message.action && (
                      <div className="mt-3 p-3.5 rounded-xl bg-slate-900/95 border border-sky-500/30 shadow-lg">
                        <div className="flex items-center justify-between gap-2 mb-2">
                          <div className="flex items-center gap-2">
                            {getActionIcon(message.action.type)}
                            <span className="text-xs font-bold text-white tracking-wide">
                              {message.action.title}
                            </span>
                          </div>

                          {/* Status Pill */}
                          {renderStatusPill(message.action.status)}
                        </div>

                        <p className="text-xs text-sky-200/90 mb-2 leading-relaxed">
                          {message.action.description}
                        </p>

                        {/* Truthful Execution Details & Native APK notes */}
                        {message.action.executionDetail && (
                          <div className="mb-2.5 p-2 rounded-lg bg-slate-950 text-[11px] border border-slate-800 text-slate-300">
                            <p className="text-emerald-400 font-medium mb-0.5">
                              {message.action.executionDetail.nepaliMessage}
                            </p>
                            <p className="text-slate-400">
                              {message.action.executionDetail.whatActuallyHappened}
                            </p>
                            {message.action.executionDetail.whatRequiresNativeAPK && (
                              <p className="text-amber-300/80 mt-1 pt-1 border-t border-slate-800/80 flex items-start gap-1">
                                <Info className="w-3 h-3 shrink-0 mt-0.5" />
                                <span>{message.action.executionDetail.whatRequiresNativeAPK}</span>
                              </p>
                            )}
                          </div>
                        )}

                        {/* Interactive Execution Trigger */}
                        <div className="flex items-center gap-2 pt-1">
                          <button
                            onClick={() => onActionClick(message.action!, message.id)}
                            className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-gradient-to-r from-sky-500 to-blue-600 hover:from-sky-400 hover:to-blue-500 text-white font-semibold text-xs shadow-md shadow-sky-500/20 transition active:scale-95"
                          >
                            {getActionIcon(message.action.type)}
                            <span>
                              {message.action.status === 'dispatched_dialer' || message.action.status === 'executed'
                                ? 'फेरि चलाउनुहोस् (Run Again)'
                                : 'अनुमति दिनुहोस् र सुरु गर्नुहोस् (Authorize & Execute)'}
                            </span>
                          </button>
                        </div>
                      </div>
                    )}

                    {/* Google Search Grounding Sources */}
                    {message.searchSources && message.searchSources.length > 0 && (
                      <div className="mt-3 pt-2.5 border-t border-slate-700/60">
                        <div className="flex items-center gap-1.5 text-xs font-semibold text-sky-300 mb-2">
                          <Globe className="w-3.5 h-3.5 text-sky-400" />
                          <span>इन्टरनेट स्रोतहरू (Verified Web Sources):</span>
                        </div>
                        <div className="flex flex-wrap gap-1.5">
                          {message.searchSources.map((source, sIdx) => (
                            <a
                              key={sIdx}
                              href={source.url}
                              target="_blank"
                              rel="noopener noreferrer"
                              className="flex items-center gap-1 px-2.5 py-1 rounded-md bg-slate-900/80 hover:bg-sky-950 text-sky-200 hover:text-white border border-sky-500/25 hover:border-sky-400 text-[11px] transition duration-150 max-w-full truncate"
                              title={source.url}
                            >
                              <ExternalLink className="w-3 h-3 text-sky-400 shrink-0" />
                              <span className="truncate">{source.title}</span>
                            </a>
                          ))}
                        </div>
                      </div>
                    )}
                  </div>

                  {/* Bubble bottom actions: Speak & Copy */}
                  <div className="flex items-center gap-2 mt-1 px-1 text-[11px] text-slate-400">
                    <span>
                      {new Date(message.timestamp).toLocaleTimeString([], {
                        hour: '2-digit',
                        minute: '2-digit',
                      })}
                    </span>

                    {!isUser && (
                      <>
                        <button
                          onClick={() => onSpeakMessage(message.content)}
                          className="hover:text-sky-300 flex items-center gap-0.5 transition"
                          title="Play spoken response"
                        >
                          <Volume2 className="w-3 h-3" />
                          <span>सुन्नुहोस्</span>
                        </button>
                        <button
                          onClick={() => handleCopy(message.id, message.content)}
                          className="hover:text-sky-300 flex items-center gap-0.5 transition"
                          title="Copy message"
                        >
                          {copiedId === message.id ? (
                            <Check className="w-3 h-3 text-emerald-400" />
                          ) : (
                            <Copy className="w-3 h-3" />
                          )}
                          <span>{copiedId === message.id ? 'कपि भयो' : 'कपि'}</span>
                        </button>
                      </>
                    )}
                  </div>
                </div>

                {isUser && (
                  <div className="w-8 h-8 rounded-xl bg-slate-800 flex items-center justify-center text-slate-300 shrink-0 border border-slate-700">
                    <User className="w-4 h-4" />
                  </div>
                )}
              </motion.div>
            );
          })
        )}

        {/* Loading Indicator */}
        {isLoading && (
          <motion.div
            initial={{ opacity: 0, y: 5 }}
            animate={{ opacity: 1, y: 0 }}
            className="flex items-center gap-3"
          >
            <div className="w-8 h-8 rounded-xl bg-gradient-to-br from-sky-500 to-blue-700 flex items-center justify-center text-white shrink-0 shadow-md">
              <Sparkles className="w-4 h-4 animate-spin text-sky-100" />
            </div>
            <div className="glass-panel px-4 py-2.5 rounded-2xl rounded-bl-xs border border-sky-500/20 text-xs text-sky-200 flex items-center gap-2">
              <span className="w-1.5 h-1.5 rounded-full bg-sky-400 animate-ping" />
              <span>मेरो एआई साथी कमाण्ड विश्लेषण गर्दैछ... (Routing Command & Thinking)</span>
            </div>
          </motion.div>
        )}

        <div ref={messagesEndRef} />
      </div>

      {/* Input bar */}
      <form
        onSubmit={handleSubmit}
        className="sticky bottom-0 z-20 w-full pt-2 pb-1 bg-gradient-to-t from-[#060913] via-[#060913]/95 to-transparent"
      >
        <div className="relative flex items-center gap-1.5 sm:gap-2 p-1.5 rounded-2xl bg-slate-900/90 border border-sky-500/25 shadow-xl shadow-sky-950/40 backdrop-blur-lg focus-within:border-sky-400 focus-within:ring-2 focus-within:ring-sky-500/20 transition duration-200">
          {/* Mic Button in input */}
          <button
            type="button"
            onClick={onToggleListening}
            className={`p-2.5 rounded-xl transition duration-200 shrink-0 ${
              isListening
                ? 'bg-red-500 text-white animate-pulse shadow-md shadow-red-500/40'
                : 'bg-slate-800 hover:bg-slate-700 text-sky-300 hover:text-white'
            }`}
            title={isListening ? 'Stop recording' : 'Speak voice input'}
          >
            <Mic className="w-4 h-4" />
          </button>

          {/* Text Input */}
          <input
            ref={inputRef}
            type="text"
            value={inputText}
            onChange={(e) => setInputText(e.target.value)}
            placeholder={
              preferences.language === 'ne'
                ? 'कमाण्ड दिनुहोस् (उदा: YouTube खोल, 9801234567 मा कल गर, 6 बजे अलार्म राख)...'
                : 'Enter command or chat (e.g. Open YouTube, Call 98..., Set 6 AM alarm)...'
            }
            className="flex-1 bg-transparent border-0 text-sm text-slate-100 placeholder:text-slate-500 focus:outline-none focus:ring-0 px-2 py-1.5"
            disabled={isLoading}
          />

          {/* Send Button */}
          <button
            type="submit"
            disabled={!inputText.trim() || isLoading}
            className="p-2.5 rounded-xl bg-gradient-to-r from-sky-500 to-blue-600 hover:from-sky-400 hover:to-blue-500 text-white disabled:opacity-40 disabled:pointer-events-none shadow-md shadow-sky-500/20 transition active:scale-95 shrink-0"
            title="Send message"
          >
            <Send className="w-4 h-4" />
          </button>
        </div>
      </form>
    </div>
  );
};
