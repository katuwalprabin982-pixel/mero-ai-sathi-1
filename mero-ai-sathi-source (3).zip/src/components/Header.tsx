import React from 'react';
import { 
  Sparkles, 
  Settings, 
  ShieldCheck, 
  Grid, 
  Volume2, 
  VolumeX, 
  Download,
  Smartphone
} from 'lucide-react';
import { UserPreferences, LanguageMode } from '../types/assistant';
import { usePWAInstall } from '../hooks/usePWAInstall';

interface HeaderProps {
  preferences: UserPreferences;
  onUpdatePreferences: (updated: Partial<UserPreferences>) => void;
  onOpenSettings: () => void;
  onOpenPermissionsGuide: () => void;
  onOpenActionLauncher: () => void;
  isSpeaking: boolean;
  onStopSpeaking: () => void;
}

export const Header: React.FC<HeaderProps> = ({
  preferences,
  onUpdatePreferences,
  onOpenSettings,
  onOpenPermissionsGuide,
  onOpenActionLauncher,
  isSpeaking,
  onStopSpeaking,
}) => {
  const { isInstallable, isInstalled, install } = usePWAInstall();

  const handleLanguageToggle = () => {
    const nextLang: Record<LanguageMode, LanguageMode> = {
      auto: 'ne',
      ne: 'en',
      en: 'auto',
    };
    onUpdatePreferences({ language: nextLang[preferences.language] });
  };

  const getLanguageLabel = (lang: LanguageMode) => {
    switch (lang) {
      case 'ne':
        return 'नेपाली';
      case 'en':
        return 'English';
      default:
        return 'Auto (द्विभाषी)';
    }
  };

  return (
    <header className="sticky top-0 z-30 w-full glass-panel border-b border-sky-500/15 px-3 py-2.5 sm:px-4">
      <div className="max-w-4xl mx-auto flex items-center justify-between gap-2">
        {/* Brand identity */}
        <div className="flex items-center gap-2.5">
          <div className="relative flex items-center justify-center w-9 h-9 sm:w-10 sm:h-10 rounded-xl bg-gradient-to-br from-sky-500 to-blue-700 shadow-md shadow-sky-500/20 border border-sky-400/30">
            <Sparkles className="w-5 h-5 text-sky-100 animate-pulse" />
            <span className="absolute -bottom-0.5 -right-0.5 w-2.5 h-2.5 rounded-full bg-emerald-400 ring-2 ring-[#070b14]" />
          </div>
          <div>
            <div className="flex items-center gap-1.5">
              <h1 className="text-base sm:text-lg font-bold text-white tracking-tight flex items-center gap-1">
                Mero AI Sathi
                <span className="text-xs font-medium text-sky-400 bg-sky-950/80 px-1.5 py-0.5 rounded border border-sky-500/30">
                  Android
                </span>
              </h1>
            </div>
            <p className="text-[11px] text-sky-300/80 font-medium leading-none">
              मेरो एआई साथी • व्यक्तिगत सहायक
            </p>
          </div>
        </div>

        {/* Action Controls */}
        <div className="flex items-center gap-1.5 sm:gap-2">
          {/* Speaking Audio Indicator */}
          {isSpeaking && (
            <button
              onClick={onStopSpeaking}
              className="flex items-center gap-1 px-2 py-1 rounded-lg bg-sky-500/20 text-sky-300 border border-sky-500/40 text-xs font-medium hover:bg-sky-500/30 transition animate-pulse"
              title="Stop audio reply"
            >
              <Volume2 className="w-3.5 h-3.5 animate-bounce" />
              <span className="hidden xs:inline">बोल्दैछ</span>
            </button>
          )}

          {/* Quick Language Toggle */}
          <button
            onClick={handleLanguageToggle}
            className="flex items-center gap-1 px-2.5 py-1 rounded-lg bg-slate-800/80 text-sky-200 border border-slate-700 hover:border-sky-500/40 text-xs font-semibold transition"
            title="भाषा परिवर्तन गर्नुहोस् (Switch Language)"
          >
            <span>{getLanguageLabel(preferences.language)}</span>
          </button>

          {/* Android App Launcher Hub */}
          <button
            onClick={onOpenActionLauncher}
            className="p-1.5 sm:px-2 sm:py-1 rounded-lg bg-slate-800/80 hover:bg-slate-700/80 text-slate-200 hover:text-sky-300 border border-slate-700 transition flex items-center gap-1 text-xs"
            title="Android Apps & Intents Hub"
          >
            <Grid className="w-4 h-4 text-sky-400" />
            <span className="hidden md:inline">Apps</span>
          </button>

          {/* Build Android APK Button */}
          <button
            onClick={onOpenPermissionsGuide}
            className="flex items-center gap-1 px-2.5 py-1 rounded-lg bg-emerald-600/90 hover:bg-emerald-500 text-white font-semibold text-xs shadow-md shadow-emerald-500/20 transition active:scale-95"
            title="Build Android APK (Phone Cloud Build)"
          >
            <Download className="w-3.5 h-3.5 text-emerald-100" />
            <span className="hidden xs:inline font-bold">Build APK</span>
          </button>

          {/* Android Permissions Guide */}
          <button
            onClick={onOpenPermissionsGuide}
            className="p-1.5 sm:px-2 sm:py-1 rounded-lg bg-slate-800/80 hover:bg-slate-700/80 text-slate-200 hover:text-sky-300 border border-slate-700 transition flex items-center gap-1 text-xs"
            title="Android Permissions & Features Info"
          >
            <ShieldCheck className="w-4 h-4 text-emerald-400" />
            <span className="hidden lg:inline">Permissions</span>
          </button>

          {/* Install PWA Button (Android / Chrome) */}
          {isInstallable && !isInstalled && (
            <button
              onClick={install}
              className="flex items-center gap-1 px-2.5 py-1 rounded-lg bg-gradient-to-r from-cyan-500 to-blue-600 text-white font-medium text-xs shadow-md shadow-cyan-500/20 hover:opacity-95 transition"
              title="Install Mero AI Sathi on your Android Phone"
            >
              <Smartphone className="w-3.5 h-3.5" />
              <span className="hidden sm:inline">Install</span>
            </button>
          )}

          {/* Settings */}
          <button
            onClick={onOpenSettings}
            className="p-2 rounded-lg bg-slate-800/80 hover:bg-slate-700/80 text-slate-300 hover:text-white border border-slate-700 transition"
            title="Settings & Privacy"
          >
            <Settings className="w-4 h-4" />
          </button>
        </div>
      </div>
    </header>
  );
};
