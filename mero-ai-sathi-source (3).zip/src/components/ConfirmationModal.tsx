import React from 'react';
import { 
  Phone, 
  MessageSquare, 
  AlarmClock, 
  ExternalLink, 
  Check, 
  X,
  ShieldAlert,
  Info
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { ActionPayload } from '../types/assistant';

interface ConfirmationModalProps {
  action: ActionPayload | null;
  isOpen: boolean;
  onConfirm: () => void;
  onCancel: () => void;
}

export const ConfirmationModal: React.FC<ConfirmationModalProps> = ({
  action,
  isOpen,
  onConfirm,
  onCancel,
}) => {
  if (!isOpen || !action) return null;

  const renderActionSpecificDetails = () => {
    switch (action.type) {
      case 'CALL':
        return (
          <div className="bg-slate-900/90 rounded-xl p-3.5 border border-sky-500/25 my-2">
            <div className="flex items-center gap-2.5 text-sky-300 mb-1.5">
              <Phone className="w-4 h-4 text-emerald-400" />
              <span className="font-semibold text-sm">फोन कल सुरु गरिँदै (Initiate Phone Call)</span>
            </div>
            <p className="text-lg font-bold text-white tracking-wide font-mono">
              {action.params.phoneNumber || 'अज्ञात नम्बर'}
            </p>
            {action.params.contactName && (
              <p className="text-xs text-sky-200 mt-0.5">सम्पर्क: {action.params.contactName}</p>
            )}

            <div className="mt-3 p-2.5 rounded-lg bg-slate-950 text-[11px] text-amber-300/90 border border-amber-500/30 flex items-start gap-2">
              <Info className="w-4 h-4 shrink-0 text-amber-400 mt-0.5" />
              <p className="leading-relaxed">
                <strong>एन्ड्रोइड प्रक्रिया (How it works):</strong> ब्राउजरले एन्ड्रोइडको फोन डायलर (`tel:`) खोल्नेछ। सुरक्षा नियम अनुसार, ब्राउजरले गोप्य रूपमा पृष्ठभूमिमा कल गर्न सक्दैन; तपाईंले डायलरमा हरियो कल बटन थिच्नुपर्नेछ।
              </p>
            </div>
          </div>
        );

      case 'SEND_MESSAGE':
      case 'DRAFT_MESSAGE':
        return (
          <div className="bg-slate-900/90 rounded-xl p-3.5 border border-sky-500/25 my-2">
            <div className="flex items-center gap-2.5 text-sky-300 mb-1.5">
              <MessageSquare className="w-4 h-4 text-cyan-400" />
              <span className="font-semibold text-sm">
                {action.type === 'DRAFT_MESSAGE' ? 'सन्देश मस्यौदा (Draft Message Review)' : 'सन्देश तयार गरिँदै (Send Message)'} ({action.params.platform === 'whatsapp' ? 'WhatsApp' : 'SMS'})
              </span>
            </div>
            <p className="text-xs text-slate-400">प्रापक (Recipient):</p>
            <p className="text-sm font-semibold text-white mb-2 font-mono">{action.params.recipient}</p>
            <p className="text-xs text-slate-400">सन्देश सामग्री (Message Draft):</p>
            <div className="p-2.5 rounded bg-slate-950 text-slate-200 text-xs italic border border-slate-800 my-1">
              "{action.params.text}"
            </div>
            <p className="text-[11px] text-amber-300/90 mt-2">
              📱 <strong>सुरक्षा सूचना:</strong> पुष्टि गरेपछि {action.params.platform === 'whatsapp' ? 'WhatsApp' : 'SMS'} एप खुल्नेछ र सन्देश तयार भएर आउनेछ। तपाईंले आफैँ समीक्षा गरेर 'Send' थिच्न सक्नुहुन्छ।
            </p>
          </div>
        );

      case 'SAVE_MEMORY':
        return (
          <div className="bg-slate-900/90 rounded-xl p-3.5 border border-purple-500/30 my-2">
            <div className="flex items-center gap-2.5 text-purple-300 mb-1.5">
              <ShieldAlert className="w-4 h-4 text-purple-400" />
              <span className="font-semibold text-sm">व्यक्तिगत स्मृति बचत सहमति (Save Memory Consent)</span>
            </div>
            <p className="text-xs text-slate-300 mb-2">
              के तपाईं "मेरो एआई साथी" लाई यो जानकारी सम्झन सहमति दिनुहुन्छ?
            </p>
            <div className="p-2.5 rounded bg-slate-950 text-purple-200 text-xs border border-purple-500/30 font-medium">
              💡 "{action.params.memoryFact}"
            </div>
            <p className="text-[11px] text-slate-400 mt-2">
              यो जानकारी तपाईंको डिभाइसमा मात्र सुरक्षित रहन्छ र भविष्यका कुराकानीहरू निजीकृत गर्न प्रयोग गरिन्छ।
            </p>
          </div>
        );

      case 'SET_ALARM':
        return (
          <div className="bg-slate-900/90 rounded-xl p-3.5 border border-sky-500/25 my-2">
            <div className="flex items-center gap-2.5 text-sky-300 mb-1.5">
              <AlarmClock className="w-4 h-4 text-amber-400" />
              <span className="font-semibold text-sm">अलार्म समय (Alarm Time)</span>
            </div>
            <p className="text-2xl font-extrabold text-white tracking-wider font-mono">
              {action.params.time || `${action.params.hours}:${action.params.minutes}`}
            </p>
            <p className="text-xs text-slate-300 mt-1">
              लेबल: {action.params.label || 'Mero AI Sathi Alarm'}
            </p>
            <div className="mt-3 p-2 rounded bg-slate-950 text-[11px] text-slate-400 border border-slate-800">
              एन्ड्रोइडको आधिकारिक घडी एप (`SET_ALARM` Intent) मा पठाइनेछ र साथै इन-एप टाइमर पनि सुरु हुनेछ।
            </div>
          </div>
        );

      case 'OPEN_APP':
        return (
          <div className="bg-slate-900/90 rounded-xl p-3.5 border border-sky-500/25 my-2">
            <div className="flex items-center gap-2.5 text-sky-300 mb-1.5">
              <ExternalLink className="w-4 h-4 text-sky-400" />
              <span className="font-semibold text-sm">एन्ड्रोइड एप खोल्दै (App Launch)</span>
            </div>
            <p className="text-base font-bold text-white">{action.params.appName}</p>
            {action.params.package && (
              <p className="text-[11px] text-slate-400 font-mono mt-0.5">Package: {action.params.package}</p>
            )}
            <p className="text-[11px] text-slate-400 mt-2">
              यदि मोबाइलमा एप इन्स्टल छ भने सिधै खुल्नेछ, अन्यथा वेब संस्करणमा रिडिरेक्ट हुनेछ।
            </p>
          </div>
        );

      default:
        return (
          <div className="bg-slate-900/90 rounded-xl p-3 border border-sky-500/25 my-2">
            <p className="text-sm text-slate-200">{action.description}</p>
          </div>
        );
    }
  };

  return (
    <AnimatePresence>
      <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm">
        <motion.div
          initial={{ opacity: 0, scale: 0.9, y: 20 }}
          animate={{ opacity: 1, scale: 1, y: 0 }}
          exit={{ opacity: 0, scale: 0.9, y: 20 }}
          className="relative w-full max-w-md rounded-2xl bg-gradient-to-b from-[#0f1d38] to-[#0a1224] border border-sky-500/30 p-5 shadow-2xl shadow-sky-500/20"
        >
          {/* Header */}
          <div className="flex items-start gap-3">
            <div className="p-2.5 rounded-xl bg-amber-500/20 border border-amber-500/40 text-amber-400">
              <ShieldAlert className="w-6 h-6 animate-pulse" />
            </div>
            <div className="flex-1">
              <h3 className="text-lg font-bold text-white tracking-tight">
                कार्य पुष्टिकरण (Action Confirmation)
              </h3>
              <p className="text-xs text-sky-300/80 mt-0.5">
                यो कार्य गर्न तपाईंको स्पष्ट अनुमति आवश्यक छ (Your approval is required)
              </p>
            </div>
          </div>

          {/* Action details */}
          <div className="mt-3">
            <p className="text-sm text-slate-200 font-medium">{action.title}</p>
            {renderActionSpecificDetails()}
          </div>

          {/* Security explanation note */}
          <p className="text-[11px] text-slate-400 mt-2 mb-4 leading-relaxed">
            🔒 <strong>गोपनीयता नीति:</strong> "मेरो एआई साथी" ले तपाईंको अनुमति बिना कहिल्यै कुनै पनि कल वा सन्देश पठाउँदैन।
          </p>

          {/* Button Actions */}
          <div className="flex items-center gap-2.5">
            <button
              onClick={onCancel}
              className="flex-1 flex items-center justify-center gap-1.5 py-2.5 px-4 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-white font-semibold text-xs border border-slate-700 transition"
            >
              <X className="w-4 h-4 text-slate-400" />
              <span>रद्द गर्नुहोस् (Cancel)</span>
            </button>
            <button
              onClick={onConfirm}
              className="flex-1 flex items-center justify-center gap-1.5 py-2.5 px-4 rounded-xl bg-gradient-to-r from-emerald-500 to-teal-600 hover:from-emerald-400 hover:to-teal-500 text-white font-bold text-xs shadow-lg shadow-emerald-500/25 transition"
            >
              <Check className="w-4 h-4" />
              <span>पुष्टि गर्नुहोस् (Proceed)</span>
            </button>
          </div>
        </motion.div>
      </div>
    </AnimatePresence>
  );
};
