import React, { useEffect } from 'react';
import { AlarmClock, Pause, Play, X, Bell } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { ActiveAssistantTimer } from '../types/assistant';
import { playChime, sendAndroidNotification } from '../utils/androidActions';

interface ActiveTimerBarProps {
  timers: ActiveAssistantTimer[];
  onToggleTimer: (id: string) => void;
  onDismissTimer: (id: string) => void;
  onTickTimers: () => void;
}

export const ActiveTimerBar: React.FC<ActiveTimerBarProps> = ({
  timers,
  onToggleTimer,
  onDismissTimer,
  onTickTimers,
}) => {
  useEffect(() => {
    if (timers.length === 0) return;

    const interval = setInterval(() => {
      onTickTimers();
    }, 1000);

    return () => clearInterval(interval);
  }, [timers.length, onTickTimers]);

  if (timers.length === 0) return null;

  const formatTime = (secs: number) => {
    const m = Math.floor(secs / 60);
    const s = secs % 60;
    return `${String(m).padStart(2, '0')}:${String(s).padStart(2, '0')}`;
  };

  return (
    <div className="fixed bottom-16 right-4 z-40 flex flex-col gap-2 max-w-xs w-full pointer-events-none">
      <AnimatePresence>
        {timers.map((timer) => {
          const isDone = timer.remainingSeconds <= 0;
          return (
            <motion.div
              key={timer.id}
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: 20 }}
              className={`p-3 rounded-2xl shadow-2xl border pointer-events-auto backdrop-blur-md transition-all ${
                isDone
                  ? 'bg-rose-950/90 border-rose-500/50 animate-bounce'
                  : 'bg-slate-900/90 border-sky-500/30'
              }`}
            >
              <div className="flex items-center justify-between gap-3">
                <div className="flex items-center gap-2 overflow-hidden">
                  <div
                    className={`p-2 rounded-xl shrink-0 ${
                      isDone ? 'bg-rose-500/20 text-rose-400' : 'bg-amber-500/20 text-amber-400'
                    }`}
                  >
                    <AlarmClock className="w-4 h-4" />
                  </div>
                  <div className="overflow-hidden">
                    <p className="text-xs font-bold text-white truncate">{timer.label}</p>
                    <p
                      className={`text-base font-mono font-extrabold tracking-wider ${
                        isDone ? 'text-rose-400' : 'text-amber-300'
                      }`}
                    >
                      {isDone ? 'अलार्म सकियो!' : formatTime(timer.remainingSeconds)}
                    </p>
                  </div>
                </div>

                <div className="flex items-center gap-1 shrink-0">
                  {!isDone && (
                    <button
                      onClick={() => onToggleTimer(timer.id)}
                      className="p-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 transition"
                      title={timer.isRunning ? 'Pause' : 'Resume'}
                    >
                      {timer.isRunning ? (
                        <Pause className="w-3.5 h-3.5" />
                      ) : (
                        <Play className="w-3.5 h-3.5 text-emerald-400" />
                      )}
                    </button>
                  )}
                  <button
                    onClick={() => onDismissTimer(timer.id)}
                    className="p-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-400 hover:text-white transition"
                    title="Dismiss"
                  >
                    <X className="w-3.5 h-3.5" />
                  </button>
                </div>
              </div>
            </motion.div>
          );
        })}
      </AnimatePresence>
    </div>
  );
};
