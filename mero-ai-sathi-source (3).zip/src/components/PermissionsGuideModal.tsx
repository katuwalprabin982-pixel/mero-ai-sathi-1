import React, { useState, useEffect } from 'react';
import { 
  X, 
  Shield, 
  Mic, 
  Bell, 
  Phone, 
  AlarmClock, 
  Layers, 
  CheckCircle, 
  AlertCircle, 
  Code2,
  Copy,
  Check,
  Smartphone,
  ExternalLink,
  Info,
  HelpCircle,
  Vibrate,
  Volume2,
  Terminal,
  CheckSquare,
  MessageSquare,
  Search,
  Brain,
  Download,
  Cloud,
  ArrowRight,
  Sparkles
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { sendAndroidNotification, triggerHaptic, playChime } from '../utils/androidActions';
import { getPlatformDiagnostics } from '../utils/nativeAndroidBridge';

interface PermissionsGuideModalProps {
  isOpen: boolean;
  onClose: () => void;
  initialTab?: 'cloud_apk' | 'matrix' | 'test' | 'checklist' | 'native';
}

export const PermissionsGuideModal: React.FC<PermissionsGuideModalProps> = ({
  isOpen,
  onClose,
  initialTab = 'cloud_apk',
}) => {
  const [micStatus, setMicStatus] = useState<'prompt' | 'granted' | 'denied'>('prompt');
  const [notificationStatus, setNotificationStatus] = useState<NotificationPermission>('default');
  const [copiedCode, setCopiedCode] = useState(false);
  const [copiedCli, setCopiedCli] = useState(false);
  const [activeTab, setActiveTab] = useState<'cloud_apk' | 'matrix' | 'test' | 'checklist' | 'native'>(initialTab);
  const [isDownloadingZip, setIsDownloadingZip] = useState(false);

  const diagnostics = getPlatformDiagnostics();

  useEffect(() => {
    if (!isOpen) return;

    if (typeof window !== 'undefined' && 'Notification' in window) {
      setNotificationStatus(Notification.permission);
    }

    if (typeof navigator !== 'undefined' && navigator.permissions && navigator.permissions.query) {
      navigator.permissions
        .query({ name: 'microphone' as PermissionName })
        .then((res) => {
          setMicStatus(res.state as any);
          res.onchange = () => setMicStatus(res.state as any);
        })
        .catch(() => {});
    }
  }, [isOpen]);

  const requestMic = async () => {
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      setMicStatus('granted');
      triggerHaptic(50);
      playChime('start');
      stream.getTracks().forEach((t) => t.stop());
    } catch {
      setMicStatus('denied');
    }
  };

  const requestNotification = async () => {
    if (typeof window !== 'undefined' && 'Notification' in window) {
      const res = await Notification.requestPermission();
      setNotificationStatus(res);
      if (res === 'granted') {
        playChime('success');
        sendAndroidNotification(
          'Mero AI Sathi • सूचना सक्रिय भयो',
          'अलार्म र रिमाइन्डरहरूको लागि सूचना अनुमति प्राप्त भएको छ।'
        );
      }
    }
  };

  const testHaptic = () => {
    triggerHaptic(80);
    playChime('success');
  };

  const androidManifestSnippet = `<!-- AndroidManifest.xml for Mero AI Sathi Native APK -->
<manifest xmlns:android="http://schemas.android.com/apk/res/android"
    package="np.meroaisathi.app">

    <!-- 1. Voice Recognition (Nepali & English STT) -->
    <uses-permission android:name="android.permission.RECORD_AUDIO" />
    <uses-permission android:name="android.permission.MODIFY_AUDIO_SETTINGS" />

    <!-- 2. Alarm & Clock Integrations (Wakes from Doze Sleep) -->
    <uses-permission android:name="com.android.alarm.permission.SET_ALARM" />
    <uses-permission android:name="android.permission.SCHEDULE_EXACT_ALARM" />
    <uses-permission android:name="android.permission.WAKE_LOCK" />

    <!-- 3. Direct Phone Calls (After user confirmation) -->
    <uses-permission android:name="android.permission.CALL_PHONE" />

    <!-- 4. Notifications & Haptics -->
    <uses-permission android:name="android.permission.POST_NOTIFICATIONS" />
    <uses-permission android:name="android.permission.VIBRATE" />
    <uses-permission android:name="android.permission.INTERNET" />
    <uses-permission android:name="android.permission.ACCESS_NETWORK_STATE" />

    <!-- 5. App Launch Queries for YouTube, WhatsApp, Maps, Clock -->
    <queries>
        <package android:name="com.google.android.youtube" />
        <package android:name="com.whatsapp" />
        <package android:name="com.google.android.apps.maps" />
        <package android:name="com.google.android.deskclock" />
        <package android:name="com.android.chrome" />
        <intent>
            <action android:name="android.intent.action.DIAL" />
            <data android:scheme="tel" />
        </intent>
        <intent>
            <action android:name="android.intent.action.VIEW" />
            <data android:scheme="vnd.youtube" />
        </intent>
    </queries>
</manifest>`;

  const cliPackagingCommands = `# 1. Build web production bundle
npm run build

# 2. Add Android platform (first time only)
npx cap add android

# 3. Synchronize web assets and manifest to Android
npx cap sync android

# 4. Open project in Android Studio (GUI build)
npx cap open android

# OR build APK directly from terminal:
cd android
./gradlew assembleDebug

# Output APK path:
# android/app/build/outputs/apk/debug/app-debug.apk

# 5. Install onto connected Android device:
adb install -r android/app/build/outputs/apk/debug/app-debug.apk`;

  const handleDownloadZip = () => {
    setIsDownloadingZip(true);
    triggerHaptic(50);
    playChime('start');
    window.location.href = '/api/export-project';
    setTimeout(() => {
      setIsDownloadingZip(false);
    }, 4000);
  };

  const copyManifest = () => {
    navigator.clipboard.writeText(androidManifestSnippet);
    setCopiedCode(true);
    setTimeout(() => setCopiedCode(false), 2000);
  };

  const copyCli = () => {
    navigator.clipboard.writeText(cliPackagingCommands);
    setCopiedCli(true);
    setTimeout(() => setCopiedCli(false), 2000);
  };

  if (!isOpen) return null;

  return (
    <AnimatePresence>
      <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-black/80 backdrop-blur-md overflow-y-auto">
        <motion.div
          initial={{ opacity: 0, scale: 0.95, y: 15 }}
          animate={{ opacity: 1, scale: 1, y: 0 }}
          exit={{ opacity: 0, scale: 0.95, y: 15 }}
          className="relative w-full max-w-2xl rounded-2xl bg-[#091226] border border-sky-500/30 p-4 sm:p-6 shadow-2xl text-slate-100 max-h-[92vh] overflow-y-auto"
        >
          {/* Header */}
          <div className="flex items-center justify-between pb-3 border-b border-slate-800">
            <div className="flex items-center gap-2">
              <div className="p-2 rounded-xl bg-emerald-500/20 text-emerald-400 border border-emerald-500/30">
                <Shield className="w-5 h-5" />
              </div>
              <div>
                <h3 className="text-base sm:text-lg font-bold text-white flex items-center gap-2">
                  एन्ड्रोइड क्षमता र अनुमति गाइड (Capabilities & Testing)
                </h3>
                <p className="text-xs text-sky-300/80">
                  वर्तमान वातावरण: <span className="text-emerald-400 font-mono">{diagnostics.runtimeEnvironment}</span>
                </p>
              </div>
            </div>
            <button
              onClick={onClose}
              className="p-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-400 hover:text-white transition"
            >
              <X className="w-5 h-5" />
            </button>
          </div>

          {/* Navigation Tabs */}
          <div className="grid grid-cols-2 sm:grid-cols-5 gap-1.5 my-3.5 p-1 rounded-xl bg-slate-900 border border-slate-800 text-xs font-semibold">
            <button
              onClick={() => setActiveTab('cloud_apk')}
              className={`py-2 px-1 rounded-lg text-center transition flex items-center justify-center gap-1 ${
                activeTab === 'cloud_apk' ? 'bg-emerald-600 text-white shadow' : 'text-emerald-400 hover:text-white'
              }`}
            >
              <Smartphone className="w-3.5 h-3.5" />
              <span>📱 क्लाउड APK</span>
            </button>
            <button
              onClick={() => setActiveTab('matrix')}
              className={`py-2 px-1 rounded-lg text-center transition ${
                activeTab === 'matrix' ? 'bg-sky-500 text-white shadow' : 'text-slate-400 hover:text-white'
              }`}
            >
              क्षमता तुलना
            </button>
            <button
              onClick={() => setActiveTab('checklist')}
              className={`py-2 px-1 rounded-lg text-center transition ${
                activeTab === 'checklist' ? 'bg-sky-500 text-white shadow' : 'text-slate-400 hover:text-white'
              }`}
            >
              परीक्षण गाइड
            </button>
            <button
              onClick={() => setActiveTab('test')}
              className={`py-2 px-1 rounded-lg text-center transition ${
                activeTab === 'test' ? 'bg-sky-500 text-white shadow' : 'text-slate-400 hover:text-white'
              }`}
            >
              हार्डवेयर जाँच
            </button>
            <button
              onClick={() => setActiveTab('native')}
              className={`py-2 px-1 rounded-lg text-center transition ${
                activeTab === 'native' ? 'bg-sky-500 text-white shadow' : 'text-slate-400 hover:text-white'
              }`}
            >
              कम्प्युटर CLI
            </button>
          </div>

          {/* TAB 0: CLOUD APK BUILD (PHONE ONLY - GITHUB ACTIONS) */}
          {activeTab === 'cloud_apk' && (
            <div className="space-y-4">
              <div className="p-3.5 rounded-xl bg-gradient-to-br from-emerald-950/60 to-slate-900 border border-emerald-500/30">
                <div className="flex items-center gap-2 mb-1.5 text-emerald-400 font-bold text-sm">
                  <Cloud className="w-4 h-4" />
                  <h4>फोनबाटै APK निर्माण गर्नुहोस् (कम्प्युटर नचाहिने विधि)</h4>
                </div>
                <p className="text-xs text-slate-300 leading-relaxed">
                  यो वेब डेभलपमेन्ट वातावरणमा Node.js छ तर Java JDK र Android SDK छैन। त्यसैले तपाईंको आफ्नै फोनबाट GitHub Actions को निःशुल्क क्लाउड सर्भर प्रयोग गरेर वास्तविक <strong className="text-emerald-300 font-mono">app-debug.apk</strong> बनाउन सक्नुहुन्छ।
                </p>

                {/* 1-Tap Download Source Code Button */}
                <div className="mt-3.5 p-3 rounded-lg bg-black/40 border border-emerald-500/20 flex flex-col sm:flex-row items-center justify-between gap-3">
                  <div>
                    <h5 className="text-xs font-bold text-white flex items-center gap-1.5">
                      <Download className="w-4 h-4 text-emerald-400" />
                      <span>सम्पूर्ण प्रोजेक्ट सोर्स कोड (.ZIP)</span>
                    </h5>
                    <p className="text-[11px] text-slate-400 mt-0.5">
                      Capacitor, AndroidManifest र स्वचालित GitHub Actions workflow समावेश छ
                    </p>
                  </div>
                  <button
                    onClick={handleDownloadZip}
                    disabled={isDownloadingZip}
                    className="w-full sm:w-auto px-4 py-2 rounded-xl bg-gradient-to-r from-emerald-500 to-teal-600 hover:from-emerald-400 hover:to-teal-500 text-white font-bold text-xs shadow-lg shadow-emerald-500/20 flex items-center justify-center gap-1.5 transition active:scale-95 disabled:opacity-50"
                  >
                    {isDownloadingZip ? (
                      <>
                        <span className="w-3.5 h-3.5 border-2 border-white border-t-transparent rounded-full animate-spin" />
                        <span>तयार हुँदैछ...</span>
                      </>
                    ) : (
                      <>
                        <Download className="w-4 h-4" />
                        <span>सोर्स कोड डाउनलोड गर्नुहोस् (.ZIP)</span>
                      </>
                    )}
                  </button>
                </div>
              </div>

              {/* Step by Step Guide for Phone Users */}
              <div className="space-y-2.5">
                <h5 className="text-xs font-bold text-sky-300 uppercase tracking-wider">
                  ५ सरल चरणहरू (5 Simple Steps on Your Android Phone):
                </h5>

                <div className="p-3 rounded-xl bg-slate-900/90 border border-slate-800 flex gap-3">
                  <div className="w-6 h-6 rounded-full bg-sky-500/20 text-sky-400 flex items-center justify-center font-bold text-xs shrink-0">
                    १
                  </div>
                  <div className="text-xs">
                    <p className="font-semibold text-white">माथिको बटन थिचेर कोड डाउनलोड गर्नुहोस्</p>
                    <p className="text-slate-400 mt-0.5">
                      तपाईंको फोनको Downloads फोल्डरमा <code className="text-sky-300 bg-slate-950 px-1 py-0.5 rounded font-mono">mero-ai-sathi-source.zip</code> बचत हुनेछ।
                    </p>
                  </div>
                </div>

                <div className="p-3 rounded-xl bg-slate-900/90 border border-slate-800 flex gap-3">
                  <div className="w-6 h-6 rounded-full bg-sky-500/20 text-sky-400 flex items-center justify-center font-bold text-xs shrink-0">
                    २
                  </div>
                  <div className="text-xs">
                    <p className="font-semibold text-white">फोनको Chrome मा GitHub.com खोल्नुहोस्</p>
                    <p className="text-slate-400 mt-0.5">
                      GitHub मा जानुहोस् र माथिको <code className="text-sky-300 bg-slate-950 px-1 py-0.5 rounded font-mono">+</code> थिचेर <strong className="text-slate-200">New repository</strong> छान्नुहोस्। नाम <code className="text-sky-300 bg-slate-950 px-1 py-0.5 rounded font-mono">mero-ai-sathi</code> राखेर <strong className="text-slate-200">Create repository</strong> थिच्नुहोस्।
                    </p>
                  </div>
                </div>

                <div className="p-3 rounded-xl bg-slate-900/90 border border-slate-800 flex gap-3">
                  <div className="w-6 h-6 rounded-full bg-sky-500/20 text-sky-400 flex items-center justify-center font-bold text-xs shrink-0">
                    ३
                  </div>
                  <div className="text-xs">
                    <p className="font-semibold text-white">कोड फाइलहरू अपलोड गर्नुहोस्</p>
                    <p className="text-slate-400 mt-0.5">
                      तपाईंको नयाँ repository मा रहेको <strong className="text-slate-200">uploading an existing file</strong> लिंकमा थिचेर फोनमा भएको फाइलहरू अपलोड गर्नुहोस् र <strong className="text-slate-200">Commit changes</strong> थिच्नुहोस्। यस प्रोजेक्टमा <code className="text-sky-300 bg-slate-950 px-1 py-0.5 rounded font-mono">.github/workflows/build-apk.yml</code> पहिले नै तयार छ।
                    </p>
                  </div>
                </div>

                <div className="p-3 rounded-xl bg-slate-900/90 border border-slate-800 flex gap-3">
                  <div className="w-6 h-6 rounded-full bg-sky-500/20 text-sky-400 flex items-center justify-center font-bold text-xs shrink-0">
                    ४
                  </div>
                  <div className="text-xs">
                    <p className="font-semibold text-white">Actions ट्याबमा स्वचालित APK निर्माण हेर्नुहोस्</p>
                    <p className="text-slate-400 mt-0.5">
                      GitHub मा <strong className="text-slate-200">Actions</strong> ट्याब थिच्नुहोस्। त्यहाँ GitHub को शक्तिशाली क्लाउड मेसिनले Java 17 र Android SDK सेटअप गरी <code className="text-sky-300 bg-slate-950 px-1 py-0.5 rounded font-mono">./gradlew assembleDebug</code> आफैं चलाउनेछ (करिब २ मिनेट लाग्छ)।
                    </p>
                  </div>
                </div>

                <div className="p-3 rounded-xl bg-slate-900/90 border border-slate-800 flex gap-3">
                  <div className="w-6 h-6 rounded-full bg-sky-500/20 text-sky-400 flex items-center justify-center font-bold text-xs shrink-0">
                    ५
                  </div>
                  <div className="text-xs">
                    <p className="font-semibold text-white">APK डाउनलोड गर्नुहोस् र फोनमा इन्स्टल गर्नुहोस्</p>
                    <p className="text-slate-400 mt-0.5">
                      सम्पन्न रनमा थिचेर तल स्क्रोल गर्नुहोस् र <strong className="text-emerald-300">Artifacts</strong> बाट <code className="text-emerald-300 bg-slate-950 px-1 py-0.5 rounded font-mono">mero-ai-sathi-debug-apk</code> डाउनलोड गर्नुहोस्। फोनमा फाइल खोली सिधै इन्स्टल गर्नुहोस्!
                    </p>
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* TAB 1: CAPABILITY MATRIX */}
          {activeTab === 'matrix' && (
            <div className="space-y-3.5">
              <div className="p-3 rounded-xl bg-sky-950/40 border border-sky-500/25 text-xs text-sky-200 leading-relaxed">
                <p>
                  <strong>इमानदार कार्य प्रणाली (Truthful Execution Rule):</strong> "मेरो एआई साथी" ले वास्तविक नतिजा मात्र रिपोर्ट गर्छ। मोबाइल ब्राउजर स्यान्डबक्सभित्र के सम्भव छ र केको लागि नेटिभ एन्ड्रोइड चाहिन्छ, तल स्पष्ट गरिएको छ:
                </p>
              </div>

              {/* Action 1: Phone Calls */}
              <div className="p-3.5 rounded-xl bg-slate-900/90 border border-slate-800">
                <div className="flex items-center gap-2 mb-1.5">
                  <Phone className="w-4 h-4 text-emerald-400" />
                  <h4 className="text-sm font-bold text-white">१. फोन कल (Phone Calling)</h4>
                </div>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 text-xs">
                  <div className="p-2.5 rounded-lg bg-slate-950/80 border border-slate-800">
                    <p className="font-semibold text-emerald-400 mb-1">✓ मोबाइल ब्राउजर / PWA मा:</p>
                    <p className="text-slate-300 leading-relaxed">
                      `tel:` URL Scheme मार्फत एन्ड्रोइडको आधिकारिक डायलर खुल्छ र नम्बर भरिन्छ। प्रयोगकर्ताले डायलरमा हरियो कल बटन थिच्नुपर्छ।
                    </p>
                  </div>
                  <div className="p-2.5 rounded-lg bg-slate-950/80 border border-slate-800">
                    <p className="font-semibold text-amber-400 mb-1">⚠️ ब्राउजरमा असम्भव (Native APK आवश्यक):</p>
                    <p className="text-slate-300 leading-relaxed">
                      ब्राउजरले प्रयोगकर्ता बिना सिधै पृष्ठभूमिमा (Silent Background Call) कल गर्न सक्दैन। यसको लागि नेटिभ `CALL_PHONE` अनुमति चाहिन्छ।
                    </p>
                  </div>
                </div>
              </div>

              {/* Action 2: Alarms & Timers */}
              <div className="p-3.5 rounded-xl bg-slate-900/90 border border-slate-800">
                <div className="flex items-center gap-2 mb-1.5">
                  <AlarmClock className="w-4 h-4 text-amber-400" />
                  <h4 className="text-sm font-bold text-white">२. अलार्म र टाइमर (Alarms & Timers)</h4>
                </div>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 text-xs">
                  <div className="p-2.5 rounded-lg bg-slate-950/80 border border-slate-800">
                    <p className="font-semibold text-emerald-400 mb-1">✓ मोबाइल ब्राउजर / PWA मा:</p>
                    <p className="text-slate-300 leading-relaxed">
                      एन्ड्रोइड घडी एपमा `SET_ALARM` इन्टेन्ट पठाइन्छ। साथै इन-एप Web Audio टाइमरले स्क्रिन खुला रहँदासम्म वास्तविक घण्टी र सूचना दिन्छ।
                    </p>
                  </div>
                  <div className="p-2.5 rounded-lg bg-slate-950/80 border border-slate-800">
                    <p className="font-semibold text-amber-400 mb-1">⚠️ ब्राउजरमा असम्भव (Native APK आवश्यक):</p>
                    <p className="text-slate-300 leading-relaxed">
                      फोनको स्क्रिन बन्द भएको र गहिरो निन्द्रा (Doze Mode) मा रहँदा हार्डवेयर अलार्म बजाउन नेटिभ `SCHEDULE_EXACT_ALARM` चाहिन्छ।
                    </p>
                  </div>
                </div>
              </div>

              {/* Action 3: App Launching */}
              <div className="p-3.5 rounded-xl bg-slate-900/90 border border-slate-800">
                <div className="flex items-center gap-2 mb-1.5">
                  <Layers className="w-4 h-4 text-sky-400" />
                  <h4 className="text-sm font-bold text-white">३. एप खोल्ने (YouTube, WhatsApp, Maps)</h4>
                </div>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 text-xs">
                  <div className="p-2.5 rounded-lg bg-slate-950/80 border border-slate-800">
                    <p className="font-semibold text-emerald-400 mb-1">✓ मोबाइल ब्राउजर / PWA मा:</p>
                    <p className="text-slate-300 leading-relaxed">
                      `vnd.youtube:`, `whatsapp:`, `intent://` मार्फत सिधै एप खुल्छ। यदि एप इन्स्टल छैन भने आधिकारिक वेब संस्करण खुल्छ।
                    </p>
                  </div>
                  <div className="p-2.5 rounded-lg bg-slate-950/80 border border-slate-800">
                    <p className="font-semibold text-amber-400 mb-1">⚠️ ब्राउजरमा असम्भव (Native APK आवश्यक):</p>
                    <p className="text-slate-300 leading-relaxed">
                      कुनै एप पहिले नै इन्स्टल छ वा छैन भनेर पहिले नै जाँच्न (Pre-checking) नेटिभ `QUERY_ALL_PACKAGES` चाहिन्छ।
                    </p>
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* TAB 2: TESTING CHECKLIST */}
          {activeTab === 'checklist' && (
            <div className="space-y-2.5">
              <p className="text-xs text-slate-300 mb-2">
                हरेक सुविधालाई यसरी परीक्षण गर्न सक्नुहुन्छ:
              </p>

              {[
                {
                  title: '१. आवाज इनपुट र बोली (Voice STT & TTS)',
                  command: 'माइक थिच्नुहोस् र बोल्नुहोस्: "नमस्ते साथी"',
                  expected: 'नेपालीमा ट्रान्सक्रिप्ट देखिन्छ र जेमिनाई/ब्राउजर अडियो मार्फत उत्तर सुनिन्छ।',
                  icon: Mic,
                  color: 'text-sky-400',
                },
                {
                  title: '२. YouTube एप लन्च (App Launch)',
                  command: '"YouTube खोलिदेऊ" वा "open youtube"',
                  expected: 'कमाण्ड राउटरले ACTION छुट्याउँछ, पुष्टि माग्छ र एन्ड्रोइड युट्युब एप खोल्छ।',
                  icon: Layers,
                  color: 'text-red-400',
                },
                {
                  title: '३. फोन कल ह्यान्डअफ (Phone Dialer)',
                  command: '"आमालाई ९८०१२३४५६७ मा फोन गर"',
                  expected: 'सुरक्षा मोडलमा पुष्टि मागेपछि tel: URI मार्फत फोन डायलर खुल्छ।',
                  icon: Phone,
                  color: 'text-emerald-400',
                },
                {
                  title: '४. अलार्म र इन-एप टाइमर (Alarm & Timers)',
                  command: '"बिहान ०६:३० बजे अलार्म राख" वा "५ मिनेट टाइमर"',
                  expected: 'एन्ड्रोइड घडी एपमा इन्टेन्ट पठाइन्छ र इन-एप काउन्टडाउन टाइमर सुरु हुन्छ।',
                  icon: AlarmClock,
                  color: 'text-amber-400',
                },
                {
                  title: '५. सन्देश मस्यौदा (Drafting Messages)',
                  command: '"Shyam लाई ह्वाट्सएपमा ५ मिनेट ढिलो हुन्छु भनेर ड्राफ्ट गर"',
                  expected: 'मस्यौदा समीक्षा कार्ड खुल्छ र WhatsApp एपमा भरिएर खुल्छ।',
                  icon: MessageSquare,
                  color: 'text-cyan-400',
                },
                {
                  title: '६. सहमति-आधारित स्मृति (Personalized Memory)',
                  command: '"सम्झिराख कि मलाई कालो चिया मनपर्छ"',
                  expected: 'सहमति मोडलमा पुष्टि भएपछि स्मृतिमा थपिन्छ र भविष्यका उत्तर निजीकृत हुन्छन्।',
                  icon: Brain,
                  color: 'text-purple-400',
                },
                {
                  title: '७. इन्टरनेट खोज (Google Grounding)',
                  command: '"काठमाडौँको ताजा समाचार के छ?"',
                  expected: 'वास्तविक अनलाइन स्रोतहरू सहित ताजा जानकारी र लिङ्कहरू देखिन्छन्।',
                  icon: Search,
                  color: 'text-teal-400',
                },
              ].map((item, idx) => (
                <div key={idx} className="p-2.5 rounded-xl bg-slate-900 border border-slate-800 text-xs">
                  <div className="flex items-center gap-2 mb-1">
                    <item.icon className={`w-3.5 h-3.5 ${item.color}`} />
                    <span className="font-bold text-white">{item.title}</span>
                  </div>
                  <p className="text-sky-300 font-mono text-[11px] mb-0.5">कमाण्ड: {item.command}</p>
                  <p className="text-slate-400 text-[11px]">अपेक्षित नतिजा: {item.expected}</p>
                </div>
              ))}
            </div>
          )}

          {/* TAB 3: HARDWARE / PERMISSION TESTS */}
          {activeTab === 'test' && (
            <div className="space-y-3">
              <p className="text-xs text-slate-300 mb-3">
                तपाईंको ब्राउजर वा एन्ड्रोइड फोनमा अनुमतिहरूको वर्तमान स्थिति जाँच गर्नुहोस् र परीक्षण गर्नुहोस्:
              </p>

              {/* Microphone */}
              <div className="p-3.5 rounded-xl bg-slate-900 border border-slate-800 flex items-center justify-between">
                <div className="flex items-center gap-2.5">
                  <div className="p-2 rounded-lg bg-sky-500/20 text-sky-400">
                    <Mic className="w-4 h-4" />
                  </div>
                  <div>
                    <h5 className="text-xs font-bold text-white">माइक्रोफोन (RECORD_AUDIO)</h5>
                    <p className="text-[11px] text-slate-400">नेपाली/अंग्रेजी बोली पहिचानको लागि</p>
                  </div>
                </div>

                <div className="flex items-center gap-2">
                  <span
                    className={`text-xs font-semibold px-2 py-0.5 rounded ${
                      micStatus === 'granted'
                        ? 'bg-emerald-950 text-emerald-400 border border-emerald-500/30'
                        : 'bg-slate-800 text-slate-400'
                    }`}
                  >
                    {micStatus === 'granted' ? 'सक्रिय छ' : 'निष्क्रिय'}
                  </span>
                  <button
                    onClick={requestMic}
                    className="px-2.5 py-1 rounded-lg bg-sky-500 hover:bg-sky-400 text-white font-semibold text-xs shadow transition"
                  >
                    परीक्षण गर्नुहोस्
                  </button>
                </div>
              </div>

              {/* Notifications */}
              <div className="p-3.5 rounded-xl bg-slate-900 border border-slate-800 flex items-center justify-between">
                <div className="flex items-center gap-2.5">
                  <div className="p-2 rounded-lg bg-amber-500/20 text-amber-400">
                    <Bell className="w-4 h-4" />
                  </div>
                  <div>
                    <h5 className="text-xs font-bold text-white">सूचनाहरू (POST_NOTIFICATIONS)</h5>
                    <p className="text-[11px] text-slate-400">अलार्म र टाइमर घण्टीको लागि</p>
                  </div>
                </div>

                <div className="flex items-center gap-2">
                  <span
                    className={`text-xs font-semibold px-2 py-0.5 rounded ${
                      notificationStatus === 'granted'
                        ? 'bg-emerald-950 text-emerald-400 border border-emerald-500/30'
                        : 'bg-slate-800 text-slate-400'
                    }`}
                  >
                    {notificationStatus === 'granted' ? 'सक्रिय छ' : 'निष्क्रिय'}
                  </span>
                  <button
                    onClick={requestNotification}
                    className="px-2.5 py-1 rounded-lg bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold text-xs shadow transition"
                  >
                    परीक्षण गर्नुहोस्
                  </button>
                </div>
              </div>

              {/* Haptic Vibration */}
              <div className="p-3.5 rounded-xl bg-slate-900 border border-slate-800 flex items-center justify-between">
                <div className="flex items-center gap-2.5">
                  <div className="p-2 rounded-lg bg-purple-500/20 text-purple-400">
                    <Vibrate className="w-4 h-4" />
                  </div>
                  <div>
                    <h5 className="text-xs font-bold text-white">एन्ड्रोइड कम्पन (Haptic Vibration)</h5>
                    <p className="text-[11px] text-slate-400">थिच्दा र कार्य गर्दा कम्पन प्रतिक्रिया</p>
                  </div>
                </div>

                <button
                  onClick={testHaptic}
                  className="px-2.5 py-1 rounded-lg bg-purple-600 hover:bg-purple-500 text-white font-semibold text-xs shadow transition"
                >
                  कम्पन जाँच्नुहोस्
                </button>
              </div>

              {/* Web Audio Chime */}
              <div className="p-3.5 rounded-xl bg-slate-900 border border-slate-800 flex items-center justify-between">
                <div className="flex items-center gap-2.5">
                  <div className="p-2 rounded-lg bg-teal-500/20 text-teal-400">
                    <Volume2 className="w-4 h-4" />
                  </div>
                  <div>
                    <h5 className="text-xs font-bold text-white">अलार्म घण्टी (Web Audio Chime)</h5>
                    <p className="text-[11px] text-slate-400">सिन्थेटिक डिजिटल घण्टी</p>
                  </div>
                </div>

                <button
                  onClick={() => playChime('alarm')}
                  className="px-2.5 py-1 rounded-lg bg-teal-600 hover:bg-teal-500 text-white font-semibold text-xs shadow transition"
                >
                  घण्टी बजाउनुहोस्
                </button>
              </div>
            </div>
          )}

          {/* TAB 4: NATIVE ANDROID APK PACKAGING */}
          {activeTab === 'native' && (
            <div className="space-y-3">
              <p className="text-xs text-slate-300">
                यो प्रोजेक्टमा Capacitor र पूर्ण `AndroidManifest.xml` पहिले नै कन्फिगर गरिएको छ। APK बनाउन र फोनमा इन्स्टल गर्न तलका कमाण्डहरू चलाउनुहोस्:
              </p>

              {/* Terminal commands */}
              <div className="p-3 rounded-xl bg-black border border-slate-800">
                <div className="flex items-center justify-between mb-1.5">
                  <div className="flex items-center gap-1.5 text-xs font-bold text-emerald-400">
                    <Terminal className="w-3.5 h-3.5" />
                    <span>APK निर्माण कमाण्डहरू (Terminal Commands):</span>
                  </div>
                  <button
                    onClick={copyCli}
                    className="flex items-center gap-1 text-[11px] text-sky-400 hover:text-white"
                  >
                    {copiedCli ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
                    <span>{copiedCli ? 'कपि भयो' : 'Copy Commands'}</span>
                  </button>
                </div>
                <pre className="font-mono text-[10px] text-slate-300 overflow-x-auto leading-relaxed max-h-48 p-2 rounded bg-slate-950">
                  {cliPackagingCommands}
                </pre>
              </div>

              {/* Manifest */}
              <div className="p-3 rounded-xl bg-slate-950 border border-slate-800">
                <div className="flex items-center justify-between mb-1.5">
                  <span className="text-[11px] font-mono text-sky-400">android/app/src/main/AndroidManifest.xml</span>
                  <button
                    onClick={copyManifest}
                    className="flex items-center gap-1 text-[11px] text-sky-400 hover:text-white"
                  >
                    {copiedCode ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
                    <span>{copiedCode ? 'कपि भयो' : 'Copy XML'}</span>
                  </button>
                </div>
                <pre className="font-mono text-[10px] text-slate-300 overflow-x-auto leading-relaxed max-h-40">
                  {androidManifestSnippet}
                </pre>
              </div>
            </div>
          )}

          {/* Footer */}
          <div className="pt-3 border-t border-slate-800 flex justify-end">
            <button
              onClick={onClose}
              className="py-2 px-5 rounded-xl bg-sky-500 hover:bg-sky-400 text-white font-bold text-xs shadow transition"
            >
              बन्द गर्नुहोस् (Close)
            </button>
          </div>
        </motion.div>
      </div>
    </AnimatePresence>
  );
};
