import React, { useState } from 'react';
import { 
  X, 
  Globe, 
  Volume2, 
  ShieldCheck, 
  Trash2, 
  Download, 
  User, 
  Vibrate, 
  Check, 
  Sparkles,
  Info,
  Brain,
  Plus
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { UserPreferences, LanguageMode, UserMemoryItem } from '../types/assistant';

interface SettingsModalProps {
  isOpen: boolean;
  onClose: () => void;
  preferences: UserPreferences;
  onUpdatePreferences: (updated: Partial<UserPreferences>) => void;
  onClearHistory: () => void;
  onExportData: () => void;
}

export const SettingsModal: React.FC<SettingsModalProps> = ({
  isOpen,
  onClose,
  preferences,
  onUpdatePreferences,
  onClearHistory,
  onExportData,
}) => {
  const [newMemoryInput, setNewMemoryInput] = useState('');

  if (!isOpen) return null;

  const handleAddMemory = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newMemoryInput.trim()) return;

    const newItem: UserMemoryItem = {
      id: 'mem-' + Date.now(),
      fact: newMemoryInput.trim(),
      category: 'personal',
      createdAt: Date.now(),
    };

    const existing = preferences.userMemories || [];
    onUpdatePreferences({
      userMemories: [...existing, newItem],
      enableMemory: true,
    });
    setNewMemoryInput('');
  };

  const handleDeleteMemory = (id: string) => {
    const existing = preferences.userMemories || [];
    onUpdatePreferences({
      userMemories: existing.filter((m) => m.id !== id),
    });
  };

  const handleClearAllMemories = () => {
    onUpdatePreferences({
      userMemories: [],
    });
  };

  return (
    <AnimatePresence>
      <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-black/80 backdrop-blur-md overflow-y-auto">
        <motion.div
          initial={{ opacity: 0, scale: 0.95, y: 15 }}
          animate={{ opacity: 1, scale: 1, y: 0 }}
          exit={{ opacity: 0, scale: 0.95, y: 15 }}
          className="relative w-full max-w-lg rounded-2xl bg-[#0b1329] border border-sky-500/30 p-4 sm:p-6 shadow-2xl text-slate-100 max-h-[92vh] overflow-y-auto"
        >
          {/* Header */}
          <div className="flex items-center justify-between pb-3 border-b border-slate-800">
            <div className="flex items-center gap-2">
              <div className="p-2 rounded-xl bg-sky-500/20 text-sky-400 border border-sky-500/30">
                <ShieldCheck className="w-5 h-5" />
              </div>
              <div>
                <h3 className="text-base sm:text-lg font-bold text-white">सेटिङहरू (Settings & Privacy)</h3>
                <p className="text-xs text-sky-300/80">भाषा, आवाज, सहमति र व्यक्तिगत स्मृति</p>
              </div>
            </div>
            <button
              onClick={onClose}
              className="p-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-400 hover:text-white transition"
            >
              <X className="w-5 h-5" />
            </button>
          </div>

          <div className="space-y-4 py-3">
            {/* 1. Consent Banner & Toggle */}
            <div className="p-3.5 rounded-xl bg-slate-900/90 border border-sky-500/25">
              <div className="flex items-center justify-between gap-3">
                <div>
                  <h4 className="text-xs sm:text-sm font-semibold text-white">
                    सहमति र डेटा बचत (Consent to Store Preferences)
                  </h4>
                  <p className="text-[11px] text-slate-400 mt-0.5">
                    तपाईंको सेटिङहरू र च्याट इतिहास यस डिभाइसमा सुरक्षित रूपमा राख्न सहमति दिनुहोस्।
                  </p>
                </div>
                <label className="relative inline-flex items-center cursor-pointer shrink-0">
                  <input
                    type="checkbox"
                    checked={preferences.hasGivenConsent}
                    onChange={(e) => onUpdatePreferences({ hasGivenConsent: e.target.checked })}
                    className="sr-only peer"
                  />
                  <div className="w-11 h-6 bg-slate-700 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:width-5 after:transition-all peer-checked:bg-sky-500"></div>
                </label>
              </div>
            </div>

            {/* 2. Consent-Based Personalized Memory */}
            <div className="p-3.5 rounded-xl bg-slate-900/80 border border-purple-500/30 space-y-2.5">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <Brain className="w-4 h-4 text-purple-400" />
                  <div>
                    <h4 className="text-xs sm:text-sm font-bold text-white">
                      सहमति-आधारित स्मृति (Consent-Based Memory)
                    </h4>
                    <p className="text-[11px] text-purple-300/80">
                      व्यक्तिगत रुचि र जानकारी सम्झिएर उत्तर निजीकृत गर्नुहोस्
                    </p>
                  </div>
                </div>
                <label className="relative inline-flex items-center cursor-pointer shrink-0">
                  <input
                    type="checkbox"
                    checked={preferences.enableMemory}
                    onChange={(e) => onUpdatePreferences({ enableMemory: e.target.checked })}
                    className="sr-only peer"
                  />
                  <div className="w-11 h-6 bg-slate-700 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:width-5 after:transition-all peer-checked:bg-purple-500"></div>
                </label>
              </div>

              {preferences.enableMemory && (
                <div className="pt-2 border-t border-slate-800 space-y-2">
                  {/* Add memory input */}
                  <form onSubmit={handleAddMemory} className="flex gap-1.5">
                    <input
                      type="text"
                      value={newMemoryInput}
                      onChange={(e) => setNewMemoryInput(e.target.value)}
                      placeholder="उदा: मलाई मसाला चिया मनपर्छ / My name is Prabin..."
                      className="flex-1 px-3 py-1.5 rounded-lg bg-slate-950 border border-slate-700 text-xs text-white placeholder:text-slate-500 focus:outline-none focus:border-purple-400"
                    />
                    <button
                      type="submit"
                      disabled={!newMemoryInput.trim()}
                      className="px-3 py-1.5 rounded-lg bg-purple-600 hover:bg-purple-500 text-white font-semibold text-xs flex items-center gap-1 disabled:opacity-50 transition"
                    >
                      <Plus className="w-3.5 h-3.5" />
                      <span>थप्नुहोस्</span>
                    </button>
                  </form>

                  {/* List of remembered items */}
                  {preferences.userMemories && preferences.userMemories.length > 0 ? (
                    <div className="space-y-1.5 max-h-36 overflow-y-auto pr-1">
                      {preferences.userMemories.map((mem) => (
                        <div
                          key={mem.id}
                          className="flex items-center justify-between p-2 rounded-lg bg-slate-950/70 border border-slate-800 text-xs text-slate-200"
                        >
                          <span className="truncate pr-2">💡 {mem.fact}</span>
                          <button
                            type="button"
                            onClick={() => handleDeleteMemory(mem.id)}
                            className="text-slate-400 hover:text-red-400 p-1 rounded"
                            title="मेटाउनुहोस्"
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                          </button>
                        </div>
                      ))}
                      <div className="flex justify-end pt-1">
                        <button
                          type="button"
                          onClick={handleClearAllMemories}
                          className="text-[11px] text-red-400 hover:underline"
                        >
                          सबै सम्झना मेटाउनुहोस् (Clear All Memories)
                        </button>
                      </div>
                    </div>
                  ) : (
                    <p className="text-[11px] text-slate-400 italic">
                      अहिले कुनै सम्झना सुरक्षित छैन। तपाईं मलाई च्याटमा "सम्झिराख कि..." भन्न सक्नुहुन्छ वा माथि थप्न सक्नुहुन्छ।
                    </p>
                  )}
                </div>
              )}
            </div>

            {/* 3. User Profile */}
            <div>
              <label className="block text-xs font-semibold text-sky-300 uppercase tracking-wider mb-1">
                तपाईंको नाम (Your Name / Preferred Greeting)
              </label>
              <input
                type="text"
                value={preferences.userName}
                onChange={(e) => onUpdatePreferences({ userName: e.target.value })}
                placeholder="उदा: प्रबिन (e.g. Prabin, Aayush)"
                className="w-full px-3.5 py-2 rounded-xl bg-slate-900 border border-slate-700 text-xs sm:text-sm text-white focus:outline-none focus:border-sky-400"
              />
            </div>

            {/* 4. Language Settings */}
            <div>
              <div className="flex items-center gap-1.5 mb-1.5">
                <Globe className="w-4 h-4 text-sky-400" />
                <label className="text-xs font-semibold text-sky-300 uppercase tracking-wider">
                  सहायकको भाषा (Assistant Language)
                </label>
              </div>
              <div className="grid grid-cols-3 gap-2">
                {[
                  { id: 'auto', label: 'Auto (द्विभाषी)', desc: 'नेपाली + English' },
                  { id: 'ne', label: 'नेपाली (Nepali)', desc: 'देवनागरी लिपि' },
                  { id: 'en', label: 'English', desc: 'Standard English' },
                ].map((item) => (
                  <button
                    key={item.id}
                    onClick={() => onUpdatePreferences({ language: item.id as LanguageMode })}
                    className={`p-2 rounded-xl border text-left transition ${
                      preferences.language === item.id
                        ? 'bg-sky-500/20 border-sky-400 text-white shadow-md shadow-sky-500/10'
                        : 'bg-slate-900 border-slate-800 text-slate-300 hover:border-slate-700'
                    }`}
                  >
                    <p className="text-xs font-bold">{item.label}</p>
                    <p className="text-[10px] text-slate-400 mt-0.5">{item.desc}</p>
                  </button>
                ))}
              </div>
            </div>

            {/* 5. Voice & Speech Settings */}
            <div className="pt-2 border-t border-slate-800 space-y-2.5">
              <div className="flex items-center gap-1.5">
                <Volume2 className="w-4 h-4 text-cyan-400" />
                <label className="text-xs font-semibold text-sky-300 uppercase tracking-wider">
                  आवाज सेटिङहरू (Voice & Speech Settings)
                </label>
              </div>

              {/* Auto speak replies toggle */}
              <div className="flex items-center justify-between py-1">
                <div>
                  <p className="text-xs sm:text-sm font-medium text-white">उत्तर स्वचालित रूपमा बोल्नुहोस्</p>
                  <p className="text-[11px] text-slate-400">Auto-play spoken voice replies</p>
                </div>
                <input
                  type="checkbox"
                  checked={preferences.autoSpeakReplies}
                  onChange={(e) => onUpdatePreferences({ autoSpeakReplies: e.target.checked })}
                  className="w-4 h-4 text-sky-500 bg-slate-900 border-slate-700 rounded focus:ring-sky-400"
                />
              </div>

              {/* TTS Engine */}
              <div>
                <label className="block text-[11px] font-medium text-slate-300 mb-1">
                  स्पीच इन्जिन (Speech Engine):
                </label>
                <div className="grid grid-cols-2 gap-2">
                  <button
                    onClick={() => onUpdatePreferences({ ttsEngine: 'gemini' })}
                    className={`p-2 rounded-xl border text-xs font-semibold text-left ${
                      preferences.ttsEngine === 'gemini'
                        ? 'bg-sky-500/20 border-sky-400 text-white'
                        : 'bg-slate-900 border-slate-800 text-slate-400'
                    }`}
                  >
                    Gemini 3.8 Flash-Lite TTS (Studio Quality)
                  </button>
                  <button
                    onClick={() => onUpdatePreferences({ ttsEngine: 'browser' })}
                    className={`p-2 rounded-xl border text-xs font-semibold text-left ${
                      preferences.ttsEngine === 'browser'
                        ? 'bg-sky-500/20 border-sky-400 text-white'
                        : 'bg-slate-900 border-slate-800 text-slate-400'
                    }`}
                  >
                    Device / Browser Voice (Offline Friendly)
                  </button>
                </div>
              </div>

              {/* Voice Personas for Gemini */}
              {preferences.ttsEngine === 'gemini' && (
                <div>
                  <label className="block text-[11px] font-medium text-slate-300 mb-1">
                    आवाजको शैली (Voice Persona):
                  </label>
                  <div className="grid grid-cols-4 gap-1.5">
                    {(['Kore', 'Zephyr', 'Puck', 'Fenrir'] as const).map((voice) => (
                      <button
                        key={voice}
                        onClick={() => onUpdatePreferences({ geminiVoice: voice })}
                        className={`p-1.5 rounded-lg border text-center text-xs font-semibold ${
                          preferences.geminiVoice === voice
                            ? 'bg-cyan-500/25 border-cyan-400 text-cyan-200'
                            : 'bg-slate-900 border-slate-800 text-slate-400 hover:text-white'
                        }`}
                      >
                        {voice}
                      </button>
                    ))}
                  </div>
                </div>
              )}

              {/* Speech rate slider */}
              <div>
                <div className="flex justify-between text-xs text-slate-300 mb-1">
                  <span>बोल्ने गति (Speech Speed):</span>
                  <span>{preferences.speechRate}x</span>
                </div>
                <input
                  type="range"
                  min="0.75"
                  max="1.5"
                  step="0.05"
                  value={preferences.speechRate}
                  onChange={(e) => onUpdatePreferences({ speechRate: parseFloat(e.target.value) })}
                  className="w-full accent-sky-500 h-1.5 bg-slate-800 rounded-lg cursor-pointer"
                />
              </div>

              {/* Haptic feedback */}
              <div className="flex items-center justify-between py-1.5 border-t border-slate-800">
                <div className="flex items-center gap-2">
                  <Vibrate className="w-4 h-4 text-sky-400" />
                  <div>
                    <p className="text-xs font-medium text-white">एन्ड्रोइड कम्पन (Haptic Vibration)</p>
                    <p className="text-[11px] text-slate-400">Vibration feedback on tap</p>
                  </div>
                </div>
                <input
                  type="checkbox"
                  checked={preferences.hapticFeedback}
                  onChange={(e) => onUpdatePreferences({ hapticFeedback: e.target.checked })}
                  className="w-4 h-4 text-sky-500 bg-slate-900 border-slate-700 rounded focus:ring-sky-400"
                />
              </div>
            </div>

            {/* 6. Privacy & Data Controls */}
            <div className="pt-2 border-t border-slate-800 space-y-2">
              <div className="flex items-center gap-1.5">
                <ShieldCheck className="w-4 h-4 text-emerald-400" />
                <label className="text-xs font-semibold text-sky-300 uppercase tracking-wider">
                  गोपनीयता र डेटा व्यवस्थापन (Privacy & Data Management)
                </label>
              </div>

              <div className="grid grid-cols-2 gap-2">
                <button
                  onClick={onExportData}
                  className="flex items-center justify-center gap-1.5 py-2 px-3 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-medium border border-slate-700 transition"
                >
                  <Download className="w-3.5 h-3.5 text-sky-400" />
                  <span>डेटा डाउनलोड (Export JSON)</span>
                </button>
                <button
                  onClick={onClearHistory}
                  className="flex items-center justify-center gap-1.5 py-2 px-3 rounded-xl bg-red-950/60 hover:bg-red-900/80 text-red-200 text-xs font-medium border border-red-500/30 transition"
                >
                  <Trash2 className="w-3.5 h-3.5 text-red-400" />
                  <span>इतिहास मेटाउनुहोस् (Clear)</span>
                </button>
              </div>
            </div>
          </div>

          {/* Footer */}
          <div className="pt-3 border-t border-slate-800 flex justify-end">
            <button
              onClick={onClose}
              className="py-2 px-5 rounded-xl bg-sky-500 hover:bg-sky-400 text-white font-bold text-xs shadow-lg shadow-sky-500/20 transition"
            >
              बन्द गर्नुहोस् (Save & Close)
            </button>
          </div>
        </motion.div>
      </div>
    </AnimatePresence>
  );
};
