import React from 'react';
import { Mic, MicOff, Volume2, Sparkles, AlertCircle, Compass } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { UserPreferences } from '../types/assistant';

interface GlowingMicHeroProps {
  isListening: boolean;
  isSpeaking: boolean;
  isLoading: boolean;
  interimTranscript: string;
  errorMessage: string | null;
  onToggleListening: () => void;
  onQuickQuery: (query: string) => void;
  preferences: UserPreferences;
  onUpdatePreferences: (updated: Partial<UserPreferences>) => void;
}

export const GlowingMicHero: React.FC<GlowingMicHeroProps> = ({
  isListening,
  isSpeaking,
  isLoading,
  interimTranscript,
  errorMessage,
  onToggleListening,
  onQuickQuery,
  preferences,
  onUpdatePreferences,
}) => {
  const quickActions = [
    { label: 'कस्तो छ साथी? (How are you?)', query: 'कस्तो छ साथी?' },
    { label: 'YouTube खोल (Open App)', query: 'YouTube एप खोल' },
    { label: 'आमालाई फोन गर (Phone Call)', query: 'आमालाई ९८०१२३४५६७ मा कल गर' },
    { label: 'बिहान ६ बजे अलार्म (Alarm)', query: 'भोलि बिहान ६:०० बजेको लागि अलार्म राखिदेऊ' },
    { label: '५ मिनेट टाइमर (Timer)', query: '५ मिनेटको लागि टाइमर राख' },
    { label: 'सन्देश ड्राफ्ट गर (Draft)', query: 'Shyam लाई ह्वाट्सएपमा ५ मिनेट ढिलो हुन्छु भनेर ड्राफ्ट गर' },
    { label: 'सम्झिराख (Remember Memory)', query: 'सम्झिराख कि मलाई कालो चिया मनपर्छ' },
    { label: 'काठमाडौँको मौसम (Weather)', query: 'काठमाडौँको आजको मौसम कस्तो छ?' },
  ];

  return (
    <div className="relative w-full flex flex-col items-center justify-center pt-3 pb-5 px-4 overflow-hidden">
      {/* Background ambient glowing orbs */}
      <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-72 h-72 bg-sky-500/10 rounded-full blur-3xl pointer-events-none" />
      <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-48 h-48 bg-cyan-400/15 rounded-full blur-2xl pointer-events-none" />

      {/* Spoken / Listening Status Badge */}
      <div className="mb-4 flex items-center justify-center">
        <AnimatePresence mode="wait">
          {isListening ? (
            <motion.div
              key="listening"
              initial={{ opacity: 0, y: -8 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: 8 }}
              className="flex items-center gap-2 px-3 py-1 rounded-full bg-red-500/20 border border-red-500/40 text-red-200 text-xs font-semibold shadow-lg shadow-red-500/10"
            >
              <span className="w-2 h-2 rounded-full bg-red-400 animate-ping" />
              <span>सुन्दैछु... (Listening in {preferences.speechInputLanguage === 'ne-NP' ? 'Nepali' : 'English'})</span>
            </motion.div>
          ) : isSpeaking ? (
            <motion.div
              key="speaking"
              initial={{ opacity: 0, y: -8 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: 8 }}
              className="flex items-center gap-2 px-3 py-1 rounded-full bg-emerald-500/20 border border-emerald-500/40 text-emerald-200 text-xs font-semibold shadow-lg shadow-emerald-500/10"
            >
              <Volume2 className="w-3.5 h-3.5 text-emerald-300 animate-bounce" />
              <span>बोल्दैछु... (Replying with Voice)</span>
            </motion.div>
          ) : isLoading ? (
            <motion.div
              key="loading"
              initial={{ opacity: 0, y: -8 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: 8 }}
              className="flex items-center gap-2 px-3 py-1 rounded-full bg-cyan-500/20 border border-cyan-500/40 text-cyan-200 text-xs font-semibold shadow-lg shadow-cyan-500/10"
            >
              <Sparkles className="w-3.5 h-3.5 text-cyan-300 animate-spin" />
              <span>सोच्दैछु... (Thinking & Searching)</span>
            </motion.div>
          ) : (
            <motion.div
              key="ready"
              initial={{ opacity: 0, y: -8 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: 8 }}
              className="flex items-center gap-2 px-3 py-1 rounded-full bg-slate-800/80 border border-slate-700/80 text-slate-300 text-xs font-medium"
            >
              <span className="w-2 h-2 rounded-full bg-sky-400" />
              <span>तयार छु • माइक थिचेर बोल्नुहोस् (Tap mic to speak)</span>
            </motion.div>
          )}
        </AnimatePresence>
      </div>

      {/* Big Glowing Microphone Button with Animated Ripple Waves */}
      <div className="relative flex items-center justify-center my-3">
        {/* Pulsing Concentric Outer Rings */}
        <AnimatePresence>
          {isListening && (
            <>
              <motion.div
                initial={{ scale: 0.9, opacity: 0.8 }}
                animate={{ scale: 1.6, opacity: 0 }}
                transition={{ duration: 1.8, repeat: Infinity, ease: 'easeOut' }}
                className="absolute w-24 h-24 sm:w-28 sm:h-28 rounded-full border-2 border-red-500/50 pointer-events-none"
              />
              <motion.div
                initial={{ scale: 0.9, opacity: 0.8 }}
                animate={{ scale: 2.1, opacity: 0 }}
                transition={{ duration: 1.8, repeat: Infinity, ease: 'easeOut', delay: 0.4 }}
                className="absolute w-24 h-24 sm:w-28 sm:h-28 rounded-full border border-sky-400/40 pointer-events-none"
              />
            </>
          )}
        </AnimatePresence>

        {/* Ambient Ring */}
        <div
          className={`absolute w-28 h-28 sm:w-32 sm:h-32 rounded-full transition-all duration-700 pointer-events-none ${
            isListening
              ? 'bg-gradient-to-r from-red-600/30 to-amber-500/30 blur-xl scale-125'
              : isSpeaking
              ? 'bg-gradient-to-r from-emerald-500/30 to-cyan-500/30 blur-xl scale-110'
              : 'bg-gradient-to-r from-sky-500/20 via-blue-600/20 to-cyan-400/20 blur-lg'
          }`}
        />

        {/* Core Microphone Button */}
        <button
          onClick={onToggleListening}
          disabled={isLoading}
          className={`relative z-10 flex items-center justify-center w-20 h-20 sm:w-24 sm:h-24 rounded-full transition-all duration-300 transform active:scale-95 shadow-2xl focus:outline-none focus:ring-4 focus:ring-sky-400/40 ${
            isListening
              ? 'bg-gradient-to-br from-red-500 via-rose-600 to-amber-600 text-white shadow-red-500/50 ring-4 ring-red-400/40'
              : isSpeaking
              ? 'bg-gradient-to-br from-emerald-500 via-teal-600 to-cyan-700 text-white shadow-emerald-500/40'
              : 'bg-gradient-to-br from-cyan-400 via-sky-500 to-blue-700 text-white shadow-sky-500/40 hover:shadow-cyan-400/60 glow-blue'
          }`}
          title={isListening ? 'Stop listening' : 'Start voice command'}
        >
          {isListening ? (
            <motion.div
              animate={{ scale: [1, 1.15, 1] }}
              transition={{ repeat: Infinity, duration: 1.2 }}
            >
              <Mic className="w-9 h-9 sm:w-11 sm:h-11" />
            </motion.div>
          ) : isSpeaking ? (
            <Volume2 className="w-8 h-8 sm:w-10 sm:h-10 animate-pulse" />
          ) : (
            <Mic className="w-8 h-8 sm:w-10 sm:h-10" />
          )}
        </button>
      </div>

      {/* Dynamic Sound Wave Bars */}
      {(isListening || isSpeaking) && (
        <div className="flex items-center gap-1.5 h-8 my-2">
          <div className="w-1 bg-sky-400 rounded-full animate-wave-1" />
          <div className="w-1 bg-cyan-300 rounded-full animate-wave-2" />
          <div className="w-1 bg-blue-400 rounded-full animate-wave-3" />
          <div className="w-1 bg-sky-300 rounded-full animate-wave-4" />
          <div className="w-1 bg-cyan-400 rounded-full animate-wave-5" />
          <div className="w-1 bg-blue-300 rounded-full animate-wave-2" />
          <div className="w-1 bg-sky-400 rounded-full animate-wave-1" />
        </div>
      )}

      {/* Interim Live Transcript Display */}
      {isListening && interimTranscript && (
        <motion.div
          initial={{ opacity: 0, scale: 0.95 }}
          animate={{ opacity: 1, scale: 1 }}
          className="max-w-md w-full my-2 px-3.5 py-2 rounded-xl bg-slate-900/90 border border-sky-500/30 text-center shadow-lg backdrop-blur-md"
        >
          <p className="text-xs text-sky-400 font-semibold mb-0.5">तपाईं बोल्दै हुनुहुन्छ (Speaking):</p>
          <p className="text-sm font-medium text-slate-100 italic">"{interimTranscript}"</p>
        </motion.div>
      )}

      {/* Error message */}
      {errorMessage && (
        <div className="flex items-center gap-2 max-w-md mt-2 px-3 py-1.5 rounded-lg bg-red-950/70 border border-red-500/40 text-red-200 text-xs">
          <AlertCircle className="w-4 h-4 text-red-400 shrink-0" />
          <span>{errorMessage}</span>
        </div>
      )}

      {/* Voice language toggle chip */}
      <div className="flex items-center gap-2 mt-2 text-xs text-slate-400">
        <span>बोलीको भाषा (Mic Voice):</span>
        <div className="inline-flex rounded-lg bg-slate-800/90 p-0.5 border border-slate-700">
          <button
            onClick={() => onUpdatePreferences({ speechInputLanguage: 'ne-NP' })}
            className={`px-2 py-0.5 rounded text-xs font-semibold transition ${
              preferences.speechInputLanguage === 'ne-NP'
                ? 'bg-sky-500 text-white shadow'
                : 'text-slate-400 hover:text-white'
            }`}
          >
            नेपाली (ne-NP)
          </button>
          <button
            onClick={() => onUpdatePreferences({ speechInputLanguage: 'en-US' })}
            className={`px-2 py-0.5 rounded text-xs font-semibold transition ${
              preferences.speechInputLanguage === 'en-US'
                ? 'bg-sky-500 text-white shadow'
                : 'text-slate-400 hover:text-white'
            }`}
          >
            English (en-US)
          </button>
        </div>
      </div>

      {/* Quick Prompt Suggestions */}
      <div className="w-full max-w-2xl mt-4">
        <div className="flex items-center gap-1.5 mb-2 text-xs font-medium text-sky-300/80">
          <Compass className="w-3.5 h-3.5" />
          <span>सोध्न सकिने प्रश्नहरू र कार्यहरू (Suggestions):</span>
        </div>
        <div className="flex flex-wrap gap-1.5 sm:gap-2">
          {quickActions.map((action, idx) => (
            <button
              key={idx}
              onClick={() => onQuickQuery(action.query)}
              className="px-2.5 py-1.5 rounded-lg bg-slate-800/60 hover:bg-slate-700/80 text-slate-200 hover:text-sky-300 border border-slate-700/60 hover:border-sky-500/40 text-xs transition duration-150 text-left"
            >
              {action.label}
            </button>
          ))}
        </div>
      </div>
    </div>
  );
};
