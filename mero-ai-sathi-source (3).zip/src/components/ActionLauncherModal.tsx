import React, { useState } from 'react';
import { 
  X, 
  Grid, 
  Phone, 
  AlarmClock, 
  MessageSquare, 
  Search, 
  Youtube, 
  MapPin, 
  Camera, 
  Settings, 
  Calculator, 
  Calendar, 
  Globe, 
  Play,
  Clock,
  Sparkles
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { POPULAR_ANDROID_APPS, executePhoneCall, executeSendMessage, executeOpenApp, executeSetAlarm } from '../utils/androidActions';
import { ActionPayload } from '../types/assistant';

interface ActionLauncherModalProps {
  isOpen: boolean;
  onClose: () => void;
  onRequestActionConfirmation: (action: ActionPayload) => void;
  onTriggerAlarmTimer: (seconds: number, label: string) => void;
}

export const ActionLauncherModal: React.FC<ActionLauncherModalProps> = ({
  isOpen,
  onClose,
  onRequestActionConfirmation,
  onTriggerAlarmTimer,
}) => {
  const [activeTab, setActiveTab] = useState<'apps' | 'alarm' | 'call' | 'message'>('apps');

  // Alarm form states
  const [alarmTime, setAlarmTime] = useState('06:30');
  const [alarmLabel, setAlarmLabel] = useState('बिहानी अलार्म');

  // Phone Call form states
  const [phoneNumber, setPhoneNumber] = useState('');
  const [contactName, setContactName] = useState('');

  // Message form states
  const [msgRecipient, setMsgRecipient] = useState('');
  const [msgText, setMsgText] = useState('');
  const [msgPlatform, setMsgPlatform] = useState<'whatsapp' | 'sms'>('whatsapp');

  if (!isOpen) return null;

  const handleAppClick = (app: (typeof POPULAR_ANDROID_APPS)[0]) => {
    executeOpenApp(app.name, app.packageName, app.webFallback);
  };

  const handleSetAlarm = (e: React.FormEvent) => {
    e.preventDefault();
    const [hoursStr, minutesStr] = alarmTime.split(':');
    const hours = parseInt(hoursStr || '6', 10);
    const minutes = parseInt(minutesStr || '30', 10);

    // Prompt action confirmation or directly set
    onRequestActionConfirmation({
      type: 'SET_ALARM',
      title: `अलार्म सेट गर्नुहोस्: ${alarmTime}`,
      description: `समय ${alarmTime} मा '${alarmLabel}' अलार्म सुरु गरिनेछ।`,
      sensitive: false,
      params: {
        time: alarmTime,
        hours,
        minutes,
        label: alarmLabel,
      },
    });
    onClose();
  };

  const handleStartCall = (e: React.FormEvent) => {
    e.preventDefault();
    if (!phoneNumber.trim()) return;

    onRequestActionConfirmation({
      type: 'CALL',
      title: `फोन कल सुरु गर्नुहोस्: ${phoneNumber}`,
      description: `तपाईंको एन्ड्रोइड डायलर मार्फत ${phoneNumber} ${contactName ? `(${contactName})` : ''} लाई कल जोडिन्छ।`,
      sensitive: true,
      params: {
        phoneNumber: phoneNumber.trim(),
        contactName: contactName.trim(),
      },
    });
    onClose();
  };

  const handleSendMessage = (e: React.FormEvent) => {
    e.preventDefault();
    if (!msgRecipient.trim() || !msgText.trim()) return;

    onRequestActionConfirmation({
      type: 'SEND_MESSAGE',
      title: `सन्देश पठाउनुहोस् (${msgPlatform.toUpperCase()}): ${msgRecipient}`,
      description: `${msgRecipient} लाई सन्देश पठाइनेछ: "${msgText}"`,
      sensitive: true,
      params: {
        recipient: msgRecipient.trim(),
        text: msgText.trim(),
        platform: msgPlatform,
      },
    });
    onClose();
  };

  const getAppIcon = (iconName: string) => {
    switch (iconName) {
      case 'Youtube':
        return <Youtube className="w-5 h-5 text-red-400" />;
      case 'MessageSquare':
        return <MessageSquare className="w-5 h-5 text-emerald-400" />;
      case 'MapPin':
        return <MapPin className="w-5 h-5 text-amber-400" />;
      case 'Phone':
        return <Phone className="w-5 h-5 text-sky-400" />;
      case 'Camera':
        return <Camera className="w-5 h-5 text-purple-400" />;
      case 'AlarmClock':
        return <AlarmClock className="w-5 h-5 text-rose-400" />;
      case 'Calendar':
        return <Calendar className="w-5 h-5 text-blue-400" />;
      case 'Calculator':
        return <Calculator className="w-5 h-5 text-teal-400" />;
      case 'Globe':
        return <Globe className="w-5 h-5 text-cyan-400" />;
      case 'Settings':
        return <Settings className="w-5 h-5 text-slate-300" />;
      default:
        return <Play className="w-5 h-5 text-sky-400" />;
    }
  };

  return (
    <AnimatePresence>
      <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-md overflow-y-auto">
        <motion.div
          initial={{ opacity: 0, scale: 0.95, y: 15 }}
          animate={{ opacity: 1, scale: 1, y: 0 }}
          exit={{ opacity: 0, scale: 0.95, y: 15 }}
          className="relative w-full max-w-xl rounded-2xl bg-[#091224] border border-sky-500/30 p-5 sm:p-6 shadow-2xl text-slate-100 max-h-[90vh] overflow-y-auto"
        >
          {/* Header */}
          <div className="flex items-center justify-between pb-3 border-b border-slate-800">
            <div className="flex items-center gap-2">
              <div className="p-2 rounded-xl bg-sky-500/20 text-sky-400 border border-sky-500/30">
                <Grid className="w-5 h-5" />
              </div>
              <div>
                <h3 className="text-lg font-bold text-white">एन्ड्रोइड हब (Android Action Hub)</h3>
                <p className="text-xs text-sky-300/80">एप खोल्ने, अलार्म, कल र सन्देश सुविधाहरू</p>
              </div>
            </div>
            <button
              onClick={onClose}
              className="p-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-400 hover:text-white transition"
            >
              <X className="w-5 h-5" />
            </button>
          </div>

          {/* Navigation Tabs */}
          <div className="grid grid-cols-4 gap-1.5 my-4 p-1 rounded-xl bg-slate-900 border border-slate-800">
            {[
              { id: 'apps', label: 'एपहरू (Apps)' },
              { id: 'alarm', label: 'अलार्म (Alarm)' },
              { id: 'call', label: 'कल (Call)' },
              { id: 'message', label: 'सन्देश (SMS)' },
            ].map((tab) => (
              <button
                key={tab.id}
                onClick={() => setActiveTab(tab.id as any)}
                className={`py-2 px-1 text-center rounded-lg text-xs font-semibold transition ${
                  activeTab === tab.id
                    ? 'bg-sky-500 text-white shadow-md'
                    : 'text-slate-400 hover:text-white'
                }`}
              >
                {tab.label}
              </button>
            ))}
          </div>

          {/* Tab 1: Apps */}
          {activeTab === 'apps' && (
            <div>
              <p className="text-xs text-slate-400 mb-3">
                एन्ड्रोइड फोनमा इन्स्टल भएका एपहरू सिधै खोल्नुहोस् (Opens via native Android intent with web fallback):
              </p>
              <div className="grid grid-cols-2 sm:grid-cols-3 gap-2.5">
                {POPULAR_ANDROID_APPS.map((app) => (
                  <button
                    key={app.id}
                    onClick={() => handleAppClick(app)}
                    className="p-3 rounded-xl bg-slate-900/80 hover:bg-slate-800/90 border border-slate-800 hover:border-sky-500/40 text-left transition flex items-start gap-2.5 group active:scale-95"
                  >
                    <div className="p-2 rounded-lg bg-slate-800 group-hover:bg-sky-950/60 transition shrink-0">
                      {getAppIcon(app.icon)}
                    </div>
                    <div className="overflow-hidden">
                      <p className="text-xs font-bold text-white truncate">{app.nepaliName}</p>
                      <p className="text-[11px] text-slate-400 truncate">{app.name}</p>
                    </div>
                  </button>
                ))}
              </div>
            </div>
          )}

          {/* Tab 2: Alarm */}
          {activeTab === 'alarm' && (
            <form onSubmit={handleSetAlarm} className="space-y-4">
              <div className="p-3.5 rounded-xl bg-slate-900/80 border border-sky-500/20">
                <p className="text-xs text-sky-300 mb-1 font-semibold">एन्ड्रोइड घडी / अलार्म</p>
                <p className="text-xs text-slate-400">
                  अलार्मको समय छान्नुहोस् र एन्ड्रोइड घडी एपमा सेट गर्नुहोस् वा इन-एप टाइमर सुरु गर्नुहोस्।
                </p>
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-1.5">
                  अलार्मको समय (Alarm Time):
                </label>
                <input
                  type="time"
                  value={alarmTime}
                  onChange={(e) => setAlarmTime(e.target.value)}
                  className="w-full px-4 py-2.5 rounded-xl bg-slate-900 border border-slate-700 text-lg font-bold text-white text-center focus:outline-none focus:border-sky-400"
                  required
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-1.5">
                  अलार्मको नाम / लेबल (Label):
                </label>
                <input
                  type="text"
                  value={alarmLabel}
                  onChange={(e) => setAlarmLabel(e.target.value)}
                  placeholder="उदा: बिहानी योग, कार्यालय समय"
                  className="w-full px-3.5 py-2 rounded-xl bg-slate-900 border border-slate-700 text-sm text-white focus:outline-none focus:border-sky-400"
                />
              </div>

              <div className="pt-2 flex gap-2">
                <button
                  type="submit"
                  className="flex-1 py-2.5 px-4 rounded-xl bg-gradient-to-r from-amber-500 to-orange-600 hover:from-amber-400 hover:to-orange-500 text-white font-bold text-xs shadow-lg shadow-amber-500/20 transition flex items-center justify-center gap-1.5"
                >
                  <AlarmClock className="w-4 h-4" />
                  <span>एन्ड्रोइड अलार्म राख्नुहोस्</span>
                </button>
                <button
                  type="button"
                  onClick={() => {
                    onTriggerAlarmTimer(600, alarmLabel || '10 Min Timer');
                    onClose();
                  }}
                  className="py-2.5 px-3 rounded-xl bg-slate-800 hover:bg-slate-700 text-sky-300 font-semibold text-xs border border-slate-700 transition"
                  title="१० मिनेटको इन-एप टाइमर"
                >
                  १० मिनेट टाइमर
                </button>
              </div>
            </form>
          )}

          {/* Tab 3: Phone Call */}
          {activeTab === 'call' && (
            <form onSubmit={handleStartCall} className="space-y-4">
              <div className="p-3.5 rounded-xl bg-slate-900/80 border border-emerald-500/20">
                <p className="text-xs text-emerald-300 mb-1 font-semibold">फोन कल इनिसिएसन</p>
                <p className="text-xs text-slate-400">
                  फोन नम्बर वा नेपालका आकस्मिक सेवाहरूमा कल लगाउनुहोस्। सुरु गर्नुअघि सुरक्षा पुष्टिकरण सोधिनेछ।
                </p>
              </div>

              {/* Quick Emergency Numbers in Nepal */}
              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-1.5">
                  नेपालका आकस्मिक नम्बरहरू (Emergency Numbers):
                </label>
                <div className="grid grid-cols-3 gap-2">
                  {[
                    { name: 'प्रहरी (Police)', num: '100' },
                    { name: 'दमकल (Fire)', num: '101' },
                    { name: 'एम्बुलेन्स (Ambulance)', num: '102' },
                  ].map((em) => (
                    <button
                      type="button"
                      key={em.num}
                      onClick={() => {
                        setPhoneNumber(em.num);
                        setContactName(em.name);
                      }}
                      className="p-2 rounded-xl bg-slate-900 border border-slate-800 hover:border-emerald-500/50 text-left transition"
                    >
                      <p className="text-xs font-bold text-white">{em.num}</p>
                      <p className="text-[10px] text-slate-400">{em.name}</p>
                    </button>
                  ))}
                </div>
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-1.5">
                  सम्पर्कको नाम (Contact Name - Optional):
                </label>
                <input
                  type="text"
                  value={contactName}
                  onChange={(e) => setContactName(e.target.value)}
                  placeholder="उदा: आमा, डाक्टर, साथी"
                  className="w-full px-3.5 py-2 rounded-xl bg-slate-900 border border-slate-700 text-sm text-white focus:outline-none focus:border-sky-400"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-1.5">
                  फोन नम्बर (Phone Number):
                </label>
                <input
                  type="tel"
                  value={phoneNumber}
                  onChange={(e) => setPhoneNumber(e.target.value)}
                  placeholder="उदा: 9801234567 वा +977..."
                  className="w-full px-3.5 py-2 rounded-xl bg-slate-900 border border-slate-700 text-sm font-mono text-white focus:outline-none focus:border-sky-400"
                  required
                />
              </div>

              <button
                type="submit"
                className="w-full py-2.5 px-4 rounded-xl bg-gradient-to-r from-emerald-500 to-teal-600 hover:from-emerald-400 hover:to-teal-500 text-white font-bold text-xs shadow-lg shadow-emerald-500/20 transition flex items-center justify-center gap-1.5"
              >
                <Phone className="w-4 h-4" />
                <span>पुष्टिकरण सोध्नुहोस् र कल गर्नुहोस्</span>
              </button>
            </form>
          )}

          {/* Tab 4: Message */}
          {activeTab === 'message' && (
            <form onSubmit={handleSendMessage} className="space-y-4">
              <div className="p-3.5 rounded-xl bg-slate-900/80 border border-cyan-500/20">
                <p className="text-xs text-cyan-300 mb-1 font-semibold">सन्देश पठाउनुहोस्</p>
                <p className="text-xs text-slate-400">
                  ह्वाट्सएप वा सामान्य SMS मार्फत पूर्व-तयार सन्देश पठाउनुहोस्।
                </p>
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-1.5">
                  माध्यम छान्नुहोस् (Platform):
                </label>
                <div className="grid grid-cols-2 gap-2">
                  <button
                    type="button"
                    onClick={() => setMsgPlatform('whatsapp')}
                    className={`py-2 px-3 rounded-xl border text-xs font-bold transition flex items-center justify-center gap-1.5 ${
                      msgPlatform === 'whatsapp'
                        ? 'bg-emerald-500/20 border-emerald-400 text-emerald-300'
                        : 'bg-slate-900 border-slate-800 text-slate-400'
                    }`}
                  >
                    <MessageSquare className="w-4 h-4 text-emerald-400" />
                    <span>WhatsApp</span>
                  </button>
                  <button
                    type="button"
                    onClick={() => setMsgPlatform('sms')}
                    className={`py-2 px-3 rounded-xl border text-xs font-bold transition flex items-center justify-center gap-1.5 ${
                      msgPlatform === 'sms'
                        ? 'bg-cyan-500/20 border-cyan-400 text-cyan-300'
                        : 'bg-slate-900 border-slate-800 text-slate-400'
                    }`}
                  >
                    <Phone className="w-4 h-4 text-cyan-400" />
                    <span>SMS</span>
                  </button>
                </div>
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-1.5">
                  फोन नम्बर (Recipient Phone Number):
                </label>
                <input
                  type="tel"
                  value={msgRecipient}
                  onChange={(e) => setMsgRecipient(e.target.value)}
                  placeholder="उदा: 9841234567"
                  className="w-full px-3.5 py-2 rounded-xl bg-slate-900 border border-slate-700 text-sm font-mono text-white focus:outline-none focus:border-sky-400"
                  required
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-1.5">
                  सन्देश सामग्री (Message Body):
                </label>
                <textarea
                  value={msgText}
                  onChange={(e) => setMsgText(e.target.value)}
                  rows={3}
                  placeholder="उदा: नमस्ते, म आज अलि ढिलो आउँछु।"
                  className="w-full px-3.5 py-2 rounded-xl bg-slate-900 border border-slate-700 text-sm text-white focus:outline-none focus:border-sky-400 resize-none"
                  required
                />
              </div>

              <button
                type="submit"
                className="w-full py-2.5 px-4 rounded-xl bg-gradient-to-r from-cyan-500 to-blue-600 hover:from-cyan-400 hover:to-blue-500 text-white font-bold text-xs shadow-lg shadow-cyan-500/20 transition flex items-center justify-center gap-1.5"
              >
                <MessageSquare className="w-4 h-4" />
                <span>पुष्टिकरण सोध्नुहोस् र सन्देश पठाउनुहोस्</span>
              </button>
            </form>
          )}

          {/* Footer */}
          <div className="pt-3 border-t border-slate-800 flex justify-end">
            <button
              onClick={onClose}
              className="py-1.5 px-4 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs font-semibold transition"
            >
              बन्द गर्नुहोस् (Close)
            </button>
          </div>
        </motion.div>
      </div>
    </AnimatePresence>
  );
};
