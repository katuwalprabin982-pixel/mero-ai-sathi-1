/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect, useCallback } from 'react';
import { Header } from './components/Header';
import { GlowingMicHero } from './components/GlowingMicHero';
import { ChatScreen } from './components/ChatScreen';
import { ConfirmationModal } from './components/ConfirmationModal';
import { SettingsModal } from './components/SettingsModal';
import { PermissionsGuideModal } from './components/PermissionsGuideModal';
import { ActionLauncherModal } from './components/ActionLauncherModal';
import { ActiveTimerBar } from './components/ActiveTimerBar';
import { OfflineIndicator } from './components/OfflineIndicator';
import { useVoiceRecognition } from './hooks/useVoiceRecognition';
import { useSpeechSynthesis } from './hooks/useSpeechSynthesis';
import { routeCommand } from './utils/commandRouter';
import { 
  Message, 
  ActionPayload, 
  UserPreferences, 
  ActiveAssistantTimer,
  ActionExecutionDetail 
} from './types/assistant';
import { 
  executePhoneCall, 
  executeSendMessage, 
  executeOpenApp, 
  executeSetAlarm, 
  triggerHaptic, 
  playChime,
  sendAndroidNotification 
} from './utils/androidActions';

const STORAGE_KEY_PREFS = 'mero_ai_sathi_prefs_v1';
const STORAGE_KEY_MSGS = 'mero_ai_sathi_msgs_v1';

const DEFAULT_PREFERENCES: UserPreferences = {
  hasGivenConsent: true,
  userName: '',
  language: 'auto',
  speechInputLanguage: 'ne-NP',
  autoSpeakReplies: true,
  ttsEngine: 'gemini',
  geminiVoice: 'Kore',
  speechRate: 1.0,
  speechPitch: 1.0,
  hapticFeedback: true,
  saveHistory: true,
  enableMemory: true,
  userMemories: [
    {
      id: 'mem-default-1',
      fact: 'प्रयोगकर्ताले नेपाली र अंग्रेजी दुबै भाषा मन पराउनुहुन्छ (Bilingual preference)',
      category: 'preference',
      createdAt: Date.now(),
    },
  ],
  highContrast: false,
};

const INITIAL_GREETING: Message = {
  id: 'welcome-1',
  role: 'assistant',
  content: `नमस्ते! म तपाईंको "मेरो एआई साथी" (Mero AI Sathi) हुँ। 🇳🇵\n\nम वास्तविक एन्ड्रोइड कार्यहरू र सामान्य कुराकानी बीच भेद छुट्याउने कमाण्ड राउटर (Command Router) सहित सुसज्जित छु:\n\n• फोन कल: "आमालाई ९८०१२३४५६७ मा फोन गर" (डायलरमा ह्यान्डअफ)\n• एप खोल्ने: "YouTube खोल", "WhatsApp खोल", "क्यामेरा खोल"\n• अलार्म र टाइमर: "बिहान ६ बजे अलार्म राख" वा "१० मिनेट टाइमर"\n• सामान्य कुराकानी: "कस्तो छ साथी?", "YouTube भनेको के हो?" (यसमा एप खुल्दैन, जानकारी दिइन्छ)`,
  timestamp: Date.now(),
};

export default function App() {
  // Load preferences from localStorage
  const [preferences, setPreferences] = useState<UserPreferences>(() => {
    try {
      const stored = localStorage.getItem(STORAGE_KEY_PREFS);
      if (stored) {
        return { ...DEFAULT_PREFERENCES, ...JSON.parse(stored) };
      }
    } catch {}
    return DEFAULT_PREFERENCES;
  });

  // Load chat history if consent is given
  const [messages, setMessages] = useState<Message[]>(() => {
    try {
      const stored = localStorage.getItem(STORAGE_KEY_MSGS);
      if (stored) {
        const parsed = JSON.parse(stored);
        if (Array.isArray(parsed) && parsed.length > 0) return parsed;
      }
    } catch {}
    return [INITIAL_GREETING];
  });

  const [isLoading, setIsLoading] = useState(false);
  const [activeActionForConfirmation, setActiveActionForConfirmation] = useState<ActionPayload | null>(null);
  const [activeActionMessageId, setActiveActionMessageId] = useState<string | null>(null);
  const [activeTimers, setActiveTimers] = useState<ActiveAssistantTimer[]>([]);

  // Modals state
  const [isSettingsOpen, setIsSettingsOpen] = useState(false);
  const [isPermissionsGuideOpen, setIsPermissionsGuideOpen] = useState(false);
  const [isActionLauncherOpen, setIsActionLauncherOpen] = useState(false);

  // Speech hooks
  const { isSpeaking, speak, stop: stopSpeaking } = useSpeechSynthesis({ preferences });

  const handleFinalVoiceTranscript = useCallback((transcriptText: string) => {
    if (transcriptText.trim()) {
      handleSendMessage(transcriptText.trim());
    }
  }, []);

  const {
    isListening,
    interimTranscript,
    errorMessage: micError,
    toggleListening,
    stopListening,
  } = useVoiceRecognition({
    language: preferences.speechInputLanguage,
    onFinalTranscript: handleFinalVoiceTranscript,
  });

  // Save preferences with consent
  const handleUpdatePreferences = (updated: Partial<UserPreferences>) => {
    setPreferences((prev) => {
      const next = { ...prev, ...updated };
      if (next.hasGivenConsent) {
        try {
          localStorage.setItem(STORAGE_KEY_PREFS, JSON.stringify(next));
        } catch {}
      }
      return next;
    });
  };

  // Save messages if allowed by consent
  useEffect(() => {
    if (preferences.hasGivenConsent && preferences.saveHistory) {
      try {
        localStorage.setItem(STORAGE_KEY_MSGS, JSON.stringify(messages));
      } catch {}
    }
  }, [messages, preferences.hasGivenConsent, preferences.saveHistory]);

  // Timer Tick handler
  const handleTickTimers = useCallback(() => {
    setActiveTimers((prev) =>
      prev.map((timer) => {
        if (!timer.isRunning || timer.remainingSeconds <= 0) return timer;
        const nextSec = timer.remainingSeconds - 1;
        if (nextSec === 0) {
          playChime('alarm');
          triggerHaptic(200);
          sendAndroidNotification('Mero AI Sathi अलार्म', `टाइमर समाप्त भयो: ${timer.label}`);
        }
        return { ...timer, remainingSeconds: nextSec };
      })
    );
  }, []);

  const handleToggleTimer = (id: string) => {
    setActiveTimers((prev) =>
      prev.map((t) => (t.id === id ? { ...t, isRunning: !t.isRunning } : t))
    );
  };

  const handleDismissTimer = (id: string) => {
    setActiveTimers((prev) => prev.filter((t) => t.id !== id));
  };

  const handleTriggerAlarmTimer = (seconds: number, label: string) => {
    const newTimer: ActiveAssistantTimer = {
      id: 'timer-' + Date.now(),
      label: label || 'Timer',
      totalSeconds: seconds,
      remainingSeconds: seconds,
      isRunning: true,
      createdAt: Date.now(),
    };
    setActiveTimers((prev) => [...prev, newTimer]);
    playChime('success');
  };

  // Main Chat Send Handler using Command Router
  const handleSendMessage = async (text: string) => {
    if (!text.trim() || isLoading) return;

    if (preferences.hapticFeedback) {
      triggerHaptic(30);
    }

    // 1. Run Command Router to distinguish real action from ordinary chat
    const classification = routeCommand(text);

    const userMessage: Message = {
      id: 'msg-' + Date.now(),
      role: 'user',
      content: text,
      timestamp: Date.now(),
      classification: classification,
    };

    const nextMessages = [...messages, userMessage];
    setMessages(nextMessages);
    setIsLoading(true);

    try {
      const response = await fetch('/api/chat', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          messages: nextMessages.slice(-10),
          userPreferences: preferences,
          currentLanguage: preferences.language,
          classification: classification,
        }),
      });

      if (!response.ok) {
        throw new Error(`Server returned HTTP ${response.status}`);
      }

      const data = await response.json();

      let actionPayload: ActionPayload | undefined = undefined;

      // Only assign action if either server or command router identified a true action
      if (classification.isAction && classification.intentType !== 'CHAT') {
        const detectedParams = classification.detectedParams || {};
        actionPayload = {
          type: classification.intentType,
          title: data.action?.title || `${classification.intentType} Action`,
          description: data.action?.description || classification.reason,
          sensitive: classification.intentType === 'CALL' || classification.intentType === 'SEND_MESSAGE',
          status: 'pending',
          params: { ...detectedParams, ...(data.action?.params || {}) },
        };
      } else if (data.action && classification.intentType !== 'CHAT') {
        actionPayload = {
          ...data.action,
          status: 'pending',
        };
      }

      const assistantMessage: Message = {
        id: 'msg-' + (Date.now() + 1),
        role: 'assistant',
        content: data.text || 'म तपाईंलाई कसरी सहयोग गर्न सक्छु?',
        timestamp: Date.now(),
        action: actionPayload,
        classification: classification,
        searchSources: data.searchSources,
        searchQueries: data.searchQueries,
      };

      setMessages((prev) => [...prev, assistantMessage]);

      // Play audio response if auto-speak is enabled
      if (preferences.autoSpeakReplies) {
        speak(assistantMessage.content);
      }

      // If action is sensitive or requires user confirmation, prompt confirmation modal
      if (actionPayload) {
        if (actionPayload.sensitive || actionPayload.type === 'CALL' || actionPayload.type === 'SEND_MESSAGE') {
          setActiveActionForConfirmation(actionPayload);
          setActiveActionMessageId(assistantMessage.id);
        } else if (actionPayload.type === 'SET_TIMER' && actionPayload.params.seconds) {
          handleTriggerAlarmTimer(actionPayload.params.seconds, actionPayload.params.label || 'Alarm');
        }
      }
    } catch (err: any) {
      console.error('Chat error:', err);
      const errorMessage: Message = {
        id: 'err-' + Date.now(),
        role: 'assistant',
        content: `माफ गर्नुहोस्: ${err.message || 'कृपया आफ्नो इन्टरनेट जडान जाँच गर्नुहोस्।'}`,
        timestamp: Date.now(),
      };
      setMessages((prev) => [...prev, errorMessage]);
    } finally {
      setIsLoading(false);
    }
  };

  // Action Click from Chat Card or Action Hub
  const handleActionClick = (action: ActionPayload, messageId?: string) => {
    setActiveActionForConfirmation(action);
    if (messageId) {
      setActiveActionMessageId(messageId);
    }
  };

  // Truthful Action Execution when user confirms in modal
  const handleConfirmAction = () => {
    if (!activeActionForConfirmation) return;
    const action = activeActionForConfirmation;

    if (preferences.hapticFeedback) {
      triggerHaptic(50);
    }

    let executionDetail: ActionExecutionDetail | null = null;

    try {
      switch (action.type) {
        case 'CALL':
          if (action.params.phoneNumber) {
            executionDetail = executePhoneCall(action.params.phoneNumber, action.params.contactName);
          }
          break;

        case 'SEND_MESSAGE':
          if (action.params.recipient && action.params.text) {
            executionDetail = executeSendMessage(
              action.params.recipient,
              action.params.text,
              action.params.platform || 'whatsapp'
            );
          }
          break;

        case 'SET_ALARM':
          if (action.params.hours !== undefined && action.params.minutes !== undefined) {
            executionDetail = executeSetAlarm(action.params.hours, action.params.minutes, action.params.label);
            // Also start an in-app timer as reliable backup
            const now = new Date();
            const target = new Date();
            target.setHours(action.params.hours, action.params.minutes, 0, 0);
            if (target.getTime() <= now.getTime()) {
              target.setDate(target.getDate() + 1);
            }
            const diffSecs = Math.floor((target.getTime() - now.getTime()) / 1000);
            if (diffSecs > 0 && diffSecs <= 86400) {
              handleTriggerAlarmTimer(Math.min(diffSecs, 3600), action.params.label || 'Alarm');
            }
          }
          break;

        case 'SET_TIMER':
          if (action.params.seconds) {
            handleTriggerAlarmTimer(action.params.seconds, action.params.label || 'Timer');
            executionDetail = {
              success: true,
              status: 'timer_active',
              userMessage: `Started ${action.params.label || 'Timer'} (${action.params.seconds}s)`,
              nepaliMessage: `${action.params.label || 'टाइमर'} सुरु भयो। घण्टी र सूचना दिइनेछ।`,
              methodUsed: 'web_audio',
              whatActuallyHappened: 'Running active in-app timer via Web Audio API chime & Notification API.',
            };
          }
          break;

        case 'OPEN_APP':
          if (action.params.appName) {
            executionDetail = executeOpenApp(
              action.params.appName,
              action.params.package,
              action.params.fallbackUrl
            );
          }
          break;

        case 'SEARCH_WEB':
          if (action.params.query) {
            window.open(
              `https://www.google.com/search?q=${encodeURIComponent(action.params.query)}`,
              '_blank'
            );
            executionDetail = {
              success: true,
              status: 'executed',
              userMessage: `Searched Google for: ${action.params.query}`,
              nepaliMessage: `गुगल खोजी नयाँ विन्डोमा खोलिएको छ।`,
              methodUsed: 'browser_api',
              whatActuallyHappened: 'Opened verified Google web search query in browser.',
            };
          }
          break;

        case 'DRAFT_MESSAGE':
          if (action.params.recipient && action.params.text) {
            executionDetail = executeSendMessage(
              action.params.recipient,
              action.params.text,
              action.params.platform || 'whatsapp'
            );
          }
          break;

        case 'SAVE_MEMORY':
          if (action.params.memoryFact) {
            const newMem = {
              id: 'mem-' + Date.now(),
              fact: action.params.memoryFact,
              category: 'personal' as const,
              createdAt: Date.now(),
            };
            handleUpdatePreferences({
              enableMemory: true,
              userMemories: [...(preferences.userMemories || []), newMem],
            });
            executionDetail = {
              success: true,
              status: 'executed',
              userMessage: `Saved to memory: "${action.params.memoryFact}"`,
              nepaliMessage: `सहमति अनुसार सम्झनामा थपियो: "${action.params.memoryFact}"`,
              methodUsed: 'browser_api',
              whatActuallyHappened: 'Stored in consent-based local memory store and will be used to personalize future responses.',
            };
          }
          break;

        default:
          break;
      }

      // Mark message action status and attach truthful execution detail
      if (activeActionMessageId && executionDetail) {
        setMessages((prev) =>
          prev.map((m) =>
            m.id === activeActionMessageId && m.action
              ? {
                  ...m,
                  action: {
                    ...m.action,
                    status: executionDetail!.status,
                    executionDetail: executionDetail!,
                  },
                }
              : m
          )
        );
      }

      playChime('success');
    } catch (err) {
      console.error('Execution error:', err);
    } finally {
      setActiveActionForConfirmation(null);
      setActiveActionMessageId(null);
    }
  };

  const handleCancelAction = () => {
    if (activeActionMessageId) {
      setMessages((prev) =>
        prev.map((m) =>
          m.id === activeActionMessageId && m.action
            ? { ...m, action: { ...m.action, status: 'cancelled' } }
            : m
        )
      );
    }
    setActiveActionForConfirmation(null);
    setActiveActionMessageId(null);
  };

  // Clear chat history
  const handleClearHistory = () => {
    setMessages([INITIAL_GREETING]);
    try {
      localStorage.removeItem(STORAGE_KEY_MSGS);
    } catch {}
    setIsSettingsOpen(false);
  };

  // Export data
  const handleExportData = () => {
    const data = {
      app: 'Mero AI Sathi',
      exportedAt: new Date().toISOString(),
      preferences,
      messages,
    };
    const blob = new Blob([JSON.stringify(data, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `mero-ai-sathi-backup-${Date.now()}.json`;
    a.click();
    URL.revokeObjectURL(url);
  };

  return (
    <div className="flex flex-col min-h-screen bg-[#070b14] text-slate-100 font-sans selection:bg-sky-500/30">
      {/* Offline Status Banner */}
      <OfflineIndicator />

      {/* App Header */}
      <Header
        preferences={preferences}
        onUpdatePreferences={handleUpdatePreferences}
        onOpenSettings={() => setIsSettingsOpen(true)}
        onOpenPermissionsGuide={() => setIsPermissionsGuideOpen(true)}
        onOpenActionLauncher={() => setIsActionLauncherOpen(true)}
        isSpeaking={isSpeaking}
        onStopSpeaking={stopSpeaking}
      />

      {/* Main Content Area */}
      <main className="flex-1 flex flex-col w-full max-w-4xl mx-auto">
        {/* Glowing Microphone Hero & Quick Actions */}
        <GlowingMicHero
          isListening={isListening}
          isSpeaking={isSpeaking}
          isLoading={isLoading}
          interimTranscript={interimTranscript}
          errorMessage={micError}
          onToggleListening={toggleListening}
          onQuickQuery={handleSendMessage}
          preferences={preferences}
          onUpdatePreferences={handleUpdatePreferences}
        />

        {/* Chat Thread */}
        <ChatScreen
          messages={messages}
          isLoading={isLoading}
          onSendMessage={handleSendMessage}
          onActionClick={handleActionClick}
          onSpeakMessage={speak}
          isSpeaking={isSpeaking}
          onToggleListening={toggleListening}
          isListening={isListening}
          preferences={preferences}
        />
      </main>

      {/* Floating Active Timers / Alarms */}
      <ActiveTimerBar
        timers={activeTimers}
        onToggleTimer={handleToggleTimer}
        onDismissTimer={handleDismissTimer}
        onTickTimers={handleTickTimers}
      />

      {/* Sensitive Action Confirmation Modal */}
      <ConfirmationModal
        isOpen={!!activeActionForConfirmation}
        action={activeActionForConfirmation}
        onConfirm={handleConfirmAction}
        onCancel={handleCancelAction}
      />

      {/* Settings Modal */}
      <SettingsModal
        isOpen={isSettingsOpen}
        onClose={() => setIsSettingsOpen(false)}
        preferences={preferences}
        onUpdatePreferences={handleUpdatePreferences}
        onClearHistory={handleClearHistory}
        onExportData={handleExportData}
      />

      {/* Permissions Guide Modal */}
      <PermissionsGuideModal
        isOpen={isPermissionsGuideOpen}
        onClose={() => setIsPermissionsGuideOpen(false)}
      />

      {/* Android Action Launcher Hub */}
      <ActionLauncherModal
        isOpen={isActionLauncherOpen}
        onClose={() => setIsActionLauncherOpen(false)}
        onRequestActionConfirmation={(action) => handleActionClick(action)}
        onTriggerAlarmTimer={handleTriggerAlarmTimer}
      />
    </div>
  );
}
