import { useState, useEffect, useRef, useCallback } from 'react';
import { triggerHaptic, playChime } from '../utils/androidActions';

interface VoiceRecognitionOptions {
  language: string; // 'ne-NP' | 'en-US' | 'en-IN'
  onFinalTranscript?: (text: string) => void;
}

export function useVoiceRecognition({ language, onFinalTranscript }: VoiceRecognitionOptions) {
  const [isListening, setIsListening] = useState(false);
  const [transcript, setTranscript] = useState('');
  const [interimTranscript, setInterimTranscript] = useState('');
  const [isSupported, setIsSupported] = useState(false);
  const [permissionState, setPermissionState] = useState<'prompt' | 'granted' | 'denied'>('prompt');
  const [errorMessage, setErrorMessage] = useState<string | null>(null);

  const recognitionRef = useRef<any>(null);
  const finalTranscriptRef = useRef('');

  useEffect(() => {
    const SpeechRecognition = (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition;
    if (SpeechRecognition) {
      setIsSupported(true);
      const recognition = new SpeechRecognition();
      recognition.continuous = false;
      recognition.interimResults = true;
      recognition.lang = language || 'ne-NP';

      recognition.onstart = () => {
        setIsListening(true);
        setErrorMessage(null);
        setTranscript('');
        setInterimTranscript('');
        finalTranscriptRef.current = '';
        triggerHaptic(40);
        playChime('start');
      };

      recognition.onresult = (event: any) => {
        let interim = '';
        let final = '';

        for (let i = event.resultIndex; i < event.results.length; ++i) {
          if (event.results[i].isFinal) {
            final += event.results[i][0].transcript;
          } else {
            interim += event.results[i][0].transcript;
          }
        }

        if (final) {
          finalTranscriptRef.current += (finalTranscriptRef.current ? ' ' : '') + final;
          setTranscript(finalTranscriptRef.current);
        }
        setInterimTranscript(interim);
      };

      recognition.onerror = (event: any) => {
        console.warn('Speech recognition error:', event.error);
        if (event.error === 'not-allowed' || event.error === 'service-not-allowed') {
          setPermissionState('denied');
          setErrorMessage('Microphone access denied. Please grant microphone permission in Android / browser settings.');
        } else if (event.error === 'no-speech') {
          setErrorMessage('No speech detected. Please speak clearly into the microphone.');
        } else {
          setErrorMessage(`Speech recognition error: ${event.error}`);
        }
        setIsListening(false);
      };

      recognition.onend = () => {
        setIsListening(false);
        const finalResult = (finalTranscriptRef.current + ' ' + interimTranscript).trim();
        if (finalResult && onFinalTranscript) {
          onFinalTranscript(finalResult);
        }
      };

      recognitionRef.current = recognition;
    } else {
      setIsSupported(false);
      setErrorMessage('Speech recognition is not natively supported in this browser. You can type in the chat box.');
    }

    return () => {
      if (recognitionRef.current) {
        try {
          recognitionRef.current.abort();
        } catch {}
      }
    };
  }, [language]);

  const startListening = useCallback(() => {
    if (!recognitionRef.current) {
      setErrorMessage('Speech recognition is unavailable.');
      return;
    }
    setErrorMessage(null);
    try {
      recognitionRef.current.lang = language;
      recognitionRef.current.start();
    } catch (e: any) {
      // If already started, stop and restart
      try {
        recognitionRef.current.stop();
        setTimeout(() => {
          recognitionRef.current.start();
        }, 150);
      } catch (err) {
        console.error('Cannot start recognition:', err);
      }
    }
  }, [language]);

  const stopListening = useCallback(() => {
    if (recognitionRef.current) {
      try {
        recognitionRef.current.stop();
        triggerHaptic(30);
      } catch {}
    }
    setIsListening(false);
  }, []);

  const toggleListening = useCallback(() => {
    if (isListening) {
      stopListening();
    } else {
      startListening();
    }
  }, [isListening, startListening, stopListening]);

  return {
    isListening,
    transcript,
    interimTranscript,
    isSupported,
    permissionState,
    errorMessage,
    startListening,
    stopListening,
    toggleListening,
  };
}
