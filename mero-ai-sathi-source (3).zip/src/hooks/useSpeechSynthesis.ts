import { useState, useEffect, useRef, useCallback } from 'react';
import { UserPreferences } from '../types/assistant';

interface SpeechSynthesisHookOptions {
  preferences: UserPreferences;
}

export function useSpeechSynthesis({ preferences }: SpeechSynthesisHookOptions) {
  const [isSpeaking, setIsSpeaking] = useState(false);
  const [browserVoices, setBrowserVoices] = useState<SpeechSynthesisVoice[]>([]);
  const currentAudioRef = useRef<HTMLAudioElement | null>(null);

  // Load available browser voices
  useEffect(() => {
    if (typeof window === 'undefined' || !('speechSynthesis' in window)) return;

    const updateVoices = () => {
      const voices = window.speechSynthesis.getVoices();
      setBrowserVoices(voices);
    };

    updateVoices();
    window.speechSynthesis.onvoiceschanged = updateVoices;

    return () => {
      if (typeof window !== 'undefined' && 'speechSynthesis' in window) {
        window.speechSynthesis.onvoiceschanged = null;
      }
    };
  }, []);

  const stop = useCallback(() => {
    // Stop server audio
    if (currentAudioRef.current) {
      currentAudioRef.current.pause();
      currentAudioRef.current.currentTime = 0;
      currentAudioRef.current = null;
    }

    // Stop browser speech synthesis
    if (typeof window !== 'undefined' && 'speechSynthesis' in window) {
      try {
        window.speechSynthesis.cancel();
      } catch {}
    }

    setIsSpeaking(false);
  }, []);

  const speakWithBrowser = useCallback(
    (cleanText: string) => {
      if (typeof window === 'undefined' || !('speechSynthesis' in window)) {
        setIsSpeaking(false);
        return;
      }

      window.speechSynthesis.cancel();

      const utterance = new SpeechSynthesisUtterance(cleanText);
      utterance.rate = preferences.speechRate || 1.0;
      utterance.pitch = preferences.speechPitch || 1.0;

      // Pick best voice for Nepali or English
      const isNepaliText = /[\u0900-\u097F]/.test(cleanText);
      const targetLang = isNepaliText ? 'ne' : 'en';

      const match = browserVoices.find(
        (v) =>
          v.lang.toLowerCase().startsWith(targetLang) ||
          (isNepaliText && v.lang.toLowerCase().startsWith('hi')) // Hindi fallback shares devanagari pronunciation
      );

      if (match) {
        utterance.voice = match;
      }
      utterance.lang = isNepaliText ? 'ne-NP' : 'en-US';

      utterance.onstart = () => setIsSpeaking(true);
      utterance.onend = () => setIsSpeaking(false);
      utterance.onerror = () => setIsSpeaking(false);

      window.speechSynthesis.speak(utterance);
    },
    [browserVoices, preferences.speechRate, preferences.speechPitch]
  );

  const speak = useCallback(
    async (text: string) => {
      if (!text) return;
      stop();

      // Clean markdown tags or action blocks from spoken text
      const cleanText = text
        .replace(/```action[\s\S]*?```/gi, '')
        .replace(/[*#_`>]/g, '')
        .trim();

      if (!cleanText) return;

      setIsSpeaking(true);

      // Check user preferred TTS engine
      if (preferences.ttsEngine === 'browser') {
        speakWithBrowser(cleanText);
        return;
      }

      // Try Gemini 3.8 Flash-Lite TTS on server
      try {
        const res = await fetch('/api/tts', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            text: cleanText,
            voiceName: preferences.geminiVoice || 'Kore',
          }),
        });

        if (!res.ok) {
          throw new Error(`TTS server responded with ${res.status}`);
        }

        const data = await res.json();

        if (data.audioBase64) {
          const audio = new Audio(`data:${data.mimeType || 'audio/wav'};base64,${data.audioBase64}`);
          currentAudioRef.current = audio;

          audio.onended = () => {
            setIsSpeaking(false);
            currentAudioRef.current = null;
          };

          audio.onerror = () => {
            console.warn('Audio playback error, falling back to browser speech');
            speakWithBrowser(cleanText);
          };

          await audio.play();
        } else {
          // Fallback to browser synthesis
          speakWithBrowser(cleanText);
        }
      } catch (err) {
        console.warn('Server TTS failed, falling back to browser:', err);
        speakWithBrowser(cleanText);
      }
    },
    [preferences.ttsEngine, preferences.geminiVoice, speakWithBrowser, stop]
  );

  return {
    isSpeaking,
    speak,
    stop,
    browserVoices,
  };
}
